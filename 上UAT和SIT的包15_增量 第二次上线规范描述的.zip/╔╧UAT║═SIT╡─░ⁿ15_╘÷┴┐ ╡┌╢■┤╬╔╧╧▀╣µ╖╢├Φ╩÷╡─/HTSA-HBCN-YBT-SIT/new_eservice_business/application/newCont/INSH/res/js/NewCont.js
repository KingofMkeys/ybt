var vue_config = [];
var vueobj={};
var afterVueSelect={};
var bootstrap_valid={};
var afterloadNewElements={};
var beforesubmitvueform={};
var aftersubmitvueform={};
var relaprtnoStr="";
var countRelaPrtNo= 0;
function openH5Iframe(title, url){
	 layer.open({
		type: 2,
		title: title,
		content: url,
		area: ['90%', '90%'],
		success: function(layro, idx){
		  	$("div[class='layui-layer layui-layer-iframe']").attr("tabindex","-1");
		  	$("div[class='layui-layer layui-layer-iframe']").attr("role","dialog");
		  	$("div[class='layui-layer layui-layer-iframe']").attr("aria-modal","true");
		  	$("div[class='layui-layer layui-layer-iframe']").focus();
		  	$("span[class='layui-layer-setwin'] a").first().attr("aria-label","关闭模态框");
		},end: function () {
			$(window).unbind("resize");
		}
	});
}
$(document).ready(function () {}).keydown(function (e) {
   if (e.which === 27){//ESC关闭二维码页面
	   if($("a[aria-label='关闭模态框']").is(":visible")){
   			console.log("关闭当前二维码页面");
            $("a[aria-label='关闭模态框']").click();
   		}
   }
});
/**
 * vue 增加方法  init 
 */
var vueMethods ={};
vueMethods.tab_toggle_check=function(activeid){
	
};
vueMethods.addWord=function (){
	 this.$nextTick(function(){		
 	 for (var i=0;i<$("input[id^='bnfrenewCount']").length;i++){
 		 if(($("#bnfrenewCount\\["+i+"\\]").is(":visible") && $("#bnfrenewCountTitle"+i+"").length <= 0)){
		   		$("#bnfrenewCount\\["+i+"\\]").parent().append("<small id='bnfrenewCountTitle"+i+"' class='help-block zhq' style='color: red;'>请注意，" +
		   				"请按证件上的换证次数填写，例如：01。</small>");
				 }
	 }
  },200);	
};
vueMethods.checkESignFlagRadio = function (formdata){
	var arr =[];
	if(formdata){
		if("00"!=formdata.lcinsured.relationtoappnt){
			 arr.push(formdata.lcinsured);
		}
		for(var i=0;i<formdata.lcinsuredmulti.length;i++){
			 if("00"!=formdata.lcinsuredmulti[i].relationtoappnt){
				 arr.push(formdata.lcinsuredmulti[i]);
			 }
		}
		return arr.length<=2&&(formdata.lccont&&formdata.lccont.shoppingCartIndicator!='Y');
	}
	//Relationtoappnt relationtoappnt
	return false;
}

vueMethods.clearNull=function(lcappnt,lcappntaddress,value){
//	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousprovince", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previouscountry", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousprovince", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previouscity", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousarea", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousdetails", null);
	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"movetorsdtladdrdate", null);
	if(value==1){
		var x = vueobj["testdivchange"].form_elementsBYID.lcappnt.movetorsdtladdrdate;
		x.elementstatus = "01";
	}else{
		var x = vueobj["testdivchange"].form_elementsBYID.lcappnt.movetorsdtladdrdate;
		x.elementstatus = "02";
	}		
}

vueMethods.checkFormDisabled=function (appflag,flag){
	if(flag =='5'){
		_sinovalid_needValidFlag=false;
		return true;
	}
	if( appflag=='01'|| appflag=='10'||
							 appflag==null|| appflag==''
							|| appflag=='undefined'){
		return false;
	}
	_sinovalid_needValidFlag=false;
	return true;
};
vueMethods.checkFormDisabledH5=function (formdata){

	if(formdata.newContApply.brhQRFlag == 'Y' || formdata.newContApply.brhQRFlag == 'S'){
		_sinovalid_needValidFlag=false;
		return true;
	}

	if(formdata.newContApply.shoppingCartIndicator == 'Y' && formdata.newContApply.remoteSalesIndicator == 'Y'){
		_sinovalid_needValidFlag=false;
		return true;
	}
	
	if(formdata.lccont && formdata.lccont.shoppingCartIndicator == 'Y' && formdata.lccont.remoteSalesIndicator == 'Y'){
		_sinovalid_needValidFlag=false;
		return true;
	}
	if(formdata.lccont && formdata.lccont.shoppingCartIndicator == 'N' && formdata.lccont.remoteSalesIndicator == 'Y'){
		_sinovalid_needValidFlag=false;
		return true;
	}
	if(formdata.newContApply.flag =='5'){
		_sinovalid_needValidFlag=false;
		return true;
	}
	if(formdata.newContApply.appflag=='01'|| formdata.newContApply.appflag=='10'||
			formdata.newContApply.appflag==null|| formdata.newContApply.appflag==''
							|| formdata.newContApply.appflag=='undefined'){
		return false;
	}
	_sinovalid_needValidFlag=false;
	return true;
};

//远程购物车
vueMethods.generateOpQRcode = function (formdata){

	//手机端客户未录入完成时，新建继续操作二维码给到客户
	if(formdata.lccont && formdata.lccont.shoppingCartIndicator == 'Y' && formdata.lccont.remoteSalesIndicator == 'Y'){
		if(formdata.lccont.riskcode == '@Y3' || formdata.lccont.riskcode == '@C8'|| formdata.lccont.riskcode == '@E10'
			|| formdata.lccont.riskcode == '@E27'){ //uvc uvd uve
			$.ajax({
				type : "POST",
				url:path+'/newContApply/checkUVCAndGetNewPolicy.do',
				data: {"transNo":formdata.lccont.transno, "orderId":formdata.lccont.orderID},
				dataType : "json",
				success:function(data) {
					// console.log(data)
					if(!data.success){
						alert(data.msg)
					}else{
						if("Y" == data.parm){
							console.log("此单由于客户保存投保人后再进行关联rbf操作，已作废，刷新数据后可生成有效新单二维码")
							alert("请刷新数据后再生成操作二维码！")
						}else{
							//正常关联操作
							let url = path + "/qrCodeController/generateBtnQRcode.do?customerId=" + formdata.lccont.grpcontno
								+"&staffId=" + formdata.lccont.operator + "&transno=" + formdata.lccont.transno;
							if(initFormdata.newContApply.tokenId != "" && initFormdata.newContApply.tokenId != null){
								url += "&tokenId=" +initFormdata.newContApply.tokenId;
							}
							openH5Iframe("扫描二维码继续操作", url);
						}

					}
				},
				error:function(){
					alert("系统异常")
				}
			});
		}else{
			let url = path + "/qrCodeController/generateBtnQRcode.do?customerId=" + formdata.lccont.grpcontno
				+"&staffId=" + formdata.lccont.operator + "&transno=" + formdata.lccont.transno;
			if(initFormdata.newContApply.tokenId != "" && initFormdata.newContApply.tokenId != null){
				url += "&tokenId=" +initFormdata.newContApply.tokenId;
			}
			openH5Iframe("扫描二维码继续操作", url);
		}
	}
};

//RE渠道的 白板录入的
vueMethods.generateWBoard = function (formdata) {

	//手机端客户未录入完成时，新建继续操作链接给到ALI白板
	if ((formdata.lccont && formdata.lccont.shoppingCartIndicator == 'N' && formdata.lccont.remoteSalesIndicator == 'Y')
		|| (initFormdata.newContApply.activeId != "" && initFormdata.newContApply.activeId != null)) {
		if (formdata.lccont.riskcode == '@Y3' || formdata.lccont.riskcode == '@C8' || formdata.lccont.riskcode == '@E10'
			|| formdata.lccont.riskcode == '@E27') { //uvc uvd uve
			$.ajax({
				type: "POST",
				url: path + '/newContApply/checkUVCAndGetNewPolicy.do',
				data: {"transNo": formdata.lccont.transno, "orderId": formdata.lccont.orderID},
				dataType: "json",
				success: function (data) {
					// console.log(data)
					if (!data.success) {
						alert(data.msg)
					} else {
						if ("Y" == data.parm) {
							console.log("此单由于客户保存投保人后再进行关联rbf操作，已作废，刷新数据后可生成有效新单URL")
							alert("请刷新数据后再生成操作URL！")
						} else {

							//正常关联操作
							let url = path + "/qrCodeController/generateBtnWBoard.do?customerId=" + formdata.lccont.grpcontno
								+ "&staffId=" + formdata.lccont.operator + "&transno=" + formdata.lccont.transno;
							if (initFormdata.newContApply.tokenId != "" && initFormdata.newContApply.tokenId != null) {
								url += "&tokenId=" + initFormdata.newContApply.tokenId;
							}
							openH5Iframe("开启客户端继续操作", url);
						}

					}
				},
				error: function () {
					alert("系统异常")
				}
			});
		} else {
			let url = path + "/qrCodeController/generateBtnWBoard.do?customerId=" + formdata.lccont.grpcontno
				+ "&staffId=" + formdata.lccont.operator + "&transno=" + formdata.lccont.transno;
			if (initFormdata.newContApply.tokenId != "" && initFormdata.newContApply.tokenId != null) {
				url += "&tokenId=" + initFormdata.newContApply.tokenId;
			}
			openH5Iframe("开启客户端继续操作", url);
		}
	}
};


//分行QR
vueMethods.generateBrhOpQRcode = function (formdata){

	if(formdata.lccont && (formdata.lccont.brhQRFlag == 'S' || formdata.lccont.brhQRFlag == 'Y')){
		//手机端客户未录入完成时，新建继续操作二维码给到客户
		let url = path + "/qrCodeController/generateBrhOpQRcode.do?customerId=" + formdata.lccont.grpcontno
			+"&staffId=" + formdata.lccont.operator + "&transno=" + formdata.lccont.transno
			+"&insurancecom=" + formdata.lccont.insurancecom + "&riskcode=" + formdata.lccont.riskcode
			+"&brhQRFlag=" + formdata.lccont.brhQRFlag;
		if(initFormdata.newContApply.tokenId != "" && initFormdata.newContApply.tokenId != null){
			url += "&tokenId=" +initFormdata.newContApply.tokenId;
		}
		openH5Iframe("扫描二维码继续操作", url);
	}

};
vueMethods.refreshCurrentPage = function (formdata){
	
	if(self != top){
		console.log("当前已嵌入框架");
	}else{
		console.log("当前未嵌入框架");
	}

	if(formdata.lccont.riskcode == '@Y3' || formdata.lccont.riskcode == '@C8' || formdata.lccont.riskcode == '@E10'
		|| formdata.lccont.riskcode == '@E27'){ //uvc uvd uve
		$.ajax({
			type : "POST",
			url:path+'/newContApply/checkUVCAndGetNewPolicy.do',
			data: {"transNo":formdata.lccont.transno, "orderId":formdata.lccont.orderID},
			dataType : "json",
			success:function(data) {
				if(!data.success){
					alert(data.msg)
				}else{
					if("Y" == data.parm){
						console.log("此单由于客户保存投保人后再进行关联rbf操作，已作废，返回有效新单流水号：" + data.transno)
						let urlUVC = path+"/newCont/enter/"+ formdata.lccont.insurancecom +"/"+ formdata.lccont.riskcode +"/"+ formdata.lccont.grpcontno+"/"+ data.transno+".do";
						if(initFormdata.newContApply.tokenId != "" && initFormdata.newContApply.tokenId != null){
							urlUVC += "?tokenId=" +initFormdata.newContApply.tokenId;
						}
						window.location.href = urlUVC;
					}else{
						console.log("uvc|uvd正常关联后正常刷新")
						window.location.reload(true);
					}
				}
			},
			error:function(){
				alert("系统异常")
			}
		});
	}else{
		console.log("非uvc|uvd，正常刷新")
		window.location.reload(true);
	}

};

vueMethods.tickNoticePage = function (formdata){
	
	$('#tab_notice_tabinfo').removeClass("disabled");
	$('#tab_notice_tabinfo').addClass("active");
	$('#tab_notice_tabinfo').click();
	
};
//隔天之后，电子签发送按钮不能点击
vueMethods.checkDateForButton=function (formdata){
	if(formdata&&formdata.lccont&&formdata.lccont.polapplydate){
		var polapplydate =formdata.lccont.polapplydate;
		var date = new Date();
		var seperator1 = "-";
		var year = date.getFullYear();
		var month = date.getMonth() + 1;
		var strDate = date.getDate();
		if (month >= 1 && month <= 9) {
			month = "0" + month;
		}
		if (strDate >= 0 && strDate <= 9) {
			strDate = "0" + strDate;
		}
		var currentdate = year + seperator1 + month + seperator1 + strDate;
		if(new Date(polapplydate)<new Date(currentdate)){
			return true;
		}else{
			return false;
		}
	}
};
//电子签名radio控制
vueMethods.checkESignRadioDisabled = function (lccont,flag,uploadflag,uploadflaghis){
	var appflag = lccont.appflag;
	var chargecode = lccont.chargecode;
	var polApplyDate = lccont.polapplydate;
    var recording=lccont.recording;
    var esignflag = lccont.eSignFlag;
	/*var date = new Date();
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	if(month < 10){
		month = "0" + month;
	}
	var day = date.getDate();
	if(day < 10){
		day = "0" + day;
	}
	var today = year+month+day;*/
	
	if(flag == '5'){
		return true;
	}
	if(recording=='Y'){ 
		return true;
	}
	
	if(appflag == null || appflag == '' 
		|| polApplyDate == null || polApplyDate=='' ||uploadflag=='Y'||(esignflag=='P'&&(uploadflag=="F"||uploadflaghis=='F')) 
			/*|| chargecode == null || chargecode == ''*/){
		return true;
	}
	
	/*if(appflag == '01' || appflag =='10' ||appflag == '07'){
		return true;
	}else */
	if(appflag == '02' || appflag == '12' || appflag == '14'){
		/*if(chargecode == null || chargecode == 'W' || chargecode =='F' || chargecode == 'S' || chargecode =='E'){
			return false;
		}*/
		if(chargecode != 'C'){
			return false;
		}
	}else if(appflag =='04'){
		if(chargecode == null || chargecode == 'S' ){
			return false;
		}
	}else if(appflag =='05' || appflag =='06'){
		if(chargecode == null || chargecode == 'C' ){
			return false;
		}
	}else if(appflag == '09' || appflag == '13'){
		if(chargecode == null || chargecode == 'W' ){
			return false;
		} 
	}/*else if(appflag == '14'){
		if(chargecode == 'W' || chargecode == 'F' || chargecode == 'S' ||chargecode == 'E'){
			return false;
		}
	}else if(appflag == '12'){
		if(chargecode == 'W' || chargecode=='F' || chargecode=='S' || chargecode=='E'){
			return false;
		}
	}else if(appflag == '13'){
		if(chargecode == 'W'){
			return false;
		}
	}*/
	
	return true;
};

function getAge(birthday)
{
    //出生时间 毫秒
    var birthDayTime = new Date(birthday).getTime(); 
    //当前时间 毫秒
    var nowTime = new Date().getTime(); 
    //一年毫秒数(365 * 86400000 = 31536000000)
    return Math.ceil((nowTime-birthDayTime)/31536000000);
}



var tempVal = "";
//更新保单电子签名标记   
vueMethods.insertElectronicSignature=function (lccont, value){
//	console.log(lccont);
//	console.log(value);
	if(tempVal == value){
		return;
	}else{
		tempVal = value;
	}

	buttonControl(lccont.proposalcontno);
	if(vueobj["testdivchange"].formdata.lcnotConclusion&&vueobj["testdivchange"].formdata.lcnotConclusion.uploadflag=="Y"){
		vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"eSignFlag",vueobj["testdivchange"].formdata.lccontTemp.eSignFlag);
		layer.msg("<span style='font-size:20px'>投保单号："+lccont.proposalcontno+"的影像文件已成功发送至保险公司，不能更改签署方式</span>",{offset:"t", time:10000,anim:6});
		return;
	}
	
	//tablet不支持的证件类型提示RM走纸质签的
	//身份证 护照 港澳台通行证  户口本 外国人永久居留证  港澳台居住证 被保人&另一持有人出生证
	var arr = ["I", "P", "X", "H","K","J","C"];
	
	var formdata=vueobj["testdivchange"].formdata;
	var lcappntIdType=formdata.lcappnt==null?null:formdata.lcappnt.idtype;
	var lcinsuredIdType=formdata.lcinsured==null?null:formdata.lcinsured.lcinsuredidtype;
	var lcinsuredtwoIdType=formdata.lcinsuredtwo==null?null:formdata.lcinsuredtwo.lcinsuredidtype;
	var anotherHolderIdType=formdata.ldcustomeraccount==null?null:formdata.ldcustomeraccount.anotherHolderIdType;
	//出生证 判断成年人不能电子签
	var lcinsuredbirthday=formdata.lcinsured==null?null:formdata.lcinsured.lcinsuredbirthday;
	var lcinsuredtwobirthday=formdata.lcinsuredtwo==null?null:formdata.lcinsuredtwo.lcinsuredbirthday;
	
	var lcinsuredmultiArr=formdata.lcinsuredmulti;
	
	console.log("投保人证件类型:"+lcappntIdType+"," +
	"被保人1证件类型:"+lcinsuredIdType+",被保人2证件类型:"+lcinsuredtwoIdType+",另一持有人证件类型:"+anotherHolderIdType);
	
	if("E"==value){
		var flag=false;
		for(var i=0;i<lcinsuredmultiArr.length;i++){
			if(arr.toString().indexOf(lcinsuredmultiArr[i].lcinsuredidtype)<0){
				  flag=true;
				  break;
			}
		}
		if(flag||null!=lcappntIdType&&arr.toString().indexOf(lcappntIdType)<0||"C"==lcappntIdType||
				   null!=lcinsuredIdType&&arr.toString().indexOf(lcinsuredIdType)<0||
				   null!=lcinsuredtwoIdType&&arr.toString().indexOf(lcinsuredtwoIdType)<0||
				   null!=anotherHolderIdType&&arr.toString().indexOf(anotherHolderIdType)<0||
				   null!=lcinsuredbirthday&&"C"==lcinsuredIdType&&getAge(lcinsuredbirthday)>=18||
				   null!=lcinsuredtwobirthday&&"C"==lcinsuredtwoIdType&&getAge(lcinsuredtwobirthday)>=18){
				   layer.msg("<span style='font-size:20px'>此客户的证件暂时不支持使用电子签署认证，请走纸质流程！</span>",{offset:"t", time:10000,anim:6});
		}
	}
	
	//纸质
	if("P"==value){
		$(function () { $("[data-toggle='popover']").popover("show"); });
		$.ajax({
			type : "POST",
			url:path+'/SFPJsonSend/JsonSend.do',
			data: {"transNo":formdata.lccont.transno},
			dataType : "json",
			success:function(data) {
				try {
					var response=JSON.parse(data);
					if(response.status=="SUCCESS"){
						alert("成功/Succeed");
					}else if(response.errorInfo[0].code!="OIM0042"){
						alert("同步SFP失败/Failed to update \n"+data);
					}else{
						alert("双录停止失败！");
					}
				} catch (e) {
					alert("双录停止失败！");
				}
				
			},
			 error:function(){ 
				 alert("双录停止失败！");
			 }
		});
	}
	
	$.ajax({
		  url: path + "/newContEnter/selectUploadFlag.do",
		  data: {"proposalcontno":lccont.proposalcontno},
		  type: "post", 
		  success : function (data) {
			  if(data.success){
				var showdilog= layer.load(0, {
					  shade: [0.1,'#fff'] //0.1透明度的白色背景
				   });
				$.ajax({
					  url: path + "/newContEnter/updateEsFlag.do",
					  data: {"transno":lccont.transno,"eSignFlag":value,"proposalcontno":lccont.proposalcontno},
					  type: "post", 
					  success : function (data) {
					      if(data.success){
					//          	layer.alert(data.msg);
					    	buttonControl(lccont.proposalcontno);
					    	layer.close(showdilog); 
					      	console.log(data.msg);
					      	esignTable('Y');
					      	
					      	$.ajax({
				        	 	url: path + "/AllianzController/esignTypeNotifyINSH.do",
				        	 	data: {"proposalcontno":lccont.proposalcontno,"operator":lccont.operator},
				        	 	type: "post", 
				        	 	success : function (data) {
				        	 		if(!data.success){
				        	 			alert(data.msg);
				        	 		}else{
				        	 			console.log("esign Type Notice Request Send Success.");
				        	 		}  
				        	 	},
				        	 	error : function (data){
				                    console.log("esign Type Notice Request Send Error.");
				                }
				            });
					      	
					      }else{
					    	layer.close(showdilog);
					    	layer.alert(data.msg);
					      }
					  },
					  error : function (data){
						  layer.close(showdilog);
					      alert("系统繁忙,请稍后再试！");
					  }
			    }); 
			  }else{
			        $("input[name='eSignFlag'][value='E']").prop("checked",true);
			    	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"eSignFlag","E");
			    	vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcnotConclusion,"uploadflag","Y");
			        return;
			  }
		  },
		  error : function (data){
		      alert("系统繁忙,请稍后再试！");
		  }
	});
	
	
};
//重新push
	// vue_config.push({id : "testdivchange", url : path + "/vue/common/test.do",initFunction:pageinit});
	vue_config.push({
		id : "testdivchange",
		url : "/newCont/enter/get/tab/"+initFormdata.newContApply.insurancecom+"/insuranceContInput"

	});
	/**
	合并校验
	**/
//	var bootstrap_valid = {
//
//			ageFromBrithDay: function(validitem   ){
//        	 	var min =getRealValueFromVueObj.call( validitem.vueobj,validitem.min);
//		 		var max =getRealValueFromVueObj.call( validitem.vueobj,validitem.max);
//		 		var validobj= {
//		 				message:validitem.tempmessage + "年龄必须大于"+ min+ "小于"+ max,
//		 				minage:min,
//		 				maxage:max
//		 		};
//			 
//		 		return validobj;
//                 
//         }
//	
//	};
/**
 * 合并 变化 校验 
 */ 
combineCheckID["lccont_tabinfo"]="lcappnt_tabinfo";
combineCheckID["subriskcode_tabinfo"]="lcinsured_tabinfo";
 
		/***
		 * 下拉框配置
		 */
		var commonCombobox_option = {
			commonCombobox_notice : {
				"data" : [ {
					"value" : "N",
					"text" : "否"					
				}, {
					"value" : "Y",
					"text" : "是"
				} ]
			},
			commonCombobox_elementstatus : {
				"data" : [ {
					"value" : "01",
					"text" : "显示"
				}, {
					"value" : "02",
					"text" : "不显示"
				} ]
			},
			commonCombobox_country : {

				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]
				
			},
			commonCombobox_fataca : {
				"data" : [ {
					"value" : "01",
					"text" : "显示"
				}, {
					"value" : "02",
					"text" : "不显示"
				} ]
			},					
			commonCombobox_IDtype : {
				url : path + '/newCont/codeselect/common/idtype',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			/*commonCombobox_IDtype1 : {
				url : path + '/newCont/codeselect/id/idtype/#lccont.grpcontno',
				valueField : "idtype",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ],
			afterselect : function() {
				var idtype = $("#idtype").val();
				var grpcontno = vueobj["testdivchange"].formdata.lccont.grpcontno;	
				$.ajax({
					url : path + '/LdcodeController/selectidIndo.do',
					type : "POST",
					data : {
						"idtype" : idtype,
						"cifid": grpcontno
					},
					success : function(data) {						
						vueobj["testdivchange"].$set(
								vueobj["testdivchange"].formdata.lcappnt,
								"idno", data.idno);	
						vueobj["testdivchange"].$set(
								vueobj["testdivchange"].formdata.lcappnt,
								"appntenddate", data.expiredate);
					},
				});													
			  
			},
			},*/
			
			commonCombobox_sex : {
				"data" : [ {
					"value" : "0",
					"text" : "男"
				}, {
					"value" : "1",
					"text" : "女"
				} ]
			},
			commonCombobox_bnforder : {
				"data" : [ {
					"value" : "1",
					"text" : "第一顺序"
				}, {
					"value" : "2",
					"text" : "第二顺序"
				} ]
			},
			commonCombobox_lcinsuredtype : {
				url : path + '/newCont/codeselect/common/lcinsuredtype',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			commonCombobox_insuredrelaToInsu : {
				url : path + '/newCont/codeselect/common/anzl_relation',
				valueField : "code",
				relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			/*commonCombobox_bnfrelationship : {
				"data" : [ {
					"value" : "01",
					"text" : "父子"
				}, {
					"value" : "02",
					"text" : "母子"
				} ]
			},*/
			commonCombobox_lcinsuredrelationship : {
				"data" : [ {
					"value" : "01",
					"text" : "本人"
				}, {
					"value" : "02",
					"text" : "非本人"
				} ]
			},
			commonCombobox_insurancecom : {
				url : path + '/newContEnter/selectFromLacom.do',
				valueField : "agentcom",
				// 显示在输入框的
				inputText : "name",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : ["agentcom", "name" ]
			},
			
			commonCombobox_anotherHolderIdType : {
				url : path
						+ '/LdcodeController/selectIdTypeByCodetype.do?codetype=idtype',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			commonCombobox_getpolmode : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : '1',
					codename : '快递递送'
				}, {
					code : '2',
					codename : '电子保单'
				} ]
			},
			commonCombobox_custtype : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : 'RCC',
					codename : '否'
				}, {
					code : 'NonRCC',
					codename : '是'
				} ]
			},
			commonCombobox_newbankaccno : {
				url : path + '/newCont/codeselect/selectAppntAccNoCNY/#grpcontno.do',
				valueField : "accountnumber",
				// 显示在输入框的
				inputText : "accountnumber",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "accountnumber" ],
				textShowFormat: function(textShow,linedata){
					var accountvalid='';
					if(linedata.accountvalid=='1'){
						accountvalid ='A';
					}else if(linedata.accountvalid=='2'){
						accountvalid ='D';
					}
					if(linedata.accountstatus=="Y"){
						return  "(联-"+accountvalid+")"+linedata.accountnumber;
					}else{
						return  "(个-"+accountvalid+")"+linedata.accountnumber;
					}  
				},
				afterselect : function(ele,$target  ,value,text,comboboxObj) {
					var newbankaccno = $("#newbankaccno").val();
					var grpcontno = $("#grpcontno").val();
					$.ajax({
						url : path + '/newContEnter/selectLdcustomeraccount.do',
						type : "POST",
						data : {
							"bankaccno" : newbankaccno,
							"cifid": grpcontno
						},
						success : function(data) {
							if(data.accountstatus=='Y'){
								console.log("-----联名账户----");
								$("#div_anotherHolderIdType").show();
								$("#div_anotherHolderIdNo").show();
								$("#div_anotherHolderName").show();
								$("#div_anotherHoldercountry").show();									
							}else{
								$("#div_anotherHolderIdType").hide();
								$("#div_anotherHolderIdNo").hide();
								$("#div_anotherHolderName").hide();
								$("#div_anotherHoldercountry").hide();
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderIdType", "");	
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderIdNo", "");	
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderName", "");
								
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.ldcustomeraccount,
										"anotherHolderCountry", ""); 
								vueobj["testdivchange"].$set(
										vueobj["testdivchange"].formdata.lccont,
										"anotherholder", ""); 	
							}
							
							vueobj["testdivchange"].$set(
									vueobj["testdivchange"].formdata.lccont,
									"accountbalance", data.accountbalance);
							if(initFormdata.newContApply.enterWay!="pEnter"||(initFormdata.newContApply.enterWay=="pEnter"&&(comboboxObj&&comboboxObj.options.data.length>1))){
								vueobj["testdivchange"].$set(
									vueobj["testdivchange"].formdata.lccont,
									"accountBranch", data.accountBranch);
							}
							vueobj["testdivchange"].$set(
									vueobj["testdivchange"].formdata.newContApply,
									"accountStatus", data.accountstatus);
						},
					});
				},
			 
		 },
		 
		
			//行业类别
			commonCombobox_lcinsuredindustry : {
				url : path + '/newCont/codeselect/occupation/AL.do',
				valueField : "occupationcode1",
				// 显示在输入框的
				inputText : "occupationname1",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname1" ]
			},
			//行业代码
			commonCombobox_lcinsuredindustrycode : {
				url : path + '/newCont/codeselect/occupation/#lcinsuredindustry/AL.do',
				valueField : "occupationcode2",
				// 显示在输入框的
				inputText : "occupationname2",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname2" ]
			},
			//行业代码
			commonCombobox_lcinsuredindustrycode1 : {
				url : path + '/newCont/codeselect/occupation/#lcinsuredindustry1/AL.do',
				valueField : "occupationcode2",
				// 显示在输入框的
				inputText : "occupationname2",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname2" ]
			},
			//职业代码
			commonCombobox_occupationcode : {
				url : path + '/newCont/codeselect/occupationocc/#lcinsuredindustrycode/AL.do',
				valueField : "occupationcode",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			},
			//职业代码
			commonCombobox_occupationcode1 : {
				url : path + '/newCont/codeselect/occupationocc/#lcinsuredindustrycode1/AL.do',
				valueField : "occupationcode",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			},
			//婚姻状况
			commonCombobox_marry :{
				url : path + '/LdcodeController/selectIdTypeByCodetype.do?codetype=marry',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			//主要收入来源
			commonCombobox_appntincomesource :{
				url : path + '/LdcodeController/selectIdTypeByCodetype.do?codetype=appntincomesource',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]/*,
				afterselect: function(){
					if($('#appntincomesource').val() != '4'){
						$('#appntincomeother').attr("disabled",true);
						$('#appntincomeother').val("");
					}else{
						$('#appntincomeother').removeAttr("disabled");
					}
				}*/
			},
			//INSH投保人出生地国家下拉
			commonCombobox_birthcountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ],
				afterselect : function(){
					if($('#birthcountyinsh').val() != 'CN'){
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"appntbirthprovince", null);
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappnt,"appntcity", null);
						$('#appntbirthprovince').combobox("clear");
						$('#appntbirthprovince').combobox("disable");
						$('#appntcity').combobox("clear");
						$('#appntcity').combobox("disable");
					}else{
						$('#appntbirthprovince').combobox("enable");
						$('#appntcity').combobox("enable");
					}
				}
				
			},
			//INSH职业代码说明
			commonCombobox_occualias :{
				url : path + '/LdcodeController/selectDistinctCodeAlias.do?codetype=occupationinsh',
				valueField : "comcode",
				// 显示在输入框的
				inputText : "codealias",
				delayLoadDataFlag : true,
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codealias" ]
			},
			//INSH职业代码
			commonCombobox_occupationcodeinsh :{
				url : path + '/LdcodeController/code/#occualias.do',
				valueField : "code",
				// 显示在输入框的
				inputText : "codename",
				delayLoadDataFlag : true,
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "code","codename" ],
				textShowFormat: function(textShow,linedata){
					return  linedata.code+"-"+linedata.codename;
				}
			},
			/*commonCombobox_occupationcode : {
				url : path + '/newContEnter/selectByLdoccupationVo.do',
				valueField : "occupationcode",
				// 显示在输入框的
				inputText : "occupationname",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "occupationname" ]
			},*/
			commonCombobox_creditgrade : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : '1',
					codename : '农村'
				}, {
					code : '2',
					codename : '城镇'
				} ]
			},
			commonCombobox_jade : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : 'Y',
					codename : '是'
				}, {
					code : 'N',
					codename : '否'
				} ]
			},
			commonCombobox_multiplenativeplaceflag :{
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : 'Y',
					codename : '多重国籍'
				}, {
					code : 'N',
					codename : '非多重国籍'
				} ]/*,
				afterselect: function(){
					if($('#multiplenativeplaceflag').val() == 'N'){
						$('#nativeplace2').combobox("clear");
						$('#nativeplace2').combobox("disable");	
						$('#nativeplace3').combobox("clear");
						$('#nativeplace3').combobox("disable");	
					}else{
						$('#nativeplace2').combobox("enable");
						$('#nativeplace3').combobox("enable");	
					}
				}*/
			}
			,
			commonCombobox_goaltype : {
				url:path+"/LdcodeController/selectGoalTypeByGrpContno/"+initFormdata.newContApply.grpcontno+"/"+initFormdata.newContApply.insurancecom+"/"+(initFormdata.newContApply.FPRID==''?'N':initFormdata.newContApply.FPRID)+"/"+initFormdata.newContApply.riskcode+".do",
				//url : path+ '/LdcodeController/selectGoalTypeByGrpContno/#newContApply.grpcontno/#newContApply.insurancecom/#newContApply.FPRID/#newContApply.riskcode',
				valueField : "code",
				//relateType: "vue",
				// 显示在输入框的
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ]
			},
			//通讯选项：电子通知、纸质通知。
			commonCombobox_correspondenceopt : {
				valueField : "code",
				inputText : "codename",
				// 显示在下拉列表的项，默认空，空则全部显示
				textShow : [ "codename" ],
				data : [ {
					code : 'E',
					codename : '电子通知'
				}, {
					code : 'P',
					codename : '纸质通知'
				} ]
			},
			//投保人通讯地址国家下拉
			commonCombobox_zactladdrcountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]/*,
				afterselect : function(){
					if($('#zactladdrcountry').val() != 'CN'){	
						if($('#zactladdrcountry').val()!=null&&$('#zactladdrcountry').val()!=""&&$('#zactladdrcountry').val()!=undefined){
							$('#appntpostprovinceinsh').combobox("clear");
							$('#appntpostcityinsh').combobox("clear");
							$('#appntpostdistrictinsh').combobox("clear");	
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"postprovince", "");
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"postcity", "");
	 					    vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"postdistrict", "");
						}
//						$('#appntpostprovinceinsh').combobox("clear");
						$('#appntpostprovinceinsh').combobox("disable");
//						$('#appntpostcityinsh').combobox("clear");
						$('#appntpostcityinsh').combobox("disable");
//						$('#appntpostdistrictinsh').combobox("clear");
						$('#appntpostdistrictinsh').combobox("disable");
					}else if($('#appntpostprovinceinsh_combobox').val() != '' && $('#appntpostprovinceinsh_combobox').val() !=undefined){
						return;
					}else{
						$('#appntpostprovinceinsh').combobox("enable");
						$('#appntpostcityinsh').combobox("enable");
						$('#appntpostdistrictinsh').combobox("enable");
					}
				}*/
				
			},
			//dbs_city  dbs_province dbs_area 投保人联系地址省
			commonCombobox_appntpostprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 投保人联系地址市
			commonCombobox_appntpostcity : {

				url :  path + '/newCont/codeselect/allcity/#appntpostprovinceinsh.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 投保人联系地址区
			commonCombobox_appntpostdistrict : {

				url :  path + '/newCont/codeselect/allcounty/#appntpostcityinsh.do',
				valueField : "countyid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//投保人居住地址国家下拉
			commonCombobox_homecountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ],
				afterselect : function(){
					if($('#addresscountry').val() != 'CN'){
						if($('#addresscountry').val()!=null&&$('#addresscountry').val()!=""&&$('#addresscountry').val()!=undefined){
							$('#homeprovince').combobox("clear");
							$('#homecity').combobox("clear");
							$('#homedistrict').combobox("clear");
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"homeprovince", null);
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"homecity", null);
	 					    vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"homedistrict", null);
						}
						$('#homeprovince').combobox("clear");
						$('#homecity').combobox("clear");
						$('#homedistrict').combobox("clear");
						$('#homeprovince').combobox("disable");
						
						$('#homecity').combobox("disable");
						
						$('#homedistrict').combobox("disable");
					}else{
						$('#homeprovince').combobox("enable");
						$('#homecity').combobox("enable");
						$('#homedistrict').combobox("enable");
//						console.log($('#homeprovince').combobox());
					}
				}
				
			},
			//dbs_city  dbs_province dbs_area 投保人居住地址省
			commonCombobox_appnthomeprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 投保人居住地址市
			commonCombobox_appnthomecity : {
				
				url :  path + '/newCont/codeselect/allcity/#homeprovince.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 投保人居住地址区
			commonCombobox_appnthomedistrict : {

				url :  path + '/newCont/codeselect/allcounty/#homecity.do',
				 valueField : "countyid",
				 delayLoadDataFlag : true,
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			 
		    //行业
		    commonCombobox_businesstype_insh : {

					url : path + '/newCont/codeselect/common/businesstype_insh.do',
					valueField : "code",
					delayLoadDataFlag : true,
					// 显示在输入框的
					inputText :  "codename" ,
					textShow : [ "codename" ]
					
				},
				//永久居住地址国家下拉
				commonCombobox_permanentcountry : {
					url : path + '/newCont/codeselect/common/iss_country',
					valueField : "code",
					relateType: "vue",
					delayLoadDataFlag : true,
					// 显示在输入框的
					inputText :  "codename" ,
					textShow : [ "codename" ]/*,
					afterselect : function(){
						if($('#permanentcountry').val() != 'CN'){
							if($('#permanentcountry').val()!=null&&$('#permanentcountry').val()!=""&&$('#permanentcountry').val()!=undefined){
								$('#permanentprovince').combobox("clear");
								$('#permanentcity').combobox("clear");
								$('#permanentarea').combobox("clear");
							}
//							$('#permanentprovince').combobox("clear");
							$('#permanentprovince').combobox("disable");
//							$('#permanentcity').combobox("clear");
							$('#permanentcity').combobox("disable");
//							$('#permanentarea').combobox("clear");
							$('#permanentarea').combobox("disable");
						}else if($('#permanentprovince_combobox').val() != '' && $('#permanentprovince_combobox').val() !=undefined){
							return;
						}else{
							$('#permanentprovince').combobox("enable");
							$('#permanentcity').combobox("enable");
							$('#permanentarea').combobox("enable");
						}
					}
				*/	
				},
			//dbs_city  dbs_province dbs_area 永久居住地址省
			commonCombobox_permanentprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 永久居住地址市
			commonCombobox_permanentcity : {

				url :  path + '/newCont/codeselect/allcity/#permanentprovince.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 永久居住地址区
			commonCombobox_permanentarea : {

				url :  path + '/newCont/codeselect/allcounty/#permanentcity.do',
				 valueField : "countyid",
				 delayLoadDataFlag : true,
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//曾居住地址国家下拉
			commonCombobox_previouscountry : {
				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ]/**/,
				afterselect : function(){
					if(vueobj["testdivchange"].formdata.lcappnt.movetorsdtladdrdate!=undefined||vueobj["testdivchange"].formdata.lcappnt.movetorsdtladdrdate!=null){
						var x = vueobj["testdivchange"].form_elementsBYID.lcappnt.movetorsdtladdrdate;
						x.elementstatus = "01";		
					}
					if($('#previouscountry').val() != 'CN'){
							if($('#previouscountry').val()!=null
									&&$('#previouscountry').val()!=""
										&&$('#previouscountry').val()!=undefined){
								$('#previousprovince').combobox("clear");
								$('#previouscity').combobox("clear");
								$('#previousarea').combobox("clear");
								vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousprovince", null);
								vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previouscity", null);
								vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"previousarea", null);
								
							}
//						$('#previousprovince').combobox("clear");
						$('#previousprovince').combobox("disable");
//						$('#previouscity').combobox("clear");
						$('#previouscity').combobox("disable");
//						$('#previousarea').combobox("clear");
						$('#previousarea').combobox("disable");
					}else{
						$('#previousprovince').combobox("enable");
						$('#previouscity').combobox("enable");
						$('#previousarea').combobox("enable");
					}
				}
				
			},
			//dbs_city  dbs_province dbs_area 曾居住地址省
			commonCombobox_previousprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 曾居住地址市
			commonCombobox_previouscity : {

				url :  path + '/newCont/codeselect/allcity/#previousprovince.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 曾居住地址区
			commonCombobox_previousarea : {

				url :  path + '/newCont/codeselect/allcounty/#previouscity.do',
				 valueField : "countyid",
				 delayLoadDataFlag : true,
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//单位、学校国家下拉
			commonCombobox_employcountry : {

				url : path + '/newCont/codeselect/common/iss_country',
				valueField : "code",
				relateType: "vue",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText :  "codename" ,
				textShow : [ "codename" ],
				afterselect : function(){
					if($('#employcountry').val() != 'CN'){
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employprovince", null);
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employcity", null);
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lcappntaddress,"employarea", null);
						$('#employprovince').combobox("clear");
						$('#employprovince').combobox("disable");
						$('#employcity').combobox("clear");
						$('#employcity').combobox("disable");
						$('#employarea').combobox("clear");
						$('#employarea').combobox("disable");
					}else{
						$('#employprovince').combobox("enable");
						$('#employcity').combobox("enable");
						$('#employarea').combobox("enable");
					}
				}
				
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址省
			commonCombobox_employprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址市
			commonCombobox_employcity : {

				url :  path + '/newCont/codeselect/allcity/#employprovince.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址区
			commonCombobox_employarea : {

				url :  path + '/newCont/codeselect/allcounty/#employcity.do',
				 valueField : "countyid",
				 delayLoadDataFlag : true,
					// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址省
			commonCombobox_appntbirthprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//dbs_city  dbs_province dbs_area 单位/学校居住地址市
			commonCombobox_appntcity : {

				url :  path + '/newCont/codeselect/allcity/#appntbirthprovince.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			
			//dbs_city  dbs_province dbs_area 第二被保人联系地址省
			commonCombobox_insuredpostprovince1 : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			
			//dbs_city  dbs_province dbs_area 第二被保人联系地址市
			commonCombobox_insuredpostcity1 : {

				url :  path + '/newCont/codeselect/allcity/#insuredpostprovince1.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			
			//dbs_city  dbs_province dbs_area 第二被保人联系地址
			commonCombobox_insuredpostdistrict1 : {

				url :  path + '/newCont/codeselect/allcounty/#insuredpostcity1.do',
				valueField : "countyid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "countyname",
				textShow : [ "countyname" ]
			},					
			//dbs_city  dbs_province dbs_area 是否参加当地医疗保险
			commonCombobox_insuredsociomedical : {

				url :  path + '/newCont/codeselect/common/anzl_sociomedical.do',
				valueField : "code",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
			//开户行省
			commonCombobox_lccontprovince : {

				url :  path + '/newCont/codeselect/allprovinceid/province.do',
				valueField : "provinceid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "provincename",
				textShow : [ "provincename" ]
			},
			//开户行市
			commonCombobox_lccontcity : {

				url :  path + '/newCont/codeselect/allcity/#lccontareaprovince.do',
				valueField : "cityid",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			commonCombobox_countrycode_anzl : {

				url :  path + '/newCont/codeselect/common/countrycode_anzl.do',
				delayLoadDataFlag : true,
				valueField : "code",
				delayLoadDataFlag : true,
				// 显示在输入框的
				inputText : "codename",
				textShow : [ "codename" ]
			},
         //根据保险产品加载对应的网点及地区						
			commonCombobox_cityname_all : {

				url :  path + '/newCont/codeselect/serachCity/#newContApply.insurancecom/#newContApply.riskcode',
				valueField : "citycode",
				relateType: "vue",
				// 显示在输入框的
				inputText : "cityname",
				textShow : [ "cityname" ]
			},
			commonCombobox_companyCode_all : {

				url :  path + '/newCont/codeselect/serachcompanyCode/#newContApply.insurancecom/#newContApply.riskcode/#lccont.citycode',
				valueField : "comcode",
				relateType: "vue",
				// 显示在输入框的
				inputText : "comname",
				textShow : [ "comname" ]
			},
			commonCombobox_relaPrtNo_insh : {

				url :  path + '/newCont/codeselect/relevanceRbfProposalcontno/'+initFormdata.newContApply.riskcode+'/'+(initFormdata.newContApply.FPRID==''?'no_fprID':initFormdata.newContApply.FPRID)+'/'+initFormdata.newContApply.grpcontno+'/'+(initFormdata.newContApply.transno==''?'no_transno':initFormdata.newContApply.transno) +".do",
				delayLoadDataFlag : true,
				valueField : "proposalcontno",
				// 显示在输入框的
				inputText : "proposalcontno",
				textShow : [ "proposalcontno" ],
				afterClick : function(){
					if($('#relaprtno').val()!=null&&$('#relaprtno').val()!=''&&relaprtnoStr!=$('#relaprtno').val()){
						if(confirm("是否关联投保单"+$('#relaprtno').val()+"?")){
							/*$.ajax({
								url : path + '//newCont/common/getAllFormDataByProposalcontno.do',
								type : "POST",
								data : {
									"proposalcontno" : $('#relaprtno').val(),
								},
								success : function(data) {
									vueobj["testdivchange"].$set(vueobj["testdivchange"],"formdata",data);
								},error:function(){
									alert("系统异常");
								}
							});*/
							var proposalcontno=$('#relaprtno').val();
							var showdilog= layer.load(2, {
								shade:0.3, //0.2透明度的白色背景
							});
							 $.ajax({
						            url:path + '/newContApply/uvcInshCopy.do',
						            type: "POST",
						           // async: false,
						            dataType:"json",
						            data:{
						            	"applyBeanStr":JSON.stringify(initFormdata.newContApply),
						            	"relaprtno":proposalcontno
						            },
						            success: function(data){
						            	layer.close(showdilog);
						                if(data.success==true){
						                   
//						                    if(row.insurancecom!="MELI"){
											var url = path + "/newCont/enter/" + vueobj["testdivchange"].formdata.newContApply.insurancecom + "/" + vueobj["testdivchange"].formdata.newContApply.riskcode + "/" + vueobj["testdivchange"].formdata.newContApply.grpcontno + "/" + data.msg + ".do?flag=3";
											window.location.replace(url);
//						                    }else{
//						                    	 window.location.href="partNewContEnter.jsp?flag=4&transno="+data.msg;
//						                    }
						                   
						                }else{
						                	//layer.alert(data.msg);
						                }

						            },error:function(){
						            	layer.alert("系统异常");
						            	layer.close(showdilog);
									}
						        });
						}else{
							vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"relaPrtNo", relaprtnoStr);
						}
					}else{
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"relaPrtNo", $('#relaprtno').val());
					}
				},
				afterselect:function(ele,$target  ,text,value,comboboxObj){
					/*iutf(comboboxObj.select_Data != undefined && $('#relaprtno').val() == ''){
						//清掉
					}*/
					if(countRelaPrtNo < 1){
						relaprtnoStr=value;
					}
					countRelaPrtNo++;
					if(comboboxObj.selected == false && $('#relaprtno').val() != ''){
						//清掉
						vueobj["testdivchange"].$set(vueobj["testdivchange"].formdata.lccont,"relaPrtNo",'');
					}
					
				}
			}
		};

		afterVueSelect.wtrelaprtno=function(form_element){
		    
			if($("#wtrelaprtno").val()=="Y"){
				$("#div_relaprtno").show();
			}else{
				$("#div_relaprtno").hide();
				$('#relaprtno').combobox("clearData");
				vueobj["testdivchange"].$set(
						vueobj["testdivchange"].formdata.lccont,
						"relaPrtNo", "");	
			}
		
	    }		
    /**
     * 下面是进行插件初始化
     * 你只需传入相应的键值对
     * */
    


/**
 * 自定义 校验
 */
var bootstrap_valid={
	 
};
/**
 *   值变化钩子
 */

		
//		/**
//		 * 同被保人
//		 */
//		afterVueSelect.relationtoappnt=function(form_element){
//			 
//			var topvue = getTopvueObj(this);
//			if(topvue.formdata.lcinsured["relationtoappnt"]=="01"){
//				
//				topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",topvue.formdata.lcappnt.appntname); 
//				
////				topvue.formdata.lcinsured["lcinsuredname"]=topvue.formdata.lcappnt.appntname;
//			}else{
////				topvue.$set(topvue.formdata.lcinsured,"lcinsuredname",""); 
//				
//			}
//			
//		}




$(function() {
	//分行继续录入RM所在销售网点、名称显示
	console.log("remark:"+initFormdata.newContApply.remark
		+"   brhQRFlag:"+initFormdata.newContApply.brhQRFlag+"  购物车:"+initFormdata.newContApply.shoppingCartIndicator
		+"   远程:"+initFormdata.newContApply.shoppingCartIndicator
		+"   flag:"+initFormdata.newContApply.flag+"  试算："+initFormdata.newContApply.appflag+"(01、10未试算-2，else-5)");
	//flag=3时为复制单后跳转这个页面（排除），appflag！=01|10时，为不可继续录入的已试算单（排除）
	if (initFormdata.newContApply.flag != '3' && (initFormdata.newContApply.appflag == '01' || initFormdata.newContApply.appflag == '10')) {
        //查询销售网点名称
        $.ajax({
            url: path + '/newContEnter/selectCompanyName.do',
            type: "POST",
            success: function (data) {
                if (data != null) {
					$("#companyName").val(data.comname);//表中查不到时，输入框就会是空的
					$("#companyCode").val(data.comcode);
                    $("#companyCodeName_Modal").modal('show');
                } else {
                    alert("销售网点名称查询异常！");
                }
            }, error: function () {
                alert("销售网点名称查询错误！");
            }
        });
    }
});

//关闭确认当前销售网点提示框
function isConfirm(){
	$('#companyCodeName_Modal').modal('hide');
};

function afterVueInitDataLoad() {
	console.info("vue初始化完成后，决定表单显示与否");
	if (this.formdata.newContApply.subrisklist
		&& this.formdata.newContApply.subrisklist.length > 0) {
		// if(this.formdata.newContApply.shoppingCartIndicator == 'Y' && this.formdata.newContApply.remoteSalesIndicator == 'Y'){
		// 	this.$set(this.form_elementsBYID.INSHinsuranceContInput['subriskcode_tabinfo'],"elementstatus", "04");
		// }

		console.info("进入01了：附加险个数不为0，为：" + this.formdata.newContApply.subrisklist.length);
		console.info("IPS查询前取值1：" + initFormdata.newContApply.applicationId + "  " + initFormdata.newContApply.quotationId);
	
		var _that = this;
		//IPS是否含有附加险
		$.ajax({
			type: "POST",
			url: path + "/newCont/common/checkIPSSubRisk.do",
			data: {
				"applicationId": this.formdata.newContApply.applicationId,
				"quotationId": this.formdata.newContApply.quotationId,
				"transno": this.formdata.newContApply.transno
			},
			dataType: "json",
			success: function (data) {
				console.log("查询IPS成功，data.parm：" + data.parm);
				if (data.success) {
					if (data.parm == 'N') {
						//不包含附加险，要隐藏掉
						_that.$set(_that.form_elementsBYID.INSHinsuranceContInput['subriskcode_tabinfo'], "elementstatus", "04");
					}

				} else {
					console.log(data.msg + "  附加险tab不作处理");
				}

			},
			error: function () {
				console.log("系统异常");
			}
		});

	} else {
		this.$set(this.form_elementsBYID.INSHinsuranceContInput['subriskcode_tabinfo'],
			"elementstatus", "04");//04 不显示
	}	
	
}
		
