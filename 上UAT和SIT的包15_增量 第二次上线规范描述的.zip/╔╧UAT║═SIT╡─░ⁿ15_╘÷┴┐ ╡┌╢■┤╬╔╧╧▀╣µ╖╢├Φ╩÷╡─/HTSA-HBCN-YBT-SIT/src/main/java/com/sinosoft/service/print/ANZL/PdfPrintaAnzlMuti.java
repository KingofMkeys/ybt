package com.sinosoft.service.print.ANZL;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.sinosoft.bean.common.FormElement;
import com.sinosoft.bean.common.NoticeFormData;
import com.sinosoft.bean.common.ValueMapBean;
import com.sinosoft.bean.common.VueForm;
import com.sinosoft.bean.newCont.ContFormData;
import com.sinosoft.bean.newCont.NewContStaticStr;
import com.sinosoft.bean.newCont.data.ApplyBean;
import com.sinosoft.core.common.bean.config.SinoProperty;
import com.sinosoft.mvc.newCont.NewContController;
import com.sinosoft.service.api.PubFun;
import com.sinosoft.service.business.db.dao.*;
import com.sinosoft.service.business.db.vo.*;
import com.sinosoft.service.business.ui.contprint.metLife.SpecialProvenceCheck;
import com.sinosoft.service.common.newCont.ImpartConfigService;
import com.sinosoft.service.common.pdfprint.PdfItextBean;
import com.sinosoft.service.common.pdfprint.PdfPrintForItextImpl;

import net.sf.json.JSONArray;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PdfPrintaAnzlMuti extends PdfPrintForItextImpl {

	/** 日志 */
	private static final Logger logger = LoggerFactory
			.getLogger(PdfPrintaAnzlMuti.class);
	
	@Resource
	private SinoProperty sinoProperty;
	@Resource
	private LmriskDao lmriskDao;
	@Resource
	private LdcomVoMapper ldcom;
	@Resource
	LdoccupationVoMapper ldoccupationVoMapper;
	@Resource
	private NewContController newContController;
	@Resource
    private LMRiskParamsDefADao lmriskParamsDefADao;

	@Resource
	private LdcodeDao ldcodeDao;
	@Autowired
	private NewContEnterDao enterDao;
	@Autowired
    private LdPathDao ldpathDao;
	@Autowired
	private lcaddressVoMapper addressDao;
	@Autowired
	private ProvinceVoMapper proviceDao;
	@Autowired
    private CityVoMapper cityDao;
	@Autowired
    private CountyVoMapper countyDao;
	@Autowired
	private PaymentBranchMapper paymentbranchMapper;
	@Autowired
	private lcpolVoMapper lcpolVoMapper;
	@Autowired
	private ImpartConfigService impartConfigService;
    @Autowired
	private FormelementMapper formelementMapper;
	@Override
	public String getFormTemplate() {

		Properties fontproperties = sinoProperty.getProMap().get(
				"pdfprint_properties");
		return fontproperties.getProperty("ANZLmuti_template");

	}
	/**
	 * 保险计划改大写
	 * @param lcpolVo
	 * @return
	 */
	private String getPlan(lcpolVo lcpolVo){
		String plan = lcpolVo.getPlan();
		if ("1".equals(plan)){
			plan = "计划一";
		}else if("2".equals(plan)){
			plan = "计划二";
		} else if("3".equals(plan)){
			plan = "计划三";
		}
		return plan;
	}
	 
	/***
	 * 0 : HttpServletRequest
	 * 1 : transno
	 * 2 : riskcode
	 */
	@Override
	public PdfItextBean getPDF(Object... obj) throws IOException {
 
		PdfItextBean pdfStamper =null;
		try {
			ContFormData returnFormData = getFormData(
					(HttpServletRequest) obj[0], (String) obj[1],
					(String) obj[2],(String) obj[3]);
			// 准备数据
			List<lcpolVo> lcpolVos = returnFormData.getSublcpols();
			lcpolVo[] lcpolVos2 = new lcpolVo[21];
			for (lcpolVo lcpolVo : lcpolVos) {
				if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())){
					lcpolVo.setBak1(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode())+ "(" + getPlan(lcpolVo) + ")");
					System.out.println("-----111-----"+lcpolVo.getBak1());
				}else{
					lcpolVo.setBak1(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()));
				}
				try {
					int insudNo = Integer.parseInt(lcpolVo.getMaininsured());
					if(insudNo!=999){
						for (int i = insudNo * 3; i < (insudNo + 1) * 3; i++) {
							if (lcpolVos2[i] == null) {
								lcpolVos2[i] = lcpolVo;
								break;
							}
						}
					}
					else {
						for (int i = 0; i < 3; i++) {
							if (lcpolVos2[18+i] == null) {
								lcpolVos2[18+i] = lcpolVo;
								break;
							}
						}
					}
				} catch (Exception e) {
					logger.error(obj[1] + "附加险处理报错 。 附加险所属被保人出错");
					e.printStackTrace();
				}

			}
			lcpolVos.clear();
			for (int i = 0; i < lcpolVos2.length; i++) {
				if (lcpolVos2[i] == null) {
					lcpolVos.add(new lcpolVo());
				} else {
					lcpolVos.add(lcpolVos2[i]);
				}
			}
			//生成文件的路径
			String pdfpath = ldpathDao.selectByKey("41").getCodeValue();
			File file = new File(pdfpath);
			if (file.exists()) {
				pdfpath = pdfpath + File.separator
						+ returnFormData.getLccont().getProposalcontno();
				File fileChild = new File(pdfpath);
				if (!fileChild.exists()) {
					fileChild.mkdir();
				}
				logger.info("path:"  + pdfpath);
	 
				
			} else {
				throw new IOException(pdfpath + "目录有误");
			}
			// 通用处理
			pdfStamper = getFillFormFieldPDF(returnFormData,pdfpath+File.separator+ returnFormData.getLccont().getProposalcontno()+".pdf");

			
			// 生成PDF
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new IOException(e);
		}finally{

		
		
		}
		return pdfStamper;
	}

	private ContFormData getFormData(HttpServletRequest request, String transno 
			, String riskcode, String grpcontno) {
		
		String insurancecom ="ANZL";
		
		VueForm returnVueForm = new VueForm();
		
		ContFormData returnFormData = new ContFormData();
		returnVueForm.setFormdata(returnFormData);
		
		ApplyBean applyBean = new ApplyBean();
		applyBean.setTransno(transno);
		applyBean.setRiskcode(riskcode);
		applyBean.setGrpcontno(grpcontno);
		applyBean.setInvestment("M");
		returnFormData.setNewContApply(applyBean); 
//		
		
		
		returnFormData=	newContController.getAllFormData(request, transno, insurancecom, returnVueForm);

		//一年期不打印税收
		if("1Y".equals(returnFormData.getLcpol().getInsuyear())){
			List<TAXTIN> taxtins = new ArrayList<>();
			returnFormData.getLcappnt().setTaxtype(null);
			returnFormData.getLcappnt().setTaxtins(taxtins);
			returnFormData.getLcinsured().setTaxtype(null);
			returnFormData.getLcinsured().setTaxtins(taxtins);
		}

		return returnFormData;
	}
	
	
	@Override
	public ValueMapBean getValueMapBean() {

		ValueMapBean valueMapBean = new ValueMapBean(); 
		//告知
		valueMapBean.addJsonMapEle("noticeinfos.owneryesorno", "Y", "是");
		valueMapBean.addJsonMapEle("noticeinfos.owneryesorno", "N", "否");
		valueMapBean.addJsonMapEle("noticeinfos.impartContentInsus.insuredyesorno", "Y", "是");
		valueMapBean.addJsonMapEle("noticeinfos.impartContentInsus.insuredyesorno", "N", "否");
		
		
		valueMapBean.addJsonMapEle("bnf.sex", "0", "男");
		valueMapBean.addJsonMapEle("bnf.sex", "1", "女");
		
		return valueMapBean;
		
	}
	
	@Override
	public String getDateformat() {
		// TODO Auto-generated method stub
		return "yyyy/MM/dd";
	}
	
	/***
	 * 获取保险期间
	 * @param lcpolVo
	 * @return
	 */
	private String getInsuYear(lcpolVo lcpolVo){
		
		
		 String insuyear = lcpolVo.getInsuyear();
		LmriskparamsdefaVo defavo = new LmriskparamsdefaVo();
        defavo.setRiskcode(lcpolVo.getRiskcode());
        defavo.setParamstype("insuyear");
        defavo.setParamscode(insuyear);
        logger.info("保险期间代号" + insuyear);
        insuyear = lmriskParamsDefADao.selectlmriskParamsDef(defavo).getParamsname();

        return insuyear;
	}
	
	
	/**
	 * 获取付费期间
	 * @param lcpolVo
	 * @return
	 */
	private String getPayendyear(lcpolVo lcpolVo){
		
		
		String payendyear = lcpolVo.getPayendyear();
	    if (payendyear.equals("0Y")) {
	        payendyear = "趸交";
	    } else {
	        System.out.println("保费支付期" + payendyear);
	        payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
	    }
       return payendyear;
	}
	

//    tBean.setPremiumTerm(payendyear);
	
	private LdoccupationVo getLdoccupation(String  occupationcode){
	
		if(occupationcode==null||occupationcode.length()==0){
			return new LdoccupationVo();
		}
		
		 LdoccupationVo  ldoccupationVo  =ldoccupationVoMapper.selectByOccupationcode(occupationcode, "AL");
	 
		 if(ldoccupationVo==null){
			 ldoccupationVo= new LdoccupationVo();
		 }
		
		return ldoccupationVo;
		
		
	}
	

	@Override
	public void setSpecialCode(Object valueObj, PdfItextBean pdfStamper) throws IOException {
		ContFormData returnFormData = (ContFormData)valueObj;
        String transno = returnFormData.getNewContApply().getTransno();
        //渠道
        String commonchannel = returnFormData.getLccont().getCommonchannel();
		Date polapplydate = returnFormData.getLccont().getPolapplydate();
        if ("SC".equals(commonchannel)||"RS".equals(commonchannel)) {
        	setSigleValue("手机银行", pdfStamper, "commonchannel");
			try {
				setSigleValue(PubFun.formatYMD1(polapplydate),pdfStamper,"polapplydate");
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}else if("BH".equals(commonchannel)) {
        	setSigleValue("银保通", pdfStamper, "commonchannel");
        }
        System.out.println("渠道："+commonchannel+"销售人员编号："+returnFormData.getLccont().getOperator());
        //条形码
		setSigleValue("*" + returnFormData.getLccont().getProposalcontno()
				+ "*", pdfStamper, "lccont.barcodetext");    
        setSigleValue("*1151*", pdfStamper, "barcode1code");
        setSigleValue("*1152*", pdfStamper, "barcode2code");
        setSigleValue("*1152*", pdfStamper, "barcode2code");
        setSigleValue("*4201*", pdfStamper, "side1code");
        setSigleValue("*4202*", pdfStamper, "side2code");
        setSigleValue("*4203*", pdfStamper, "side3code");
        setSigleValue("*4204*", pdfStamper, "side4code");
        setSigleValue("*4205*", pdfStamper, "side5code");
        setSigleValue("*4206*", pdfStamper, "side6code");
        setSigleValue("*4207*", pdfStamper, "side7code");
        setSigleValue("*4208*", pdfStamper, "side8code");
        setSigleValue("*4209*", pdfStamper, "side9code");
        setSigleValue("*4210*", pdfStamper, "side10code");
		 LCContVo contSchema = enterDao.selectBylccont(transno);
		//线上还是线下
        if( "12".equals(contSchema.getAppflag())){
			if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
				setSigleValue("HSBC Online Application_S", pdfStamper, "lccont.appflag");
			}else if("BH".equals(commonchannel) || "RE".equals(commonchannel)){
				setSigleValue("HSBC Online Application", pdfStamper, "lccont.appflag");
			}
        }else if("09".equals(contSchema.getAppflag()) || "14".equals(contSchema.getAppflag())){
			if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
				setSigleValue("HSBC Offline Application_S", pdfStamper, "lccont.appflag");
			}else if("BH".equals(commonchannel) || "RE".equals(commonchannel)){
				setSigleValue("HSBC Offline Application", pdfStamper, "lccont.appflag");
			}
        }

		//投保人
        if (returnFormData.getLcappnt() != null) {
        	lcaddressVo lcappntaddress = returnFormData.getLcappntaddress();
			//投保人行业类型
			setSigleValue(ldoccupationVoMapper.selectByOccupationcode(returnFormData.getLcappnt().getOccupationcode(), "AL").getOccupationname2(), pdfStamper, "lcappnt.industrytype");
			//投保人具体工作
			setSigleValue(ldoccupationVoMapper.selectByOccupationcode(returnFormData.getLcappnt().getOccupationcode(), "AL").getOccupationname(), pdfStamper, "lcappnt.responsibility");
			//投保人居住地址
	        String postprovince1 = lcappntaddress.getPostprovince();
	        ProvinceVo provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince1));
	        provinceVo = SpecialProvenceCheck.check(provinceVo);
	        String postcity1 = lcappntaddress.getPostcity();
	        CityVo cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity1));
	        cityVo = SpecialProvenceCheck.checkCity(cityVo);
	        String postArea = lcappntaddress.getPostdistrict();
	        CountyVo countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
	        String postdetail =lcappntaddress.getPostaladdress();
	        String appntResidentialAddress = provinceVo.getProvincename() + cityVo.getCityname()
	                + countyVo.getCountyname() + postdetail;
	        
	        setSigleValue(appntResidentialAddress, pdfStamper,
	        		"lcappntaddress.homeaddress");
			
	        setSigleValue(ldcodeDao.selectLdcode("iss_country", returnFormData.getLcappnt().getBirthcounty()).get(0).getCodename(), pdfStamper,
	        		"lcappnt.birthcounty");
			//证件长期
			Date date = null;
			try {
				date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			Date enddate = returnFormData.getLcappnt().getAppntenddate();
			if (null!=enddate){
				if (date.compareTo(enddate) == 0){
					setSigleValue("长期",pdfStamper,"lcappnt.appntenddate");
				}
			}

	    }

		// 被保人
		if (returnFormData.getLcinsured() != null) {
			// 职业
			LdoccupationVo ldoccupationVo = getLdoccupation(returnFormData
					.getLcinsured().getLcinsuredroccupationcode());
			setSigleValue(ldoccupationVo.getOccupationname2(), pdfStamper,
					"lcinsured.industrytype");
			setSigleValue(ldoccupationVo.getOccupationname(), pdfStamper,
					"lcinsured.lcinsuredroccupationcode");
			//出生国籍
			String lcinsuredbirthcounty=returnFormData.getLcinsured().getLcinsuredbirthcounty();
			setSigleValue(ldcodeDao.selectLdcode("iss_country", lcinsuredbirthcounty).get(0).getCodename(), pdfStamper,
					"lcinsured.lcinsuredbirthcounty");
			//居住地址
	        lcaddressVo insuriedlcaddressVo = new lcaddressVo();
	        insuriedlcaddressVo.setTransno(transno);
	        insuriedlcaddressVo.setCustomerno(contSchema.getGrpcontno());
	        insuriedlcaddressVo.setAddressno(new BigDecimal("1"));
	        lcaddressVo insuriedlcaddress_anzl = addressDao.selectByPrimaryKey_anzl(insuriedlcaddressVo);
	        String postprovince1 = insuriedlcaddress_anzl.getPostprovince();
	        ProvinceVo provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince1));
	        provinceVo = SpecialProvenceCheck.check(provinceVo);
	        String postcity1 = insuriedlcaddress_anzl.getPostcity();
	        CityVo cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity1));
	        cityVo = SpecialProvenceCheck.checkCity(cityVo);
	        String postArea = insuriedlcaddress_anzl.getPostdistrict();
	        CountyVo countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
	        String postdetail = insuriedlcaddress_anzl.getPostaladdress();
	        String insuriedResidentialAddress = provinceVo.getProvincename() + cityVo.getCityname()
	                + countyVo.getCountyname() + postdetail;
	        
	        setSigleValue(insuriedResidentialAddress, pdfStamper,
					"lcinsuredaddress.homeaddress");
	                
	        // 投保人与主被保人关系
	        String relationtoappnt = returnFormData.getLcinsured().getRelationtoappnt();
	        if(relationtoappnt!=null) {
				setSigleValue(ldcodeDao.selectLdcode("anzl_relation", relationtoappnt).get(0).getCodename(), pdfStamper, "lcinsured.relationtoappnt");
			}
			//证件长期
			Date date = null;
			try {
				date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			Date enddate = returnFormData.getLcinsured().getInsureidenddate();
			if (null!=enddate){
				if (date.compareTo(enddate) == 0){
					setSigleValue("长期",pdfStamper,"lcinsured.insureidenddate");
				}
			}
		}

		// 附属被保险人
		int i = 0;
		for (LcinsuredTwoVo lcinsuredTwoVo : returnFormData
				.getLcinsuredmulti()) {

			if (lcinsuredTwoVo != null) {
				// 职业
				LdoccupationVo ldoccupationVo = getLdoccupation(lcinsuredTwoVo
						.getLcinsuredroccupationcode());

				setSigleValue(ldoccupationVo.getOccupationname2(),
						pdfStamper, "lcinsuredmulti[" + i + "].industrytype");
				setSigleValue(ldoccupationVo.getOccupationname(),
						pdfStamper, "lcinsuredmulti[" + i
								+ "].lcinsuredroccupationcode");
				//出生国籍
				String lcinsuredbirthcounty=lcinsuredTwoVo.getLcinsuredbirthcounty();
				setSigleValue(ldcodeDao.selectLdcode("iss_country", lcinsuredbirthcounty).get(0).getCodename(), pdfStamper,
						"lcinsuredmulti[" + i + "].lcinsuredbirthcounty");

				
				//居住地址
				
		        String postprovince1 = lcinsuredTwoVo.getLcaddress().getPostprovince();
		        ProvinceVo provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince1));
		        provinceVo = SpecialProvenceCheck.check(provinceVo);
		        String postcity1 = lcinsuredTwoVo.getLcaddress().getPostcity();
		        CityVo cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity1));
		        cityVo = SpecialProvenceCheck.checkCity(cityVo);
		        String postArea = lcinsuredTwoVo.getLcaddress().getPostdistrict();
		        CountyVo countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
		        String postdetail =lcinsuredTwoVo.getLcaddress().getPostaladdress();
		        String insuriedResidentialAddress = provinceVo.getProvincename() + cityVo.getCityname()
		                + countyVo.getCountyname() + postdetail;
		        
		        setSigleValue(insuriedResidentialAddress, pdfStamper,
		        		"lcinsuredmulti[" + i + "].lcaddress.postaladdress");
				
		        //与主被保险人关系
		        setSigleValue(ldcodeDao.selectLdcode("anzl_relation", lcinsuredTwoVo.getRelatoinsu()).get(0).getCodename(), pdfStamper,"lcinsuredmulti[" + i + "].relatoinsu");
				//证件长期
				Date date = null;
				try {
					date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");

					Date enddate = lcinsuredTwoVo.getInsureidenddate();
					if (null!=enddate){
						if (date.compareTo(enddate) == 0){
							setSigleValue("长期",pdfStamper,"lcinsuredmulti[" + i + "].insureidenddate");
						}else{
							setSigleValue(PubFun.formatYMD1(enddate),pdfStamper,"lcinsuredmulti[" + i + "].insureidenddate");
						}
					}
	//
	//					// 出生日期
	//					Calendar c = Calendar.getInstance();
	//					c.setTime(lcinsuredTwoVo.getInsureidenddate());
	//					setSigleValue(String.valueOf(c.get(Calendar.YEAR)),
	//							pdfStamper, "lcinsuredmulti[" + i + "].year");
	//					setSigleValue(String.valueOf(c.get(Calendar.MONTH) + 1),
	//							pdfStamper, "lcinsuredmulti[" + i + "].month");
	//					setSigleValue(String.valueOf(c.get(Calendar.DAY_OF_MONTH)),
	//							pdfStamper, "lcinsuredmulti[" + i + "].day");

					//证件有效起期
					if(null!=lcinsuredTwoVo.getStartingDate()){
						System.out.println("被保人"+i+"证件有效起期:"+lcinsuredTwoVo.getStartingDate());
						setSigleValue(PubFun.formatYMD1(lcinsuredTwoVo.getStartingDate()),pdfStamper,"lcinsuredmulti[" + i + "].startingDate");
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}

			i++;
		}

		
		// 主险
		setSigleValue(getInsuYear(returnFormData.getLcpol()), pdfStamper,
				"lcpol.insuyear");
		setSigleValue(getPayendyear(returnFormData.getLcpol()), pdfStamper,
				"lcpol.payendyear");
		if (null != returnFormData.getLcpol().getPlan() && StringUtils.isNoneBlank(returnFormData.getLcpol().getPlan())){
			setSigleValue(lmriskDao.selectNameByRiskCode(returnFormData.getLcpol().getKindcode())+ "(" + getPlan(returnFormData.getLcpol()) + ")", pdfStamper,
					"lcpol.bak1");
		}else{
			setSigleValue(lmriskDao.selectNameByRiskCode(returnFormData.getLcpol().getKindcode()), pdfStamper,
					"lcpol.bak1");
		}
		//每期保费
		
        if (returnFormData.getLcpol() != null) {
        	lcpolVo lcpol = returnFormData.getLcpol();
            String payintv = lcpol.getPayintv();
    		setSigleValue(payintv, pdfStamper,
    				"lcpol.payintv");
    		setSigleValue(lcpol.getPaymode(), pdfStamper,
    				"lcpol.paymode");
    		
        }
		// 附加险
		i = 0;

		for (lcpolVo lcpolVo : returnFormData.getSublcpols()) {
			
			if (lcpolVo.getRiskcode() == null) {
				i++;
				continue;
			}
			setSigleValue(getInsuYear(lcpolVo), pdfStamper, "sublcpols[" + i
					+ "].insuyear");
			setSigleValue(getPayendyear(lcpolVo), pdfStamper, "sublcpols["
					+ i + "].payendyear");
			setSigleValue(lcpolVo.getBak1(), pdfStamper, "sublcpols[" + i
					+ "].bak1");
			if (lcpolVo.getBak1().contains("计划")){
				setSigleValue(lcpolVo.getBak1(), pdfStamper, "sublcpols[" + i
						+ "].bak1");
			}else{
				if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())){
					setSigleValue(lcpolVo.getBak1()+ "(" + getPlan(lcpolVo) + ")", pdfStamper, "sublcpols[" + i
							+ "].bak1");
				}else{
					setSigleValue(lcpolVo.getBak1(), pdfStamper, "sublcpols[" + i
							+ "].bak1");
				}
			}
			System.out.println("-----222-----"+lcpolVo.getBak1());


//			if("@R6".equals(lcpolVo.getRiskcode())){
//			}
			i++;
		}
		
		
		// //授权账户号码
        PaymentBranchKey pay = new PaymentBranchKey();
        pay.setTransno(transno);
        pay.setAccountholder("0");// 授权账户
        PaymentBranch payment = paymentbranchMapper.selectByPrimaryKey(pay);
        if (null != payment) {
            // 授权银行
        	setSigleValue("汇丰银行(中国)有限公司",pdfStamper, "NameBanklcappnt");
            // 授权账户号码
            String bankaccno = payment.getBankaccno().replaceAll("^CNHSBC(.*)", "$1");
            char[] accountNumberCharArray = bankaccno.toCharArray();
            for (int j = 0; j < accountNumberCharArray.length; j++) {
            	setSigleValue(accountNumberCharArray[j]+"", pdfStamper, "AccountNumberslcappnt"+ (j+1));
                }
            }

            // 授权省
            if (null != payment.getAreaprovince()) {
            	setSigleValue(proviceDao.selectByPrimaryKey(
                		new BigDecimal(payment.getAreaprovince())).getProvincename(),pdfStamper, "Areaprovincelcappnt");
            }

            // 给予授权市
            if (null != payment.getAreacity()) {
            	setSigleValue(cityDao.selectByPrimaryKey(new BigDecimal(payment.getAreacity()))
                        .getCityname(),pdfStamper, "Areacitylcappnt");
            }

            // 分行/支行
            if (null != payment.getBranch()) {
            	setSigleValue(payment.getBranch(),pdfStamper, "Branchlcappnt");
            }

        pay.setAccountholder("1");// 给予账户
        payment = paymentbranchMapper.selectByPrimaryKey(pay);
        if (null != payment) {
        	
            // 授权银行
        	setSigleValue("汇丰银行(中国)有限公司",pdfStamper, "NameBanklcinsured");
            // 给予账户号码
            if (null != payment.getBankaccno()) {


                String bankaccno1 = payment.getBankaccno().replaceAll("^CNHSBC(.*)", "$1");
                setSigleValue(bankaccno1,pdfStamper, "AccountNumberslcinsured");

            // 给予授权省
            if (null != payment.getAreaprovince()) {
            	setSigleValue(proviceDao.selectByPrimaryKey(
                        new BigDecimal(payment.getAreaprovince())).getProvincename(),pdfStamper, "Areaprovincelcinsured");
            }

            // 给予授权市
            if (null != payment.getAreacity()) {
            	setSigleValue(cityDao.selectByPrimaryKey(new BigDecimal(payment.getAreacity()))
                        .getCityname(),pdfStamper, "Areacitylcinsured");
            }

            // 给予分行/支行 nameBankIns
            if (null != payment.getBranch()) {
            	setSigleValue(payment.getBranch(),pdfStamper, "Branchlcinsured");
            }
            }
        }

		//税收
		if (null != returnFormData.getLcappnt().getTaxtype()) {
			setSigleValue(returnFormData.getLcappnt().getAppntname(),pdfStamper, "taxinAppntName");
		}
		if (null != returnFormData.getLcinsured().getTaxtype()) {
			setSigleValue(returnFormData.getLcinsured().getLcinsuredname(),pdfStamper, "taxinLcinsuredName");
		}

		//医疗险不打印受益人
		if(!"11".equals(returnFormData.getLcpol().getConttype())){
			//受益人
			List<LcbnfVo> bnf = returnFormData.getBnf();
			if (bnf.isEmpty()) {
				setSigleValue("法定受益人", pdfStamper,
						"bnf[0].name");
			}
			int  bnfnum=0;
			for (LcbnfVo lcbnfVo : bnf) {
				//关系
				setSigleValue(ldcodeDao.selectLdcode("anzl_relation", lcbnfVo.getRelationtoinsured()).get(0)
						.getCodename(),pdfStamper, "bnf["+bnfnum+"].relationtoinsured");
				//证件类型
//        	setSigleValue(ldcodeDao.selectLdcode("idtype", lcbnfVo.getIdtype()).get(0)
//        			.getCodename().replaceAll("(.*?)\\/.*", "$1"),pdfStamper, "bnf["+bnfnum+"].idtype");
				//受益人证件有效期
				if ("9999-01-01".equals(lcbnfVo.getBnfvalidYear())){
					setSigleValue("长期", pdfStamper,
							"bnf["+bnfnum+"].bnfvalidYear");
				}
				// 身故受益人证件号码/换证次数
				if (StringUtils.isNotBlank(lcbnfVo.getRenewCount())){
					setSigleValue(lcbnfVo.getIdno()+"/"+lcbnfVo.getRenewCount(),pdfStamper,"bnf["+bnfnum+"].idno");
				}
				bnfnum++;
			}

		}


        /**
         * 告知详情打印  健康告知和其他告知2部分
         */
        List<SimpleNoticeInfo> noticedetails = returnFormData.getNoticedetails();
        int num=noticedetails.size()/2;
        //健康告知
        HashMap<String, String> hashMap1 = new HashMap<>();
        int number1 = 1;
        //其他告知
        HashMap<String, String> hashMap2 = new HashMap<>();
        //复杂告知和简单告知分开显示 投被保人身高体重、健康告知    SP简单告知  CP复杂告知   flage=""时不会打印在模板上所以没必要判断！=""时再填值到模板
        String flage = judgeSCorCP(returnFormData);
        int number2 = 1;
        //没有投保人
        if(null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(37) && StringUtils.isEmpty(returnFormData.getNoticeinfos().get(37).getOwnerimpart())){
        	
        	for(int i1=0;i1<num;i1++){
//        		if(i1==0) {
//        			//主被保人
//        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname(),pdfStamper, "temp"+(i1+1));
//        		}else {
//        			setSigleValue(returnFormData.getLcinsuredmulti().get(i1-1).getLcinsuredname(),pdfStamper, "temp"+(i1+1));
//        		}
//        		setSigleValue(""+(i1+1),pdfStamper, "num"+(i1+1));//序号
				if (null != returnFormData.getNoticedetails() && null != returnFormData.getNoticedetails().get(i1) && StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i1).getNoticeinfo1())) {
					if (i1 == 0 && null != returnFormData.getLcinsured()) {
        				//主被保人
        				hashMap1.put(returnFormData.getLcinsured().getLcinsuredname(),returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}else if(null != returnFormData.getLcinsuredmulti()){
						hashMap1.put(returnFormData.getLcinsuredmulti().get(i1-1).getLcinsuredname(), returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}
				}
//        		setSigleValue(returnFormData.getNoticedetails().get(i1).getNoticeinfo1(),pdfStamper, "detail"+(i1+1));
        	}

        }else{
        	setSigleValue("1",pdfStamper, flage + "num1");//序号
			if (null != returnFormData.getLcappnt()){
				setSigleValue(returnFormData.getLcappnt().getAppntname(),pdfStamper, flage + "temp1");
			}
			if (null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(37)){
				setSigleValue(returnFormData.getNoticeinfos().get(37).getOwnerimpart(),pdfStamper, flage + "detail1");
			}
    		number1 = 2;
        	for(int i1=0;i1<num;i1++){
//        		if(i1==0) {
//        			//主被保人
//        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname(),pdfStamper, "temp"+(i1+1+1));
//        		}else {
//        			setSigleValue(returnFormData.getLcinsuredmulti().get(i1-1).getLcinsuredname(),pdfStamper, "temp"+(i1+1+1));
//        		}
//        		//setSigleValue("被保人"+(i1+1),pdfStamper, "temp"+(i1+1+1));
//        		setSigleValue(""+(i1+1+1),pdfStamper, "num"+(i1+1+1));//序号
        		if (null != returnFormData.getNoticedetails() && null != returnFormData.getNoticedetails().get(i1) && StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i1).getNoticeinfo1())) {
					if (i1==0) {
						hashMap1.put(returnFormData.getLcinsured().getLcinsuredname(), returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}else {
						hashMap1.put(returnFormData.getLcinsuredmulti().get(i1-1).getLcinsuredname(), returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}
				}
//        		setSigleValue(returnFormData.getNoticedetails().get(i1).getNoticeinfo1(),pdfStamper, "detail"+(i1+1+1));
        	}
        }
        
        //打印健康告知
        Iterator<Entry<String, String>> it1 = hashMap1.entrySet().iterator();
        while(it1.hasNext()) {
        	setSigleValue(""+number1,pdfStamper, flage + "num"+(number1));//序号
        	Entry<String, String> entry = it1.next();
        	setSigleValue(entry.getKey(), pdfStamper, flage + "temp"+(number1));
        	setSigleValue(entry.getValue(), pdfStamper, flage + "detail"+(number1));
        	number1++;
        }
        
        
        if(null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(38) && StringUtils.isEmpty(returnFormData.getNoticeinfos().get(38).getOwnerimpart())){
        	for(int i1=num;i1<noticedetails.size();i1++){
//        		if(i1==num) {
//        			//主被保人
//        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname(),pdfStamper, "other"+(i1+1-num));
//        		}else {
//        			setSigleValue(returnFormData.getLcinsuredmulti().get(i1-num-1).getLcinsuredname(),pdfStamper, "other"+(i1+1-num));
//        		}
//        		setSigleValue(""+(i1+1-num),pdfStamper, "newnum"+(i1+1-num));//序号
        		if (StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i1).getNoticeinfo1())) {
        			if (i1==num) {
						hashMap2.put(returnFormData.getLcinsured().getLcinsuredname(), returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}else {
						hashMap2.put(returnFormData.getLcinsuredmulti().get(i1-num-1).getLcinsuredname(), returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}
					
				}
//        		setSigleValue(returnFormData.getNoticedetails().get(i1).getNoticeinfo1(),pdfStamper, "otherdetail"+(i1+1-num));
        	}
        }else{
        	setSigleValue("1",pdfStamper, "newnum1");//序号
			 if (null != returnFormData.getLcappnt()){
			 	setSigleValue(returnFormData.getLcappnt().getAppntname(),pdfStamper, "other1");//其他告知投保人
			 }
        	if (null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(38)){
        		setSigleValue(returnFormData.getNoticeinfos().get(38).getOwnerimpart(),pdfStamper, "otherdetail1");
			}
    		number2 = 2;
        	for(int i1=num;i1<noticedetails.size();i1++){
//        		if(i1==num) {
//        			//主被保人
//        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname(),pdfStamper, "other"+(i1+1+1-num));
//        		}else {
//        			setSigleValue(returnFormData.getLcinsuredmulti().get(i1-num-1).getLcinsuredname(),pdfStamper, "other"+(i1+1+1-num));
//        			
//        		}
        		//setSigleValue("被保人"+(i1+1-num),pdfStamper, "other"+(i1+1+1-num));
//        		setSigleValue(""+(i1+1+1-num),pdfStamper, "newnum"+(i1+1+1-num));//序号
        		if (null != returnFormData.getNoticedetails() && null != returnFormData.getNoticedetails().get(i1) && StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i1).getNoticeinfo1())) {
					if (i1==num) {
						hashMap2.put(returnFormData.getLcinsured().getLcinsuredname(), returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}else {
						hashMap2.put(returnFormData.getLcinsuredmulti().get(i1-num-1).getLcinsuredname(), returnFormData.getNoticedetails().get(i1).getNoticeinfo1());
					}
				}
//        		setSigleValue(returnFormData.getNoticedetails().get(i1).getNoticeinfo1(),pdfStamper, "otherdetail"+(i1+1+1-num));
        	}
        }
        
      //打印其他告知
        Iterator<Entry<String, String>> it2 = hashMap2.entrySet().iterator();
        while(it2.hasNext()) {
        	setSigleValue(""+number2,pdfStamper, "newnum"+(number2));//序号
        	Entry<String, String> entry = it2.next();
        	setSigleValue(entry.getKey(), pdfStamper, "other"+(number2));
        	setSigleValue(entry.getValue(), pdfStamper, "otherdetail"+(number2));
        	number2++;
        }

        //复杂告知和简单告知分开显示 投被保人身高体重    SP简单告知  CP复杂告知
        if (null != returnFormData.getLcinsured() && null != returnFormData.getLcinsured().getStature() && null != returnFormData.getLcinsured().getAvoirdupois()) {
            setSigleValue(String.valueOf(returnFormData.getLcinsured().getStature()), pdfStamper, flage + "lcinsured.stature");
            setSigleValue(String.valueOf(returnFormData.getLcinsured().getAvoirdupois()), pdfStamper, flage + "lcinsured.avoirdupois");
        }
		i = 0;
		for (LcinsuredTwoVo lcinsuredTwoVo : returnFormData.getLcinsuredmulti()) {
			if (null != lcinsuredTwoVo && null != lcinsuredTwoVo.getStature() && null != lcinsuredTwoVo.getAvoirdupois()) {
				setSigleValue(String.valueOf(lcinsuredTwoVo.getStature()), pdfStamper, flage + "lcinsuredmulti[" + i + "].stature");
				setSigleValue(String.valueOf(lcinsuredTwoVo.getAvoirdupois()), pdfStamper, flage + "lcinsuredmulti[" + i + "].avoirdupois");
			}
			i++;
		}
        if (null != returnFormData.getLcappnt() && null != returnFormData.getLcappnt().getStature() && null != returnFormData.getLcappnt().getAvoirdupois()) {
            setSigleValue(String.valueOf(returnFormData.getLcappnt().getStature()), pdfStamper, flage + "lcappnt.stature");
            setSigleValue(String.valueOf(returnFormData.getLcappnt().getAvoirdupois()), pdfStamper, flage + "lcappnt.avoirdupois");
        }
        
	}

	/**
     * 判断投配置的是简单告知还是复杂告知
     * 判断逻辑为：根据配置的告知，最终在告知页面上要显示的告知来判断
     * notice1~notice9告知配置为显示为简单告知  （即elementstatus=="01"显示告知 "02"不显示告知）
     * notice10~notice39（不含notice34、notice35）告知配置为显示为复杂告知
     * @formdata
     * @return   "SP"简单告知  "CP"复杂告知  ""不显示告知 （不存在同时配置了简单告知和复杂告知的情况）
     */
    public String judgeSCorCP(ContFormData formdata) {
        String flage = "";

        logger.info("投保单打印查询告知 元素，判断为简单告知还是复杂告知（多被保人版）");
        // 查询出告知页面的元素
        String combindid = "";
        //年金/生存金是否需要转入万能账户,选是出固定复杂告知
        if (StringUtils.isNotBlank(formdata.getLcpol().getWhetherconvert()) && "Y".equals(formdata.getLcpol().getWhetherconvert())) {
            logger.info("年金/生存金是否需要转入万能账户不为空且为 Y固定复杂告知 PC， Whetherconvert="+formdata.getLcpol().getWhetherconvert());
            //选了转万能后，出固定复杂告知（数据库新配置一套） combinedid='complexnotification'
            combindid = StringUtils.isNotBlank(formdata.getLccont().getAxaPdfName()) ?
                    formdata.getLccont().getAxaPdfName() : formdata.getNewContApply().getNoticeCombineID();
        } else {
            NoticeFormData noticeFormData = new NoticeFormData();
            noticeFormData.setInsurancecom(NewContStaticStr.ANZLinsucom);//保险公司代码
            noticeFormData.setMainriskcode(formdata.getLcpol().getRiskcode());
            String additionRiskCode = "";
            Set<String> riskcodeset = new HashSet<String>();

            for (lcpolVo additionlcpol : formdata.getSublcpols()) {
            	//前面为了正常打印投保计划部分，将Sublcpols大小固定为21，用null对象填充过，所以这里要根据不为null的元素来判断附加险个数
                if (additionlcpol.getRiskcode() != null) {
                    if (riskcodeset.contains(additionlcpol.getRiskcode())) {
                        continue;
                    } else {
                        riskcodeset.add(additionlcpol.getRiskcode());
                    }
					if (additionRiskCode == "") {
                    	additionRiskCode = additionlcpol.getRiskcode();
					}else{
                    	additionRiskCode = additionRiskCode + "," + additionlcpol.getRiskcode();
					}
				}
            }
            noticeFormData.setAdditionRiskCode(additionRiskCode);

            logger.info("additionRiskCode:"+additionRiskCode);
            combindid = "N/A";
            try {
                combindid = impartConfigService.queryCombinecode(noticeFormData);
            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
                combindid = "N/A";
            }
        }
        
		List<FormElement> list = formelementMapper.selNoticeFormelement(
				NewContStaticStr.ANZLinsucom + NewContStaticStr.CONT_NOTICE, combindid);
		logger.info("list:"+ JSONArray.fromObject(list));
		for (int i = 0; i < list.size(); i++) {
			FormElement element = list.get(i);
			if ("ParentElement".equals(element.getType())&&"01".equals(element.getElementstatus())) { // 告知项
			    int num = Integer.valueOf(element.getId().substring(6));
                if (1 <= num && num <= 9) {
                	logger.info("SPnum:"+ num+" ---"+element.getId());
                    flage = "SP";
                    break;//存在一个简单告知项被配置为显示，结束循环，结果为简单告知
                } else if (10 <= num && num <= 39 && num != 34 && num != 35) {
                	logger.info("CPnum:"+ num+" ---"+element.getId());
                    flage = "CP";//存在一个复杂告知项被配置为显示，结束循环，结果为复杂告知
                    break;
                }
			}
		}
		logger.info("combindid:"+combindid+"  flage:"+flage);
		return flage;
    }
}
