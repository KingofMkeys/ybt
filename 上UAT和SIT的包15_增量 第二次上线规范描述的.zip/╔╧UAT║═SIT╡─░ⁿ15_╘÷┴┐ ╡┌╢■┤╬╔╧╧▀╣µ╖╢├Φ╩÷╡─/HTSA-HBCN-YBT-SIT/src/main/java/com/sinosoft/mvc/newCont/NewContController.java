package com.sinosoft.mvc.newCont;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.alibaba.fastjson.JSON;
import com.sinosoft.bean.common.VueForm;
import com.sinosoft.bean.newCont.ContFormData;
import com.sinosoft.bean.newCont.NewContStaticStr;
import com.sinosoft.bean.newCont.data.ApplyBean;
import com.sinosoft.common.util.NewContUtil;
import com.sinosoft.core.common.aoputil.NewContStatusCheck;
import com.sinosoft.core.common.util.CommonUtil;
import com.sinosoft.eservice.api.bean.MessageBean;
import com.sinosoft.eservice.api.bean.UserLoginInfoBean;
import com.sinosoft.eservice.framework.interceptor.RepeatSubmit;
import com.sinosoft.service.api.PubFun;
import com.sinosoft.service.business.db.dao.*;
import com.sinosoft.service.business.db.dao.axa.AxaIpsMapper;
import com.sinosoft.service.business.db.dao.axa.PartyMapper;
import com.sinosoft.service.business.db.dao.axa.PremiumCalculationDtoMapper;
import com.sinosoft.service.business.db.vo.*;
import com.sinosoft.service.business.db.vo.axa.AxaIps;
import com.sinosoft.service.business.db.vo.axa.CmiParty;
import com.sinosoft.service.business.db.vo.axa.PremiumCalculationDto;
import com.sinosoft.service.business.ui.Ips.IPSDataServiceImpl;
import com.sinosoft.service.business.ui.Ips.IPSJsonSend;
import com.sinosoft.service.business.ui.Ips.IPSUtils;
import com.sinosoft.service.business.ui.Ips.bean.Items;
import com.sinosoft.service.business.ui.Ips.bean.Quotation;
import com.sinosoft.service.business.ui.Ips.bean.QuoteId;
import com.sinosoft.service.business.ui.dailyreconciliation.RetNewPayAndChange1;
import com.sinosoft.service.business.ui.newcont.service.NewContEnterService;
import com.sinosoft.service.newCont.NewContGetSidData;
import com.sinosoft.service.newCont.NewContInitPage;
import com.sinosoft.service.newCont.NewContSaveOrUpdate;
import com.sinosoft.service.newCont.RegisterNewContop;
import com.sinosoft.service.newCont.impl.ANZL.ANZLLcbnfOpService;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import tk.mybatis.mapper.entity.Example;

/***
 * 投保单 常规操作
 *
 * @author CDK @date： 日期：2018年5月3日 时间：下午2:18:02
 * @version 1.0
 */
@Controller
@RequestMapping("/newCont/common")
public class NewContController {

    protected static final Logger LOG = LoggerFactory.getLogger(NewContController.class);
    @Resource
    private RegisterNewContop registerNewContop;

    @Autowired
    private NewContEnterDao newContEnterDao;
    @Autowired
    private PNewContEnterDao PnewContEnterDao;

    @Resource
    private IPSJsonSend iPSJsonSend;
    @Resource
    private NewContStatusCheck newContStatusCheck;

    @Resource
    private IPSDataServiceImpl ipsDataServiceImpl;

    @Autowired
    private LdPathDao ld;

    @Autowired
    lcpolVoMapper lcpolVoMapper;
    @Autowired
    PlcpolVoMapper PlcpolVoMapper;

    @Autowired
    private NewContEnterService newContEnterService;

    @Autowired
    private AxaIpsMapper axaipsMapper;

    @Autowired
    private PremiumCalculationDtoMapper premiumCalculationDtoMapper;

    @Autowired
    private PartyMapper partyMapper;

    @Autowired
    private PNewContEnterDao preContDao;
    
	@Autowired
	private LmriskDao lmriskDao;

//	private static volatile int a = 1;

    /**
     * 保单基本信息初始化
     *
     * @param request
     * @return
     */
    @RequestMapping("/init/{SID}/{insurancecom}/{transno}")
    @ResponseBody
    public VueForm newContInit(HttpServletRequest request, @PathVariable String transno, @PathVariable String SID,
                               @PathVariable String insurancecom) {
        VueForm returnVueForm = new VueForm();

        ContFormData contFormData = JSON.parseObject(request.getParameter("formdata"), ContFormData.class);

        if (contFormData != null) {

        } else {
            ContFormData formData = new ContFormData();
            contFormData = formData;
        }
        returnVueForm.setFormdata(contFormData);
        try {
            @SuppressWarnings("unchecked")
            NewContInitPage<ContFormData> initPage = (NewContInitPage<ContFormData>) registerNewContop
                    .getInitServiceByID(insurancecom + SID);
            if (initPage != null) {

                if (!NewContStaticStr.CONT_APPLY.equals(SID)) {
                    returnVueForm.setFormdata(getAllFormData(request, transno, insurancecom, returnVueForm));

                }
                returnVueForm = initPage.initPage(request, transno, insurancecom, returnVueForm, contFormData);
            } else {
                if ("contsubmit".equals(SID)) {
                    returnVueForm.setFormdata(getAllFormData(request, transno, insurancecom, returnVueForm));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();

        }

        return returnVueForm;
    }

    @PostConstruct
    public void init() {
        System.setProperty("fastjson.compatibleWithJavaBean", "true");
        JSON.DEFFAULT_DATE_FORMAT = "yyyy-MM-dd";
    }

    @Resource
    ANZLLcbnfOpService anzlLcbnfOpService;

    /**
     * 保单基本信息保存修改
     * @param request
     * @return
     */
    @RequestMapping("/saveOrUpdate/{SID}/{insurancecom}/{transno}")
    @ResponseBody
    @RepeatSubmit //自定义注解防止表单重复提交
    public VueForm newContSaveOrUpdate(HttpServletRequest request, @PathVariable String transno,
                                       @PathVariable String SID, @PathVariable String insurancecom) {
        // insurancecom="ANZL";
        // transno = "908878";

        VueForm returnVueForm = new VueForm();
        returnVueForm.setFormdata(new ContFormData());
        ContFormData contFormData = JSON.parseObject(request.getParameter("formdata"), ContFormData.class);
        //
        returnVueForm.setFormdata(contFormData);
        @SuppressWarnings("unchecked")
        NewContSaveOrUpdate<ContFormData> contSaveOrUpdate = (NewContSaveOrUpdate<ContFormData>) registerNewContop
                .getSaveOrUpdateServiceByID(insurancecom + SID);
        // 试算状态检测
        VueForm vueFormTemp = newContStatusCheck.newContSaveOrupdateControl(request, transno, insurancecom,
                returnVueForm, contFormData);
        if (vueFormTemp != null && vueFormTemp.getFormstatus() != null && !vueFormTemp.getFormstatus().getFlag()) {
            return vueFormTemp;
        }

        returnVueForm = contSaveOrUpdate.saveOrUpdate(request, transno, insurancecom, returnVueForm, contFormData);
        //
        if (returnVueForm.getFormstatus().getFlag()) {
            @SuppressWarnings("unchecked")
            NewContSaveOrUpdate<ContFormData> lccontSaveOrUpdate = (NewContSaveOrUpdate<ContFormData>) registerNewContop
                    .getSaveOrUpdateServiceByID(insurancecom + NewContStaticStr.LCCONTSID);
            lccontSaveOrUpdate.saveOrUpdate(request, transno, insurancecom, returnVueForm, contFormData);
        }
        return returnVueForm;
    }

    /**
     * 保单基本信息获取
     *
     * @param request
     * @return
     */
    @RequestMapping("/getContInfo/{SID}/{insurancecom}/{transno}")
    @ResponseBody
    public VueForm newContGetData(HttpServletRequest request, @PathVariable String transno, @PathVariable String SID,
                                  @PathVariable String insurancecom) {
        VueForm returnVueForm = new VueForm();
        returnVueForm.setFormdata(new ContFormData());
        ContFormData contFormData = JSON.parseObject(request.getParameter("formdata"), ContFormData.class);

        returnVueForm.setFormdata(contFormData);

        @SuppressWarnings("unchecked")
        NewContGetSidData<ContFormData> contGetSidData = (NewContGetSidData<ContFormData>) registerNewContop
                .getDataServiceByID(insurancecom, SID);

        returnVueForm = contGetSidData.getSidData(request, transno, insurancecom, returnVueForm, contFormData);
        return returnVueForm;
    }


    @RequestMapping("/getAllFormDataByProposalcontno")
    @ResponseBody
    public ContFormData getAllFormDataByProposalcontno(HttpServletRequest request, String proposalcontno) {


        LCContVo lccontVo = newContEnterDao.selectLccontToProposalcontno(proposalcontno);
        /*	VueForm returnVueForm = new VueForm();*/

        ContFormData contFormData = new ContFormData();
        lccontVo.setTransno(null);
        lccontVo.setProposalcontno(null);
        lccontVo.setContno(null);
        lccontVo.setAppflag("01");//01=未试算状态
        lccontVo.setState("00");//默认00
        lccontVo.setFirsttrialtime(null);//扣款日期
        lccontVo.setForceuwflag("0");//强制人工核保标记 默认=0
        lccontVo.setCardflag(null);
        lccontVo.setExecutecom(null);
        lccontVo.setHandler(null);
        lccontVo.setFamilyid(null);
        lccontVo.setFamilytype(null);
        lccontVo.setDelayeddebit(null);
        lccontVo.setSumprem(null);
        lccontVo.setFinalproposalcontno(null);
        lccontVo.setEffectiveDate(null);
        lccontVo.setTermdate(null);
        lccontVo.setFirstpaymentdate(null);
        lccontVo.setFinalpaymentdate(null);
        lccontVo.setPolreceiptDate(null);//回执日期
        lccontVo.setCvalidate(null);//生效日期
        lccontVo.setAccountbalance(null);
        lccontVo.setDeductionstype(null);
        lccontVo.setConttype("1");
        lccontVo.setPayexpirydate(null);
        lccontVo.setConttype("1");//保单类型 默认=1
        lccontVo.setChargecode("W");//扣款状态=W=未扣款
        lccontVo.setHesitationflag("0");//犹豫期退保标记
        lccontVo.setDebitflag("0");//扣款标记 0=实时
        lccontVo.setPaylocation("1");// 续期缴费方案 1->自动转账
        lccontVo.setNewpaymode("1");// 首期缴费方案 1->自动转账
        lccontVo.setPageflag("0");//页面状态
        lccontVo.setRecording("N");//补录标记 设置为非补录
        lccontVo.setOrderID(null);
        lccontVo.setReportID(null);
        lccontVo.setRecordID(null);
        lccontVo.setFPRID(null);
        lccontVo.setPrdTypeCode(null);
        lccontVo.setPrdSubTypeCode(null);
        lccontVo.setPrdAlternativeNumber(null);
        lccontVo.setPrdClassificationCode(null);
        lccontVo.setCountryTradableCode(null);
        lccontVo.setCustomerIndicator(null);
        lccontVo.setIsshutdown(null);
        lccontVo.setPipelineflag(null);//pipeline标志
        lccontVo.seteSignFlag(null);
        lccontVo.setPerIncome(null);
        lccontVo.setIsOvertop(null);
        lccontVo.setRpqflag(null);
        lccontVo.setCommonchannel(null);
        contFormData.setLccont(lccontVo);
    /*	ApplyBean newContApply = new ApplyBean();
    	
    	returnVueForm.setFormdata(contFormData);
      
		LCContVo lccont = newContEnterDao.selectLccontToProposalcontno(proposalcontno);
		
		newContApply.setTransno(lccont.getTransno());
		newContApply.setInsurancecom(lccont.getInsurancecom());
		newContApply.setRiskcode(lccont.getRiskcode());
		newContApply.setGrpcontno(lccont.getGrpcontno());
    	
    	if(lccont!=null&&"DG".equals(lccont.getCommonchannel())){
			newContApply.setRiskcode(lccont.getRiskcode());
			UserLoginInfoBean tUserLoginInfo =new UserLoginInfoBean();
			
			tUserLoginInfo.setEmplID(lccont.getOperator());
			tUserLoginInfo.setCompanyCode(lccont.getManagecom());
			request.getSession().setAttribute("userLoginInfo", tUserLoginInfo); 
		}
       	contFormData.setNewContApply(newContApply);
	
		contFormData =getAllFormData(request, lccont.getTransno(), lccont.getInsurancecom(), returnVueForm);
		LCContVo lccontVo = contFormData.getLccont();
		lccontVo.setTransno(null);
		lccontVo.setProposalcontno(null);
		lccontVo.setContno(null);
		lccontVo.setAppflag("01");//01=未试算状态
		lccontVo.setState("00");//默认00
		lccontVo.setFirsttrialtime(null);//扣款日期
		lccontVo.setForceuwflag("0");//强制人工核保标记 默认=0
		lccontVo.setCardflag(null);
		lccontVo.setExecutecom(null);
		lccontVo.setHandler(null);
		lccontVo.setFamilyid(null);
		lccontVo.setFamilytype(null);
		lccontVo.setDelayeddebit(null);
		lccontVo.setSumprem(null);
		lccontVo.setFinalproposalcontno(null);
		lccontVo.setEffectiveDate(null);
		lccontVo.setTermdate(null);
		lccontVo.setFirstpaymentdate(null);
		lccontVo.setFinalpaymentdate(null);
		lccontVo.setPolreceiptDate(null);//回执日期
		lccontVo.setCvalidate(null);//生效日期
		lccontVo.setAccountbalance(null);
		lccontVo.setDeductionstype(null);
		lccontVo.setConttype("1");
		lccontVo.setPayexpirydate(null);
		lccontVo.setConttype("1");//保单类型 默认=1
		lccontVo.setChargecode("W");//扣款状态=W=未扣款
		lccontVo.setHesitationflag("0");//犹豫期退保标记
		lccontVo.setDebitflag("0");//扣款标记 0=实时
		lccontVo.setPaylocation("1");// 续期缴费方案 1->自动转账
		lccontVo.setNewpaymode("1");// 首期缴费方案 1->自动转账
		lccontVo.setPageflag("0");//页面状态
		lccontVo.setRecording("N");//补录标记 设置为非补录
		lccontVo.setOrderID(null);
		lccontVo.setReportID(null);
		lccontVo.setRecordID(null);
		lccontVo.setFPRID(null);
		lccontVo.setPrdTypeCode(null);
		lccontVo.setPrdSubTypeCode(null);
		lccontVo.setPrdAlternativeNumber(null);
		lccontVo.setPrdClassificationCode(null);
		lccontVo.setCountryTradableCode(null);
		lccontVo.setCustomerIndicator(null);
		lccontVo.setIsshutdown(null);
		lccontVo.setPipelineflag(null);//pipeline标志
		lccontVo.seteSignFlag(null);
		lccontVo.setPerIncome(null);
		lccontVo.setIsOvertop(null);
		lccontVo.setRpqflag(null);
		lccontVo.setCommonchannel(null);
		contFormData.setLccont(lccontVo);*/

//    	contFormData =newContController.getAllFormData(request, transno, insurancecom, returnVueForm);

        return contFormData;
    }


    public ContFormData getAllFormData(HttpServletRequest request, String transno, String insurancecom,
                                       VueForm returnVueForm) {

    
        ContFormData formdata = (ContFormData) returnVueForm.getFormdata();
        boolean useIPSflag_lcinsured = false; // 是否使用被保人IPS 数据
        boolean useIPSflag_krisk = false; // 是否使用主险IPS 数据
        boolean useIPSflag_subrisk = false; // 是否使用附加险IPS 数据
        
        //纸质入口ips赋值 
    	if(insurancecom.indexOf("PAPER")>0){
    		System.out.println("纸质入口ips赋值  PAPER ips  insurancecom===="+insurancecom);
    		
    		
    		//预录新表 
    		
            int subrisksize = PlcpolVoMapper.selectByTransno1(transno, "S").size();
            // 查询投保人是否已经入库
            LCContVo lccontVo = PnewContEnterDao.selectBylccont(transno);

            ContFormData contFormDataTempIPS = new ContFormData();
            List<String> emptyDataList = new ArrayList<String>();
            ApplyBean applbean = formdata.getNewContApply();

            String ipsno = null;
            String isUnionAccount = null;
            if (formdata.getLccont() == null || !NewContUtil.validTransNo(transno)
                    || !NewContUtil.validTransNo(formdata.getLccont().getTransno())) {

                emptyDataList.add(NewContStaticStr.LCCONTSID);
            }

            if (formdata.getLcappnt() == null || !NewContUtil.validTransNo(transno)
                    || formdata.getLcappnt().getIdno() == null
                    || !NewContUtil.validTransNo(formdata.getLccont().getTransno())) {
                emptyDataList.add(NewContStaticStr.APPNTSID);
            }

            if (NewContUtil.validTransNo(transno)) {
                if (subrisksize == 0) {
                    useIPSflag_subrisk = true;
                }
                if (formdata.getLcinsured() == null || formdata.getLcinsured().getLcinsuredidno() == null) {
                    emptyDataList.add(NewContStaticStr.INSUREDSID);
                    useIPSflag_lcinsured = true;
                    // IPS直连
                }
                /*
                if ((formdata.getBnf().size() == 0 || formdata.getBnf().get(0).getIdno() == null)) {
                    emptyDataList.add(NewContStaticStr.LCBNFSID);
                }
                 */
                if (formdata.getLcpol() == null) {
                    emptyDataList.add(NewContStaticStr.LCPOLSID);
                }
                if (formdata.getLcpol() == null || formdata.getLcpol().getRiskcode() == null) {
                    useIPSflag_krisk = true;
                }

                if (formdata.getSublcpols().size() == 0) {
                    emptyDataList.add(NewContStaticStr.SUBLCPOLSID);
                } else {
                    if (formdata.getSublcpols().size() == 1
                            && CommonUtil.isEmpty(formdata.getSublcpols().get(0).getRiskcode())) {
                        emptyDataList.add(NewContStaticStr.SUBLCPOLSID);
                        useIPSflag_subrisk = true;
                        // IPS直连
                    }
                }

                 if (formdata.getTaxtins_lcinsured().size() == 0) {
                    emptyDataList.add(NewContStaticStr.CONT_FATACACRS);
                }
                 /*
                if (formdata.getNoticeinfos().size() == 0) {
                    emptyDataList.add(NewContStaticStr.CONT_NOTICE);
                    emptyDataList.add(NewContStaticStr.OtherInsuNotice);
                }*/
                if ("1".equals(formdata.getEsginInfoFlag())) {

                    emptyDataList.add(NewContStaticStr.ESIGN);
                    formdata.setEsginInfoFlag("0");

                }
            } else {

                // IPS直连 发送信息获取字段

                Quotation quotation = null;

                try {

                    UserLoginInfoBean tUserLoginInfo = (UserLoginInfoBean) request.getSession()
                            .getAttribute("userLoginInfo");
                    QuoteId quoteId = new QuoteId();

                    if (applbean.getApplicationId() != null) {
                        quoteId.setApplicationReferenceNumber(applbean.getApplicationId());
                        quoteId.setQuotationInternalReferenceNumber(applbean.getQuotationId());
                        //发请求查询改为从库中查询IPS
                        quotation = IPSUtils.readFromSql(applbean.getQuotationId(), applbean.getApplicationId());
//                    quotation = iPSJsonSend.JsonSend(tUserLoginInfo.getEmplID(), quoteId);
                        List<Items> items = quotation.getItems();

                        for (Items item : items) {
                            if ("EXTL_PROP_ID".equals(item.getKey())) {

                                ipsno = item.getValue();

                            }
                            if ("IS_UNION_ACCOUNT".equals(item.getKey()) && "1".equals(item.getValue())) {
                                isUnionAccount = "Y";
                            }
                        }

                        useIPSflag_lcinsured = false; // 是否使用被保人IPS 数据
                        useIPSflag_krisk = true; // 是否使用主险IPS 数据
                        useIPSflag_subrisk = true; // 是否使用附加险IPS 数据
                    }


                } catch (Exception e) {

                    System.out.println("IPS error" + e.getMessage() + "" + applbean.getApplicationId());

                }

            }

            for (String SID : emptyDataList) {

                @SuppressWarnings("unchecked")
                NewContGetSidData<ContFormData> contGetSidData = (NewContGetSidData<ContFormData>) registerNewContop
                        .getDataServiceByID(insurancecom, SID);

                System.out.println(" 开始获取  SID 数据: " + SID);
                
           /*     if(null!=insurancecom){
                		insurancecom=insurancecom.replaceAll("PAPER", "");
                }
                */
                if (contGetSidData != null) {
                    returnVueForm = contGetSidData.getSidData(request, transno, insurancecom, returnVueForm,
                            (ContFormData) returnVueForm.getFormdata());
                }

            }

            String pageflag = formdata.getLccont().getPageflag();
            String appflag = formdata.getLccont().getAppflag();
            // 试算通过不调用ips方法
            if (StringUtils.isNotBlank(appflag) && !"01".equals(appflag) && !"10".equals(appflag)) {
                useIPSflag_lcinsured = false; // 是否使用被保人IPS 数据
                useIPSflag_krisk = false; // 是否使用主险IPS 数据
                useIPSflag_subrisk = false; // 是否使用附加险IPS 数据
            }

            try {

                if (applbean.getIpsNo() != null && StringUtils.isNotEmpty(applbean.getIpsNo())) {

                    //AXA报价查询
                    AxaIps axaIps = axaipsMapper.selectByPrimaryKey(applbean.getIpsNo());
                    //@AM和@AS存值
                    Example example = new Example(PremiumCalculationDto.class);
                    example.createCriteria().andEqualTo("axano", applbean.getIpsNo());
                    List<PremiumCalculationDto> premiumCalculationDto = premiumCalculationDtoMapper.selectByExample(example);
                    //@IC存被保人信息
                    Example example1 = new Example(CmiParty.class);
                    example1.createCriteria().andEqualTo("axano", applbean.getIpsNo());
                    List<CmiParty> cmiParties = partyMapper.selectByExample(example1);

                    if (axaIps.getName() != null) {

                        System.out.println("AXAIPS 数据插入----------------");

                        ContFormData contFormData = (ContFormData) returnVueForm.getFormdata();
                        contFormData.getLccont().setIpsno(applbean.getIpsNo());
                        if ("@IC".equals(axaIps.getRiskcode()) || "@PA".equals(axaIps.getRiskcode())) {
                            if (contFormData.getLcpol() != null && StringUtils.isEmpty(contFormData.getLcpol().getProposalno())) {
                                if (axaIps.getInsurancebegintime().after(new Date())) {
                                    contFormData.getLccont().setCvalidate(axaIps.getInsurancebegintime());//保险起期
                                } else {
                                    contFormData.getLccont().setCvalidate(PubFun.getDate(RetNewPayAndChange1.calendar1(-1)));
                                }
                                contFormData.getLcpol().setPrem(axaIps.getPermium());
                                contFormData.getLcpol().setInsuyear("1Y");//保险期间
                                contFormData.getLcpol().setPlan(axaIps.getProductcode());
                                
                            }
                        } else {
                            if (StringUtils.isEmpty(contFormData.getAxalcappnt().getTransno())) {
                                contFormData.getAxalcappnt().setAgentcodeaxa(axaIps.getAgentcode());
                            }

                            if (contFormData.getLcpol() != null && StringUtils.isEmpty(contFormData.getLcpol().getProposalno())) {
                                if ("01".equals(axaIps.getCurrency())) {
                                    contFormData.getLccont().setCurrencytype("CNY");//人民币币种
                                } else if ("04".equals(axaIps.getCurrency())) {
                                    contFormData.getLccont().setCurrencytype("USD");//美元币种
                                }
                                contFormData.getLcpol().setPrem(axaIps.getPermium());//保费
                                contFormData.getLcpol().setInsuyear("1Y");//保险期间

                                if (axaIps.getInsurancebegintime().after(new Date())) {
                                    contFormData.getLccont().setCvalidate(axaIps.getInsurancebegintime());//保险起期
                                } else {
                                    contFormData.getLccont().setCvalidate(PubFun.getDate(RetNewPayAndChange1.calendar1(-1)));
                                }

                      

                            }
                        }


                    }
                }
                
                //insurancecom=insurancecom.replaceAll("PAPER", "");
                
                if ("MELIPAPER".equals(insurancecom) || "INSHPAPER".equals(insurancecom)|| "ANZLPAPER".equals(insurancecom) ||"PALIPAPER".equals(insurancecom)) {
                    System.out.println("useIPSflag_lcinsured=" + useIPSflag_lcinsured + " useIPSflag_krisk=" + useIPSflag_krisk
                            + " useIPSflag_subrisk=" + useIPSflag_subrisk);

                    // IPS 数据插入
                    if (useIPSflag_lcinsured || useIPSflag_krisk || useIPSflag_subrisk) {
                        System.out.println("IPS 数据插入----------------");
                        ContFormData contFormData = (ContFormData) returnVueForm.getFormdata();

                        // 第一次跳转时放入 IPS 的QuotationId
                        if (StringUtils.isNoneBlank(applbean.getQuotationId())) {
                            System.out.println("第一次SFP跳转时放入IPS的QuotationId----------------");
                            contFormData.getLccont().setQuotationId(applbean.getQuotationId());
                            contFormData.getLccont().setApplicationId(applbean.getApplicationId());
                            contFormData.getLccont().setShoppingCartIndicator(applbean.getShoppingCartIndicator());
                            contFormData.getLccont().setRemoteSalesIndicator(applbean.getRemoteSalesIndicator());
                            if ("Y".equals(applbean.getShoppingCartIndicator()) && "Y".equals(applbean.getRemoteSalesIndicator())) {
                                contFormData.getLccont().setCommonchannel("RS");
                            }
                            if ("N".equals(applbean.getShoppingCartIndicator()) && "Y".equals(applbean.getRemoteSalesIndicator())) {
                                contFormData.getLccont().setCommonchannel("RE");
                            }
                            if ("Y".equals(applbean.getShoppingCartIndicator()) && "N".equals(applbean.getRemoteSalesIndicator())) {
                                contFormData.getLccont().setCommonchannel("SC");
                            }
                            if ("N".equals(applbean.getShoppingCartIndicator()) && "N".equals(applbean.getRemoteSalesIndicator())) {
                                contFormData.getLccont().setCommonchannel("BH");
                            }
                            contFormData.getLccont().setIpsno(ipsno);
                            contFormData.getLccont().setIsUnionAccount(isUnionAccount);
                        } else {
                            System.out.println("操作页面放入IPS的QuotationId----------------");
                            if (lccontVo != null) {
                                contFormData.getLccont().setQuotationId(lccontVo.getQuotationId());
                                contFormData.getLccont().setApplicationId(lccontVo.getApplicationId());
                                contFormData.getLccont().setShoppingCartIndicator(lccontVo.getShoppingCartIndicator());
                                contFormData.getLccont().setRemoteSalesIndicator(lccontVo.getRemoteSalesIndicator());
                                if (null!=lccontVo.getIpsno()){
                                    contFormData.getLccont().setIpsno(lccontVo.getIpsno());
                                    System.out.println("操作页面IPS的ipsno:"+lccontVo.getIpsno());
                                }
                                if (null!=lccontVo.getIsUnionAccount()){
                                    contFormData.getLccont().setIsUnionAccount(lccontVo.getIsUnionAccount());
                                    System.out.println("操作页面IPS的isUnionAccount:"+lccontVo.getIsUnionAccount());
                                }
                            }
                        }

                        if (StringUtils.isNoneBlank(contFormData.getLccont().getApplicationId())
                                && StringUtils.isNoneBlank(contFormData.getLccont().getQuotationId())) {

                            QuoteId quoteId = new QuoteId();

                            quoteId.setApplicationReferenceNumber(contFormData.getLccont().getApplicationId());
                            quoteId.setQuotationInternalReferenceNumber(contFormData.getLccont().getQuotationId());
                            // 数据库查询出数据
                            System.out.println("newcontcontroller调用ipsDataServiceImpl-------");
                            contFormDataTempIPS = ipsDataServiceImpl.getSidData(quoteId, contFormData, insurancecom, pageflag,
                                    appflag);
                            if (contFormDataTempIPS.getQuotation() != null) {
                                contFormData.setQuotation(contFormDataTempIPS.getQuotation());
                            }
                            // 主被保人
                            if (contFormDataTempIPS.getLcinsured()!= null) {
                                contFormData.getLcappnt().setRelationtoappnt(contFormDataTempIPS.getLcinsured().getRelationtoappnt());
                            }
                            // 主险
                            if (contFormData.getLcpol() != null && StringUtils.isEmpty(contFormData.getLcpol().getProposalno())
                                    && contFormDataTempIPS.getLcpol() != null) {
                                contFormData.getLcpol().setPrem(contFormDataTempIPS.getLcpol().getPrem());
                                contFormData.getLcpol().setSumprem(contFormDataTempIPS.getLcpol().getSumprem());//首期保费

                                contFormData.getLcpol().setAmnt(contFormDataTempIPS.getLcpol().getAmnt());
                                contFormData.getLcpol().setType(contFormDataTempIPS.getLcpol().getType());
                                contFormData.getLcpol().setPayintv(contFormDataTempIPS.getLcpol().getPayintv());
                                contFormData.getLcpol().setGetyearflag(contFormDataTempIPS.getLcpol().getGetyearflag());
                                contFormData.getLcpol().setBonusgetmode(contFormDataTempIPS.getLcpol().getBonusgetmode());
                                contFormData.getLcpol().setSurvivalInsurancePeriod(
                                        contFormDataTempIPS.getLcpol().getSurvivalInsurancePeriod());
                                contFormData.getLcpol().setBonusgetage(contFormDataTempIPS.getLcpol().getBonusgetage());
                                contFormData.getLcpol().setBonusGetAgeFlag(NewContUtil.getRiskParamFlag(contFormDataTempIPS.getLcpol().getBonusgetage()));
                                contFormData.getLcpol().setSpecialsurvivalage(contFormDataTempIPS.getLcpol().getSpecialsurvivalage());
                                contFormData.getLcpol().setSpecialsurvivalageflag(NewContUtil.getRiskParamFlag(contFormDataTempIPS.getLcpol().getSpecialsurvivalage()));
                                contFormData.getLcpol().setExtragetyear(contFormDataTempIPS.getLcpol().getExtragetyear());
                                contFormData.getLcpol().setRegularaddflag(contFormDataTempIPS.getLcpol().getRegularaddflag());
                                contFormData.getLcpol().setRegularaddpayintv(contFormDataTempIPS.getLcpol().getRegularaddpayintv());
                                contFormData.getLcpol().setRegularaddprem(contFormDataTempIPS.getLcpol().getRegularaddprem());
                                contFormData.getLcpol().setRegularaddstartdate(contFormDataTempIPS.getLcpol().getRegularaddstartdate());
                                
                                //Y4、B9类 改成可配置化，配置了保险期间（年）输入框的产品赋值	
                        		List<LmriskparamsdefaVo> params=lmriskDao.QueryParam(contFormData.getLccont().getRiskcode(), "insuyearY4", "Y");            
                                if (params.size()>0) {
                                    String insuyear = contFormDataTempIPS.getLcpol().getInsuyear();
                                    insuyear = insuyear.substring(0, insuyear.length() - 1);
                                    contFormData.getLcpol().setInsuyearY4(insuyear);
                                } else {
                                    contFormData.getLcpol().setInsuyear(contFormDataTempIPS.getLcpol().getInsuyear());
                                }
                                contFormData.getLcpol().setPlan(contFormDataTempIPS.getLcpol().getPlan());
                                contFormData.getLcpol().setInvestmentstartdateflag(
                                        contFormDataTempIPS.getLcpol().getInvestmentstartdateflag());

                                contFormData.getLcpol().setPayendyear(contFormDataTempIPS.getLcpol().getPayendyear());
                                contFormData.getLcpol().setAnnuityincamnt(contFormDataTempIPS.getLcpol().getAnnuityincamnt());
                                // contFormData.setLcpol(contFormDataTempIPS.getLcpol());
                            }
                            // 附加险
                            if (StringUtils.isEmpty(contFormData.getLccont().getSublcpolflag())
                                    && contFormData.getSublcpols() != null && contFormDataTempIPS.getSublcpols() != null
                                    && contFormDataTempIPS.getSublcpols().size() > 0) {
                                List<lcpolVo> sublcpols = new ArrayList<>();
                                lcpolVo lcpolVo = null;
                                for (int i = 0; i < contFormDataTempIPS.getSublcpols().size(); i++) {
                                    if ("@RC".equals(contFormDataTempIPS.getSublcpols().get(i).getRiskcode())){
                                        lcpolVo= contFormDataTempIPS.getSublcpols().get(i);
                                    }else{
                                        sublcpols.add(contFormDataTempIPS.getSublcpols().get(i));
                                    }
                                }
                                //@RC放最后，特殊处理（因为告知必填校验，告知RC不是最后会失效）
                                if (null != lcpolVo){
                                    sublcpols.add(lcpolVo);
                                }
                                contFormData.setSublcpols(sublcpols);
                                LOG.info("contFormData Sublcpols json:" + JSON.toJSONString(contFormData.getSublcpols()));

                                //安联的附加险豁免险，如果被保人不是投保人的情况特殊处理（目前只支持有一个附加险豁免险，对应一个其他的被保人）
                                if (contFormDataTempIPS.getOtherinsured().size() > 0) {
                                    OtherInsuredVo otherInsuredVo = contFormDataTempIPS.getOtherinsured().get(0);
                                    if (contFormData.getOtherinsured().isEmpty()) {
                                        contFormData.getSublcpols().get(0).setOtherinsuredflag("Y");
                                        contFormData.getOtherinsured().add(otherInsuredVo);
                                    }
                                }

                            }
                        }

                    }
                }

            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
            }

    		
    		
    	}else{//新单录入


        
        
        int subrisksize = lcpolVoMapper.selectByTransno1(transno, "S").size();
        // 查询投保人是否已经入库
        LCContVo lccontVo = newContEnterService.selectBylccont(transno);

        ContFormData contFormDataTempIPS = new ContFormData();
        List<String> emptyDataList = new ArrayList<String>();
        ApplyBean applbean = formdata.getNewContApply();

        String ipsno = null;
        String isUnionAccount = null;
        if (formdata.getLccont() == null || !NewContUtil.validTransNo(transno)
                || !NewContUtil.validTransNo(formdata.getLccont().getTransno())) {

            emptyDataList.add(NewContStaticStr.LCCONTSID);
        }

        if (formdata.getLcappnt() == null || !NewContUtil.validTransNo(transno)
                || formdata.getLcappnt().getIdno() == null
                || !NewContUtil.validTransNo(formdata.getLccont().getTransno())) {
            emptyDataList.add(NewContStaticStr.APPNTSID);
        }


        Quotation quotation = null;

        try {

            QuoteId quoteId = new QuoteId();

            if (applbean.getApplicationId() != null) {
                quoteId.setApplicationReferenceNumber(applbean.getApplicationId());
                quoteId.setQuotationInternalReferenceNumber(applbean.getQuotationId());
                //发请求查询改为从库中查询IPS
                quotation = IPSUtils.readFromSql(applbean.getQuotationId(), applbean.getApplicationId());
//                    quotation = iPSJsonSend.JsonSend(tUserLoginInfo.getEmplID(), quoteId);
                ContFormData contFormData = (ContFormData) returnVueForm.getFormdata();
                contFormData.setQuotation(quotation);
                List<Items> items = quotation.getItems();

                for (Items item : items) {
                    if ("EXTL_PROP_ID".equals(item.getKey())) {
                        ipsno = item.getValue();
                        //contFormData.getLccont().setIpsno(ipsno);
                        LOG.info("IPS直连---------获取到ips数据中，IPSNO为:{}",ipsno);
                    }
                    if ("IS_UNION_ACCOUNT".equals(item.getKey()) && "1".equals(item.getValue())) {
                        isUnionAccount = "Y";
                        LOG.info("IPS直连---------获取到ips数据中，关联单标记为:{}",isUnionAccount);
                    }
                }
            }


        } catch (Exception e) {

            System.out.println("IPS error" + e.getMessage() + "" + applbean.getApplicationId());

        }

        if (NewContUtil.validTransNo(transno)) {
            if (subrisksize == 0) {
                useIPSflag_subrisk = true;
            }
            if (formdata.getLcinsured() == null || formdata.getLcinsured().getLcinsuredidno() == null) {
                emptyDataList.add(NewContStaticStr.INSUREDSID);
                useIPSflag_lcinsured = true;
                // IPS直连
            }
            if ((formdata.getBnf().size() == 0 || formdata.getBnf().get(0).getIdno() == null)) {
                emptyDataList.add(NewContStaticStr.LCBNFSID);
            }

            if (formdata.getLcpol() == null) {
                emptyDataList.add(NewContStaticStr.LCPOLSID);
            }
            if (formdata.getLcpol() == null || formdata.getLcpol().getRiskcode() == null) {
                useIPSflag_krisk = true;
            }

            if (formdata.getSublcpols().size() == 0) {
                emptyDataList.add(NewContStaticStr.SUBLCPOLSID);
            } else {
                if (formdata.getSublcpols().size() == 1
                        && CommonUtil.isEmpty(formdata.getSublcpols().get(0).getRiskcode())) {
                    emptyDataList.add(NewContStaticStr.SUBLCPOLSID);
                    useIPSflag_subrisk = true;
                    // IPS直连
                }
            }

            if (formdata.getTaxtins_lcinsured().size() == 0) {
                emptyDataList.add(NewContStaticStr.CONT_FATACACRS);
            }

            if (formdata.getNoticeinfos().size() == 0) {
                emptyDataList.add(NewContStaticStr.CONT_NOTICE);
                emptyDataList.add(NewContStaticStr.OtherInsuNotice);
            }
            if ("1".equals(formdata.getEsginInfoFlag())) {

                emptyDataList.add(NewContStaticStr.ESIGN);
                formdata.setEsginInfoFlag("0");

            }
        } else {

            // IPS直连 发送信息获取字段
            if(null!=quotation){
                useIPSflag_lcinsured = true; // 是否使用被保人IPS 数据
                useIPSflag_krisk = true; // 是否使用主险IPS 数据
                useIPSflag_subrisk = true; // 是否使用附加险IPS 数据
            }


        }

        for (String SID : emptyDataList) {

            @SuppressWarnings("unchecked")
            NewContGetSidData<ContFormData> contGetSidData = (NewContGetSidData<ContFormData>) registerNewContop
                    .getDataServiceByID(insurancecom, SID);

            System.out.println(" 开始获取  SID 数据: " + SID);
            if (contGetSidData != null) {
                returnVueForm = contGetSidData.getSidData(request, transno, insurancecom, returnVueForm,
                        (ContFormData) returnVueForm.getFormdata());
            }

        }

        String pageflag = formdata.getLccont().getPageflag();
        String appflag = formdata.getLccont().getAppflag();
        // 试算通过不调用ips方法
        if (StringUtils.isNotBlank(appflag) && !"01".equals(appflag) && !"10".equals(appflag)) {
            useIPSflag_lcinsured = false; // 是否使用被保人IPS 数据
            useIPSflag_krisk = false; // 是否使用主险IPS 数据
            useIPSflag_subrisk = false; // 是否使用附加险IPS 数据
        }

        try {

            if (applbean.getIpsNo() != null && StringUtils.isNotEmpty(applbean.getIpsNo())) {

                //AXA报价查询
                AxaIps axaIps = axaipsMapper.selectByPrimaryKey(applbean.getIpsNo());
                //@AM和@AS存值
                Example example = new Example(PremiumCalculationDto.class);
                example.createCriteria().andEqualTo("axano", applbean.getIpsNo());
                List<PremiumCalculationDto> premiumCalculationDto = premiumCalculationDtoMapper.selectByExample(example);
                //@IC存被保人信息
                Example example1 = new Example(CmiParty.class);
                example1.createCriteria().andEqualTo("axano", applbean.getIpsNo());
                List<CmiParty> cmiParties = partyMapper.selectByExample(example1);

                if (axaIps.getName() != null) {

                    System.out.println("AXAIPS 数据插入----------------");

                    ContFormData contFormData = (ContFormData) returnVueForm.getFormdata();
                    contFormData.getLccont().setIpsno(applbean.getIpsNo());
                    if ("@IC".equals(axaIps.getRiskcode()) || "@PA".equals(axaIps.getRiskcode())) {
                        if (contFormData.getLcpol() != null && StringUtils.isEmpty(contFormData.getLcpol().getProposalno())) {
                            if (axaIps.getInsurancebegintime().after(new Date())) {
                                contFormData.getLccont().setCvalidate(axaIps.getInsurancebegintime());//保险起期
                            } else {
                                contFormData.getLccont().setCvalidate(PubFun.getDate(RetNewPayAndChange1.calendar1(-1)));
                            }
                            contFormData.getLcpol().setPrem(axaIps.getPermium());
                            contFormData.getLcpol().setInsuyear("1Y");//保险期间
                            contFormData.getLcpol().setPlan(axaIps.getProductcode());
                            for (CmiParty cmiParty : cmiParties) {
                                //投保人
                                if ("0".equals(cmiParty.getIndexno())) {

                                } else if ("1".equals(cmiParty.getIndexno())) {
                                    if ("0".equals(cmiParty.getEqapplicant())) {
                                        contFormData.getLcinsured().setRelationtoappnt("00");
                                        contFormData.getLcinsured().setLcinsuredishavesocial(cmiParty.getIshavesocial());//有无社保
                                    } else {
                                        contFormData.getLcinsured().setLcinsuredname(cmiParty.getFullname());
                                        contFormData.getLcinsured().setLcinsuredsex(cmiParty.getGender());
                                        contFormData.getLcinsured().setLcinsuredidtype(cmiParty.getCertitype());
                                        contFormData.getLcinsured().setLcinsuredidno(cmiParty.getCertino());
                                        contFormData.getLcinsured().setLcinsuredbirthday(cmiParty.getBirthdate());
                                        contFormData.getLcinsured().setLcinsuredishavesocial(cmiParty.getIshavesocial());
                                    }
                                } else {
                                    LcinsuredTwoVo lcinsuredVo = new LcinsuredTwoVo();
                                    lcinsuredVo.setLcinsuredname(cmiParty.getFullname());
                                    lcinsuredVo.setLcinsuredsex(cmiParty.getGender());
                                    lcinsuredVo.setLcinsuredidtype(cmiParty.getCertitype());
                                    lcinsuredVo.setLcinsuredidno(cmiParty.getCertino());
                                    lcinsuredVo.setLcinsuredbirthday(cmiParty.getBirthdate());
                                    lcinsuredVo.setLcinsuredishavesocial(cmiParty.getIshavesocial());
                                    contFormData.getLcinsuredmulti().add(lcinsuredVo);
                                }
                            }
                        }
                    } else {
                        if (StringUtils.isEmpty(contFormData.getAxalcappnt().getTransno())) {
                            contFormData.getAxalcappnt().setAgentcodeaxa(axaIps.getAgentcode());
                        }

                        if (contFormData.getLcpol() != null && StringUtils.isEmpty(contFormData.getLcpol().getProposalno())) {
                            if ("01".equals(axaIps.getCurrency())) {
                                contFormData.getLccont().setCurrencytype("CNY");//人民币币种
                            } else if ("04".equals(axaIps.getCurrency())) {
                                contFormData.getLccont().setCurrencytype("USD");//美元币种
                            }
                            contFormData.getLcpol().setPrem(axaIps.getPermium());//保费
                            contFormData.getLcpol().setInsuyear("1Y");//保险期间

                            if (axaIps.getInsurancebegintime().after(new Date())) {
                                contFormData.getLccont().setCvalidate(axaIps.getInsurancebegintime());//保险起期
                            } else {
                                contFormData.getLccont().setCvalidate(PubFun.getDate(RetNewPayAndChange1.calendar1(-1)));
                            }

                            for (PremiumCalculationDto dto : premiumCalculationDto) {

                                if ("0".equals(dto.getTargetid())) {
                                    if ("0".equals(dto.getEqapplicant())) {
                                        contFormData.getLcinsured().setRelationtoappnt("00");
//										contFormData.getLcinsured().setIshsbcclerk(dto.getIshsbcclerk());
                                        contFormData.getLcinsured().setLcinsuredplan(dto.getProductcode());
                                        contFormData.getLcinsured().setLcinsuredprofit(dto.getDutycodelist());
                                        if (StringUtils.isNoneBlank(dto.getDeductible())) {
                                            contFormData.getLcinsured().setDeductible(dto.getDeductible());
                                        }
                                    } else {
                                        contFormData.getLcinsured().setLcinsuredname(dto.getInsurename());
                                        contFormData.getLcinsured().setLcinsuredbirthday(dto.getBirthday());
//										contFormData.getLcinsured().setIshsbcclerk(dto.getIshsbcclerk());
                                        contFormData.getLcinsured().setLcinsuredplan(dto.getProductcode());
                                        contFormData.getLcinsured().setLcinsuredprofit(dto.getDutycodelist());
                                        if (StringUtils.isNoneBlank(dto.getDeductible())) {
                                            contFormData.getLcinsured().setDeductible(dto.getDeductible());
                                        }
                                    }
                                } else {
                                    LcinsuredTwoVo lcinsuredVo = new LcinsuredTwoVo();
                                    lcinsuredVo.setLcinsuredname(dto.getInsurename());
                                    lcinsuredVo.setLcinsuredbirthday(dto.getBirthday());
//									lcinsuredVo.setIshsbcclerk(dto.getIshsbcclerk());
                                    lcinsuredVo.setLcinsuredplan(dto.getProductcode());
                                    lcinsuredVo.setLcinsuredprofit(dto.getDutycodelist());
                                    if (StringUtils.isNoneBlank(dto.getDeductible())) {
                                        lcinsuredVo.setDeductible(dto.getDeductible());
                                    }
                                    if ("2".equals(dto.getPersonrole())) {
                                        lcinsuredVo.setRelatoinsu("33");//与主被保人关系配偶
                                    } else if ("3".equals(dto.getPersonrole())) {
                                        lcinsuredVo.setRelatoinsu("32");//与主被保人关系子女
                                    }
                                    contFormData.getLcinsuredmulti().add(lcinsuredVo);
                                }
                            }

                        }
                    }


                }
            }

            if ("MELI".equals(insurancecom) || "INSH".equals(insurancecom) || "ANZL".equals(insurancecom) ||"PALI".equals(insurancecom)) {
                System.out.println("useIPSflag_lcinsured=" + useIPSflag_lcinsured + " useIPSflag_krisk=" + useIPSflag_krisk
                        + " useIPSflag_subrisk=" + useIPSflag_subrisk);

                // IPS 数据插入
                if (useIPSflag_lcinsured || useIPSflag_krisk || useIPSflag_subrisk) {
                    System.out.println("IPS 数据插入----------------");
                    ContFormData contFormData = (ContFormData) returnVueForm.getFormdata();

                    if (lccontVo != null) {
                    	System.out.println("操作页面放入IPS的QuotationId----------------");
                        contFormData.getLccont().setQuotationId(lccontVo.getQuotationId());
                        contFormData.getLccont().setApplicationId(lccontVo.getApplicationId());
                        contFormData.getLccont().setShoppingCartIndicator(lccontVo.getShoppingCartIndicator());
                        contFormData.getLccont().setRemoteSalesIndicator(lccontVo.getRemoteSalesIndicator());
                        
                        System.out.println("操作页面IPS的ipsno:"+lccontVo.getIpsno());
                        if (null==contFormData.getLccont().getIpsno()&&null!=lccontVo.getIpsno()){
                            contFormData.getLccont().setIpsno(lccontVo.getIpsno());
                        }
                        
                        System.out.println("操作页面IPS的isUnionAccount:"+lccontVo.getIsUnionAccount());
                        if (null!=lccontVo.getIsUnionAccount()){
                            contFormData.getLccont().setIsUnionAccount(lccontVo.getIsUnionAccount());
                        }

                    }else{
                    	System.out.println("第一次SFP跳转时放入IPS的QuotationId----------------");
                        contFormData.getLccont().setQuotationId(applbean.getQuotationId());
                        contFormData.getLccont().setApplicationId(applbean.getApplicationId());
                        contFormData.getLccont().setShoppingCartIndicator(applbean.getShoppingCartIndicator());
                        contFormData.getLccont().setRemoteSalesIndicator(applbean.getRemoteSalesIndicator());
                        if ("Y".equals(applbean.getShoppingCartIndicator()) && "Y".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("RS");
                        }
                        if ("N".equals(applbean.getShoppingCartIndicator()) && "Y".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("RE");
                        }
                        if ("Y".equals(applbean.getShoppingCartIndicator()) && "N".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("SC");
                        }
                        if ("N".equals(applbean.getShoppingCartIndicator()) && "N".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("BH");
                        }
                        if (null==contFormData.getLccont().getIpsno()&&null!=ipsno){
                            LOG.info("IPS setLccont IPSNO:{}",new Object[]{ipsno});
                            contFormData.getLccont().setIpsno(ipsno);
                        }

                        LOG.info("IPS setLccont关联单标记:{}",new Object[]{isUnionAccount});
                        contFormData.getLccont().setIsUnionAccount(isUnionAccount);
                    }
                    
                    
                   /* // 第一次跳转时放入 IPS 的QuotationId
                    if (StringUtils.isNoneBlank(applbean.getQuotationId())) {
                        System.out.println("第一次SFP跳转时放入IPS的QuotationId----------------");
                        contFormData.getLccont().setQuotationId(applbean.getQuotationId());
                        contFormData.getLccont().setApplicationId(applbean.getApplicationId());
                        contFormData.getLccont().setShoppingCartIndicator(applbean.getShoppingCartIndicator());
                        contFormData.getLccont().setRemoteSalesIndicator(applbean.getRemoteSalesIndicator());
                        if ("Y".equals(applbean.getShoppingCartIndicator()) && "Y".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("RS");
                        }
                        if ("N".equals(applbean.getShoppingCartIndicator()) && "Y".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("RE");
                        }
                        if ("Y".equals(applbean.getShoppingCartIndicator()) && "N".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("SC");
                        }
                        if ("N".equals(applbean.getShoppingCartIndicator()) && "N".equals(applbean.getRemoteSalesIndicator())) {
                            contFormData.getLccont().setCommonchannel("BH");
                        }
                        if (null==contFormData.getLccont().getIpsno()&&null!=ipsno){
                            contFormData.getLccont().setIpsno(ipsno);
                        }
                        contFormData.getLccont().setIsUnionAccount(isUnionAccount);
                    } else {
                        System.out.println("操作页面放入IPS的QuotationId----------------");
                        if (lccontVo != null) {
                            contFormData.getLccont().setQuotationId(lccontVo.getQuotationId());
                            contFormData.getLccont().setApplicationId(lccontVo.getApplicationId());
                            contFormData.getLccont().setShoppingCartIndicator(lccontVo.getShoppingCartIndicator());
                            contFormData.getLccont().setRemoteSalesIndicator(lccontVo.getRemoteSalesIndicator());
                            if (null==contFormData.getLccont().getIpsno()&&null!=lccontVo.getIpsno()){
                                contFormData.getLccont().setIpsno(lccontVo.getIpsno());
                                System.out.println("操作页面IPS的ipsno:"+lccontVo.getIpsno());
                            }
                            if (null!=lccontVo.getIsUnionAccount()){
                                contFormData.getLccont().setIsUnionAccount(lccontVo.getIsUnionAccount());
                                System.out.println("操作页面IPS的isUnionAccount:"+lccontVo.getIsUnionAccount());
                            }
                        }
                    }*/

                    if (StringUtils.isNoneBlank(contFormData.getLccont().getApplicationId())
                            && StringUtils.isNoneBlank(contFormData.getLccont().getQuotationId())) {

                        QuoteId quoteId = new QuoteId();

                        quoteId.setApplicationReferenceNumber(contFormData.getLccont().getApplicationId());
                        quoteId.setQuotationInternalReferenceNumber(contFormData.getLccont().getQuotationId());
                        // 数据库查询出数据
                        System.out.println("newcontcontroller调用ipsDataServiceImpl-------");
                        contFormDataTempIPS = ipsDataServiceImpl.getSidData(quoteId, contFormData, insurancecom, pageflag,
                                appflag);
                        if (contFormDataTempIPS.getQuotation() != null) {
                            contFormData.setQuotation(contFormDataTempIPS.getQuotation());
                        }

                        // 主被保人
                        if (contFormData.getLcinsured().getLcinsuredname() == null
                                && "2".equals(contFormData.getLccont().getPageflag())) {
//							System.out.println("第" + a + "次进入," + contFormDataTempIPS.getLcinsured().getLcinsuredname());
                            //纸质签投被保人关系
                            LCAppntVo lcappnt = preContDao.selectBylcAppnt(contFormData.getLccont().getTransno());
                            if (lcappnt!=null){
                                if (StringUtils.isNotEmpty(lcappnt.getRelationtoappnt())){
                                    contFormData.getLcinsured()
                                            .setRelationtoappnt(lcappnt.getRelationtoappnt());
                                }
                            }else{
                                contFormData.getLcinsured()
                                        .setRelationtoappnt(contFormDataTempIPS.getLcinsured().getRelationtoappnt());
                            }
                            contFormData.getLcinsured()
                                    .setLcinsuredname(contFormDataTempIPS.getLcinsured().getLcinsuredname());
                            contFormData.getLcinsured()
                                    .setLcinsuredsex(contFormDataTempIPS.getLcinsured().getLcinsuredsex());
                            contFormData.getLcinsured().setLcinsuredroccupationcode(
                                    contFormDataTempIPS.getLcinsured().getLcinsuredroccupationcode());
                            contFormData.getLcinsured()
                                    .setLcinsuredbirthday(contFormDataTempIPS.getLcinsured().getLcinsuredbirthday());
                            contFormData.getLcinsured().setCoveredlocalsociomedical(
                                    contFormDataTempIPS.getLcinsured().getCoveredlocalsociomedical());
                            contFormData.getLcinsured()
                                    .setMainriskflag(contFormDataTempIPS.getLcinsured().getMainriskflag());

                        }
                        if (contFormDataTempIPS.getLcinsuredmulti().size() > 0
                                || contFormDataTempIPS.getLcinsured().getLcinsuredtwoflag().size() > 0) {
                            // ANZL 第二被保人
                            if ("ANZL".equals(insurancecom)) {
                                if (contFormData.getLcinsuredmulti().size() == 0
                                        && contFormDataTempIPS.getLcinsuredmulti().size() > 0) {
                                    //if (contFormData.getLcinsured().getContno() == null) {
                                        for (int i = 0; i < contFormDataTempIPS.getLcinsuredmulti().size(); i++) {
                                            contFormData.getLcinsuredmulti()
                                                    .add(contFormDataTempIPS.getLcinsuredmulti().get(i));
                                        }
                                    //}
                                }
                                if (contFormDataTempIPS.getLcinsuredtwo() != null
                                        && contFormDataTempIPS.getLcinsuredtwo().getLcinsuredname() != null
                                        && (contFormData.getLcinsuredtwo() == null
                                        || (contFormData.getLcinsuredtwo() != null && StringUtils
                                        .isEmpty(contFormData.getLcinsuredtwo().getLcinsuredname())))) {
                                    //if (contFormData.getLcinsured().getContno() == null) {
                                        LcinsuredTwoVo lcinsuredtwo2 = contFormData.getLcinsuredtwo();
                                        LcinsuredTwoVo lcinsuredTwoVo = new LcinsuredTwoVo();
                                        if (lcinsuredtwo2 == null) {
                                            contFormData.setLcinsuredtwo(lcinsuredTwoVo);
                                        }
                                        contFormData.getLcinsured().setLcinsuredtwoflag(
                                                contFormDataTempIPS.getLcinsured().getLcinsuredtwoflag());
                                        contFormData.getLcinsuredtwo().setRelationtoappnt(
                                                contFormDataTempIPS.getLcinsuredtwo().getRelationtoappnt());
                                        contFormData.getLcinsuredtwo()
                                                .setLcinsuredname(contFormDataTempIPS.getLcinsuredtwo().getLcinsuredname());
                                        contFormData.getLcinsuredtwo()
                                                .setLcinsuredsex(contFormDataTempIPS.getLcinsuredtwo().getLcinsuredsex());
                                        contFormData.getLcinsuredtwo().setLcinsuredbirthday(
                                                contFormDataTempIPS.getLcinsuredtwo().getLcinsuredbirthday());
                                        contFormData.getLcinsuredtwo().setCoveredlocalsociomedical(
                                                contFormDataTempIPS.getLcinsuredtwo().getCoveredlocalsociomedical());
                                        contFormData.getLcinsuredtwo()
                                                .setRelatoinsu(contFormDataTempIPS.getLcinsuredtwo().getRelatoinsu());
                                    //}
                                }

                            }
                            // MELI 第二被保人
                            if ("MELI".equals(insurancecom)) {
                                if (contFormDataTempIPS.getLcinsuredtwo() != null
                                        && contFormDataTempIPS.getLcinsuredtwo().getLcinsuredname() != null
                                        && (contFormData.getLcinsuredtwo() == null
                                        || (contFormData.getLcinsuredtwo() != null && StringUtils
                                        .isEmpty(contFormData.getLcinsuredtwo().getLcinsuredname())))) {
                                    //if (contFormData.getLcinsured().getContno() == null) {
                                        LcinsuredTwoVo lcinsuredtwo2 = contFormData.getLcinsuredtwo();
                                        LcinsuredTwoVo lcinsuredTwoVo = new LcinsuredTwoVo();
                                        if (lcinsuredtwo2 == null) {
                                            contFormData.setLcinsuredtwo(lcinsuredTwoVo);
                                        }
                                        contFormData.getLcinsured().setLcinsuredtwoflag(
                                                contFormDataTempIPS.getLcinsured().getLcinsuredtwoflag());
                                        contFormData.getLcinsuredtwo().setRelationtoappnt(
                                                contFormDataTempIPS.getLcinsuredtwo().getRelationtoappnt());
                                        contFormData.getLcinsuredtwo()
                                                .setLcinsuredname(contFormDataTempIPS.getLcinsuredtwo().getLcinsuredname());
                                        contFormData.getLcinsuredtwo()
                                                .setLcinsuredsex(contFormDataTempIPS.getLcinsuredtwo().getLcinsuredsex());
                                        contFormData.getLcinsuredtwo().setLcinsuredbirthday(
                                                contFormDataTempIPS.getLcinsuredtwo().getLcinsuredbirthday());
                                        contFormData.getLcinsuredtwo().setCoveredlocalsociomedical(
                                                contFormDataTempIPS.getLcinsuredtwo().getCoveredlocalsociomedical());
                                        contFormData.getLcinsuredtwo()
                                                .setRelatoinsu(contFormDataTempIPS.getLcinsuredtwo().getRelatoinsu());
                                    //}
                                }
                            }
                            // INSH 第二被保人
                            if ("INSH".equals(insurancecom)) {
                                //if (contFormData.getLcinsured().getContno() == null) {
                                    if(contFormData.getLcinsuredmulti().size() == 0) {
                                        List<LcinsuredTwoVo> lcinsuredmulti = contFormDataTempIPS.getLcinsuredmulti();
                                        if (contFormDataTempIPS.getLcinsuredmulti().size() > 0) {
                                            for (LcinsuredTwoVo lcinsured : lcinsuredmulti) {
                                                contFormData.getLcinsuredmulti().add(lcinsured);
                                            }
                                        }
                                    }
                                    if (contFormDataTempIPS.getLcinsuredtwo() != null
                                            && contFormDataTempIPS.getLcinsuredtwo().getLcinsuredname() != null
                                            && (contFormData.getLcinsuredtwo() == null
                                            || (contFormData.getLcinsuredtwo() != null && StringUtils
                                            .isEmpty(contFormData.getLcinsuredtwo().getLcinsuredname())))) {
                                        LcinsuredTwoVo lcinsuredtwo2 = contFormData.getLcinsuredtwo();
                                        LcinsuredTwoVo lcinsuredTwoVo = new LcinsuredTwoVo();
                                        if (lcinsuredtwo2 == null) {
                                            contFormData.setLcinsuredtwo(lcinsuredTwoVo);
                                        }
                                        contFormData.getLcinsured().setLcinsuredtwoflag(
                                                contFormDataTempIPS.getLcinsured().getLcinsuredtwoflag());
                                        contFormData.getLcinsuredtwo().setRelationtoappnt(
                                                contFormDataTempIPS.getLcinsuredtwo().getRelationtoappnt());
                                        contFormData.getLcinsuredtwo()
                                                .setLcinsuredname(contFormDataTempIPS.getLcinsuredtwo().getLcinsuredname());
                                        contFormData.getLcinsuredtwo()
                                                .setLcinsuredsex(contFormDataTempIPS.getLcinsuredtwo().getLcinsuredsex());
                                        contFormData.getLcinsuredtwo().setLcinsuredbirthday(
                                                contFormDataTempIPS.getLcinsuredtwo().getLcinsuredbirthday());
                                        contFormData.getLcinsuredtwo().setCoveredlocalsociomedical(
                                                contFormDataTempIPS.getLcinsuredtwo().getCoveredlocalsociomedical());
                                        contFormData.getLcinsuredtwo()
                                                .setRelatoinsu(contFormDataTempIPS.getLcinsuredtwo().getRelatoinsu());
                                    }
                                //}
                            }
                        }
                        // 主险



                        if (((!ObjectUtils.isEmpty(lccontVo)&&StringUtils.isNotBlank(lccontVo.getRemark())&&lccontVo.getRemark().contains("COPY")&&StringUtils.isBlank(contFormData.getLcpol().getKindcode()))
                                ||(contFormData.getLcpol() != null && StringUtils.isEmpty(contFormData.getLcpol().getProposalno())))
                                && contFormDataTempIPS.getLcpol() != null) {
                            contFormData.getLcpol().setPrem(contFormDataTempIPS.getLcpol().getPrem());
                            contFormData.getLcpol().setSumprem(contFormDataTempIPS.getLcpol().getSumprem());//首期保费

                            contFormData.getLcpol().setAmnt(contFormDataTempIPS.getLcpol().getAmnt());
                            contFormData.getLcpol().setType(contFormDataTempIPS.getLcpol().getType());
                            contFormData.getLcpol().setPayintv(contFormDataTempIPS.getLcpol().getPayintv());
                            contFormData.getLcpol().setGetyearflag(contFormDataTempIPS.getLcpol().getGetyearflag());
                            contFormData.getLcpol().setBonusgetmode(contFormDataTempIPS.getLcpol().getBonusgetmode());
                            contFormData.getLcpol().setSurvivalInsurancePeriod(
                                    contFormDataTempIPS.getLcpol().getSurvivalInsurancePeriod());
                            contFormData.getLcpol().setBonusgetage(contFormDataTempIPS.getLcpol().getBonusgetage());
                            contFormData.getLcpol().setBonusGetAgeFlag(NewContUtil.getRiskParamFlag(contFormDataTempIPS.getLcpol().getBonusgetage()));
                            contFormData.getLcpol().setSpecialsurvivalage(contFormDataTempIPS.getLcpol().getSpecialsurvivalage());
                            contFormData.getLcpol().setSpecialsurvivalageflag(NewContUtil.getRiskParamFlag(contFormDataTempIPS.getLcpol().getSpecialsurvivalage()));
                            contFormData.getLcpol().setExtragetyear(contFormDataTempIPS.getLcpol().getExtragetyear());
                           
                            //Y4、B9类 改成可配置化，配置了保险期间（年）输入框的产品赋值	
                    		List<LmriskparamsdefaVo> params=lmriskDao.QueryParam(contFormData.getLccont().getRiskcode(), "insuyearY4", "Y");            
                            if (params.size()>0) {
                                String insuyear = contFormDataTempIPS.getLcpol().getInsuyear();
                                insuyear = insuyear.substring(0, insuyear.length() - 1);
                                contFormData.getLcpol().setInsuyearY4(insuyear);
                            } else {
                                contFormData.getLcpol().setInsuyear(contFormDataTempIPS.getLcpol().getInsuyear());
                            }
                            contFormData.getLcpol().setPlan(contFormDataTempIPS.getLcpol().getPlan());
                            contFormData.getLcpol().setInvestmentstartdateflag(
                                    contFormDataTempIPS.getLcpol().getInvestmentstartdateflag());

                            contFormData.getLcpol().setPayendyear(contFormDataTempIPS.getLcpol().getPayendyear());
                            contFormData.getLcpol().setAnnuityincamnt(contFormDataTempIPS.getLcpol().getAnnuityincamnt());
                            // contFormData.setLcpol(contFormDataTempIPS.getLcpol());
                            contFormData.getLcpol().setRegularaddflag(contFormDataTempIPS.getLcpol().getRegularaddflag());
                            contFormData.getLcpol().setRegularaddpayintv(contFormDataTempIPS.getLcpol().getRegularaddpayintv());
                            contFormData.getLcpol().setRegularaddprem(contFormDataTempIPS.getLcpol().getRegularaddprem());
                            contFormData.getLcpol().setRegularaddstartdate(contFormDataTempIPS.getLcpol().getRegularaddstartdate());
                        }
                        // 附加险
                        if (StringUtils.isEmpty(contFormData.getLccont().getSublcpolflag())
                                && contFormData.getSublcpols() != null && contFormDataTempIPS.getSublcpols() != null
                                && contFormDataTempIPS.getSublcpols().size() > 0) {
                            List<lcpolVo> sublcpols = new ArrayList<>();
                            lcpolVo lcpolVo = null;
                            for (int i = 0; i < contFormDataTempIPS.getSublcpols().size(); i++) {
                                if ("@RC".equals(contFormDataTempIPS.getSublcpols().get(i).getRiskcode())){
                                    lcpolVo= contFormDataTempIPS.getSublcpols().get(i);
                                }else{
                                    sublcpols.add(contFormDataTempIPS.getSublcpols().get(i));
                                }
                            }
                            //@RC放最后，特殊处理（因为告知必填校验，告知RC不是最后会失效）
                            if (null != lcpolVo){
                                sublcpols.add(lcpolVo);
                            }
                            if("Y".equals(contFormData.getLccont().getWtRelaPrtNo())&&StringUtils.isNotBlank(contFormData.getLccont().getRelaPrtNo())){
                                sublcpols.clear();
                            }
                            contFormData.setSublcpols(sublcpols);
							LOG.info("contFormData Sublcpols json:" + JSON.toJSONString(contFormData.getSublcpols()));

                            //安联的附加险豁免险，如果被保人不是投保人的情况特殊处理（目前只支持有一个附加险豁免险，对应一个其他的被保人）
                            if (contFormDataTempIPS.getOtherinsured().size() > 0) {
                                OtherInsuredVo otherInsuredVo = contFormDataTempIPS.getOtherinsured().get(0);
                                if (contFormData.getOtherinsured().isEmpty()) {
                                    contFormData.getSublcpols().get(0).setOtherinsuredflag("Y");
                                    contFormData.getOtherinsured().add(otherInsuredVo);
                                }
                            }

                        }
                    }

                }
            }

        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }

        // get获取所有的电子签名相关的录入信息
    	}
    	
        return (ContFormData) returnVueForm.getFormdata();

    }
    
    
    /**
     * 查询IPS中是否有附加险
     * @param applicationId
     * @param quotationId
     * @return  MessageBean
     */
    @RequestMapping(value = "/checkIPSSubRisk")
    @ResponseBody
    public MessageBean hasSubRisk(@RequestParam("applicationId") String applicationId, 
    		@RequestParam("quotationId") String quotationId,
    		@RequestParam("transno") String transno,
    		HttpServletRequest request) {
    	LOG.info("IPS查询：applicationId：{}，quotationId：{}", applicationId, quotationId);
    	MessageBean msgBean = new MessageBean();
    	if(StringUtils.isBlank(applicationId)){
    		msgBean.setSuccess(false);
    		msgBean.setMsg("applicationId为空，此单非SFP渠道，不做处理");
    		return msgBean;
    	}
    	if(StringUtils.isBlank(quotationId)){
    		msgBean.setSuccess(false);
    		msgBean.setMsg("quotationId为空，此单非SFP渠道，不做处理");
    		return msgBean;
    	}
    	UserLoginInfoBean loginUser = (UserLoginInfoBean) request.getSession().getAttribute("userLoginInfo");
        Boolean ipsFlag = ipsDataServiceImpl.hasSubRisk(loginUser.getEmplID(), applicationId, quotationId);
        LOG.info("IPS DATA存在附加险：{}", ipsFlag);
        
        Boolean dbFlag = false;
        if(NewContUtil.validTransNo(transno)){//transno有效
        	List<lcpolVo> sublcpols = lcpolVoMapper.selectByTransno1(transno, "S");
        	if(sublcpols.size() > 0){
        		dbFlag = true;
        		LOG.info("Lcpol表已保存附加险信息");
        	}
    	}
        
        String resFlag = "N";
        if(ipsFlag || dbFlag){
        	resFlag = "Y";
        }
        
        msgBean.setSuccess(true);
        msgBean.setParm(resFlag);
        return msgBean;
    }
}
