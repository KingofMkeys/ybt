package com.sinosoft.service.newCont.impl.ANZL;

import com.sinosoft.bean.common.FormElement;
import com.sinosoft.bean.common.FormStatus;
import com.sinosoft.bean.common.VueForm;
import com.sinosoft.bean.newCont.ContFormData;
import com.sinosoft.bean.newCont.ContRelateData;
import com.sinosoft.bean.newCont.NewContStaticStr;
import com.sinosoft.bean.newCont.data.ApplyBean;
import com.sinosoft.common.util.NewContUtil;
import com.sinosoft.core.common.util.CommonUtil;
import com.sinosoft.eservice.api.bean.UserLoginInfoBean;
import com.sinosoft.service.allianz.commonbean.CommFomat;
import com.sinosoft.service.api.PageListBean;
import com.sinosoft.service.api.PubFun;
import com.sinosoft.service.business.db.dao.*;
import com.sinosoft.service.business.db.vo.*;
import com.sinosoft.service.business.ui.CustomerID.bean.Ldcustomer;
import com.sinosoft.service.business.ui.CustomerID.bean.Ldcustomeraccount;
import com.sinosoft.service.business.ui.CustomerID.bean.Ldcustomeraddress;
import com.sinosoft.service.business.ui.laqualidetails.bean.StaffCongyeBean;
import com.sinosoft.service.business.ui.newcont.service.NewContEnterService;
import com.sinosoft.service.business.utils.AddressSplitUtil;
import com.sinosoft.service.common.newCont.FormelementService;
import com.sinosoft.service.newCont.AbstractNewContOp;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * 投保单基本信息操作
 * @author CDK 
 * @date： 日期：2018年5月3日 时间：下午1:15:27
 * @version 1.0
 */
@Service("anzllcappntOpService")
public class ANZLLcappntOpService extends AbstractNewContOp<ContFormData> {

	private static final Logger logger = LoggerFactory
			.getLogger(ANZLLcappntOpService.class);
	
	   @Autowired
	    private NewContEnterService newContEnterService;

	    @Autowired
	    private NewContEnterDao newContEnterDao;

	    @Autowired
	    private LdcustomerDao ldcustomerDao;

	    @Autowired
	    private LdcustomeraccountDao ldcustomeraccountDao;

	    @Autowired
	    private lcaddressVoMapper lcaddressVoDao;

	    @Autowired
	    private LcinsuredVoMapper lcinsuredVoDao;
	    
		@Autowired
		private FormelementService formelementService;
		
		@Autowired
		private PaymentBranchMapper paymentBranchMapper;
		@Autowired
		private HubHistoryMapper hubHistoryMapper;
		
		@Autowired
		private AreacodefullVoMapper  areacodefullVoMapper;
		@Autowired
		private  CrsInfoMapper crsInfoMapper;
		@Autowired
		private ProvinceVoMapper provinceVoMapper;
		@Autowired
		private CityVoMapper cityVoMapper;	
		@Autowired
		private CountyVoMapper countyVoMapper;
		@Autowired
		private LdcodeDao ldcodeDao;
		@Autowired
		private laqualidetailsDao certificateDao;
		@Autowired
		private PNewContEnterDao preContDao;
		@Autowired
		private PlcaddressVoMapper preAdderssDao;
		@Autowired
		private PHubHistoryMapper preHubHistoryDao;
	@Override
	public VueForm initPage(HttpServletRequest request, String transno,
			String insurancecom, VueForm returnVueForm, ContFormData formdata) {
		UserLoginInfoBean tUserLoginInfo = (UserLoginInfoBean) request
				.getSession().getAttribute("userLoginInfo");
		logger.info(" service in initPage SID: "+getSID() +" transno : "+ transno 
				+ " user :"+tUserLoginInfo.getEmplID());
		String combinedid=insurancecom;
		if("ANZL".equals(insurancecom)){
			combinedid="N/A";
		}
		List<FormElement> lcappntFormElement = formelementService.selNoticeFormelement(getSID(),combinedid);
		returnVueForm.getForm_elements().put("lcappnt", lcappntFormElement);//
//        getSidData(request, transno, insurancecom, returnVueForm, formdata);
        returnVueForm.setRelatedata(new ContRelateData());//测试用
		return returnVueForm; 
	}

	
	/**
	 * 获取数据
	 */
	@Override
	public VueForm getSidData(HttpServletRequest request, String transno,
			String insurancecom, VueForm returnVueForm, ContFormData formdata) {
		UserLoginInfoBean tUserLoginInfo = (UserLoginInfoBean) request
				.getSession().getAttribute("userLoginInfo");
		
		logger.info(" service in getSidData SID: "+getSID() +" transno : "+ transno 
				+ " user :"+tUserLoginInfo.getEmplID());
		
		ContFormData lcappntData = (ContFormData) returnVueForm
				.getFormdata();
		
		boolean ifQR = false;
		if (insurancecom.endsWith("QR")) {
			ifQR = true;
			insurancecom = insurancecom.replace("QR", "");
		}
        
        ApplyBean applyBean = formdata.getNewContApply();
        LCAppntVo lcappnt = new LCAppntVo();
        lcaddressVo lcaddress = new lcaddressVo();


        Ldcustomer ldcustomer = new Ldcustomer();
        if(NewContUtil.validTransNo(transno)){

			//预录单
			if(StringUtils.isNotBlank(applyBean.getPaperTransno())){
				lcappnt = preContDao.selectBylcAppnt(applyBean.getPaperTransno());
				formdata.getSubFormData().setLcappnt(lcappnt);
			}else{
				lcappnt = preContDao.selectBylcAppnt(applyBean.getTransno());
				if(lcappnt!=null){
					formdata.getSubFormData().setLcappnt(lcappnt);
				}
				lcappnt = newContEnterDao.selectBylcAppnt(applyBean.getTransno());
			}

            lcaddressVo lcaddress1=new lcaddressVo();
            lcaddress1.setAddressno(new BigDecimal(0));
            lcaddress1.setTransno(applyBean.getTransno());
            lcaddress1.setCustomerno(applyBean.getGrpcontno());
			//预录单
			if(StringUtils.isNotBlank(applyBean.getPaperTransno())){
				lcaddress = preAdderssDao.selectByPrimaryKey_anzl(lcaddress1);
				formdata.getSubFormData().setLcappntaddress(lcaddress);
			}else{
				lcaddress = preAdderssDao.selectByPrimaryKey_anzl(lcaddress1);
				if (lcaddress!=null){
					formdata.getSubFormData().setLcappntaddress(lcaddress);
				}
				lcaddress = lcaddressVoDao.selectByPrimaryKey_anzl(lcaddress1);
			}

            if((StringUtils.isEmpty(applyBean.getAppflag())
            		||"01".equals(applyBean.getAppflag())||"10".equals(applyBean.getAppflag())) && !"N".equals(applyBean.getOperateFlag())
            	&& !("Y".equals(applyBean.getShoppingCartIndicator()) && "Y".equals(applyBean.getRemoteSalesIndicator()))){
            	ldcustomer= ldcustomerDao.selectLdcustomer(applyBean.getGrpcontno());
            	if (ldcustomer!=null){
					if(StringUtils.isNotBlank(applyBean.getPaperTransno())){
						HubHistory preHubHistory = preHubHistoryDao.selectByPrimaryKey(applyBean.getPaperTransno());
						if(preHubHistory != null){
							ldcustomer.setGoaltype(preHubHistory.getGoaltype());
							formdata.getSubFormData().setLdcustomer(ldcustomer);
						}
					}else{
						HubHistory preHubHistory = preHubHistoryDao.selectByPrimaryKey(applyBean.getTransno());
						if(preHubHistory != null){
							ldcustomer.setGoaltype(preHubHistory.getGoaltype());
							formdata.getSubFormData().setLdcustomer(ldcustomer);
						}
						HubHistory hubHistory =	hubHistoryMapper.selectByPrimaryKey(applyBean.getTransno());
						if(hubHistory!=null){
							//需求类型回显
							ldcustomer.setGoaltype(hubHistory.getGoaltype());
						}
					}
				}
            }else{
            	HubHistory hubHistory =	hubHistoryMapper.selectByPrimaryKey(applyBean.getTransno());
            	if(hubHistory!=null){
        		//需求类型回显       		
        		ldcustomer.setGoaltype(hubHistory.getGoaltype());        		
            	} 
            }
                     
            if(lcaddress!=null&&"0".equals(lcaddress.getPostalflag())){
            	lcaddress.getPostalflags().add("postalflags");
            }
            //回显证件长期有效
            if(lcappnt!=null && "Y".equals(lcappnt.getIslongitem())){
                lcappnt.getIslongitems().add("islongitems");
            }
        }
		//查询是否存在预录单
		LCContVo preLccont = preContDao.selectBylccont(applyBean.getTransno());

        if ((!NewContUtil.validTransNo(transno)||"3".equals(applyBean.getFlag())
        		||"2".equals(applyBean.getFlag())) && null == preLccont   && !"N".equals(applyBean.getOperateFlag())
        		&& !("Y".equals(applyBean.getShoppingCartIndicator()) && "Y".equals(applyBean.getRemoteSalesIndicator()))) {
            
        	if(applyBean.getAppflag()==null||"".equals(applyBean.getAppflag())||"01".equals(applyBean.getAppflag())||"10".equals(applyBean.getAppflag())){
        		//查询投保人信息
                ldcustomer = newContEnterService.selectldcustomer(applyBean.getGrpcontno());
                //查询投保人email
                Ldcustomeraddress ldcustomeraddress = newContEnterService.selectldcustomeraddress(applyBean.getGrpcontno());
                CrsInfo crsInfo = crsInfoMapper.selectByPrimaryKey(applyBean.getGrpcontno());
                if (ldcustomer != null) {
                	if (("N").equals(ldcustomer.getGoaltype())) {
                        ldcustomer.setGoaltype("");
                    }
					lcappnt.setBankcustomertype(ldcustomer.getCustomerType());
                	lcappnt.setAppntname(ldcustomer.getFullnamechinese());
                    lcappnt.setIdtype(ldcustomer.getIdtype());
                    lcappnt.setAppntsex(ldcustomer.getGender());                  
                    lcappnt.setIdno(ldcustomer.getIdnumber());
                    lcappnt.setNativeplace(ldcustomer.getNationality());
                    if (ldcustomer.getDateofbirth() != null) {
                        lcappnt.setAppntbirthday(PubFun.strToDate(ldcustomer.getDateofbirth()));
                    }
                    //存入hub带入的默认地址与移动电话信息 试算时做比对
                    setHubAddressDetail(ldcustomeraddress, lcaddress, ldcustomer);
                    
                     //HUB映射没有保存的时候才去做映射
                    if(lcappnt!=null&&lcappnt.getContno()==null){                   	                    	 
                         //单位地址信息
                         lcappnt.setCompany(ldcustomeraddress.getPrevioucompany());
                         //出生地国家
                         if(crsInfo!=null){
                         	lcappnt.setBirthcounty(crsInfo.getBirthcountrycode());
                         }
                         if (ldcustomer.getIdexpiry() != null) {
                             lcappnt.setAppntenddate(PubFun.strToDate(ldcustomer.getIdexpiry()));
                         }                      
                         if (ldcustomer.getIncome() != null&&!"".equals(ldcustomer.getIncome())) {
                         	//个人年收入
                             if (("N").equals(ldcustomer.getIncome())) {
//                                 lcappnt.setCompany("");
                             	lcappnt.setRgtaddress("");
                             } else {
                             	lcappnt.setRgtaddress(ldcustomer.getIncome());
//                                 lcappnt.setCompany(ldcustomer.getIncome());
                             }
                         }else{
                         	//出现异常后 ldcustomer.getIncome()可能为空字符串
                         	lcappnt.setRgtaddress("");
                         }
                         if (!CommonUtil.isEmpty(ldcustomer.getTotalincome()) ) {
                         	 
                             if ("N".equals(ldcustomer.getTotalincome())) {
                                  BigDecimal bd = new BigDecimal(0);
                                 lcappnt.setSalary(bd);
                             } else {
                             	try {
                             		 BigDecimal bd = new BigDecimal(ldcustomer.getTotalincome());
                                      lcappnt.setSalary(bd);
         						} catch (Exception e) {
         							e.printStackTrace();
         						}
                                
                             }
                         }
                        mappingadd(ldcustomeraddress,lcaddress);                                              
                        LdcodeVo mobile_countrycode =new LdcodeVo();
             			
             			if(!CommonUtil.isEmpty(ldcustomer.getCountryCode_home())){
             				//根据code CN 获取 86
             				 LdcodeVo ldcode=new LdcodeVo();
             				 ldcode.setCodetype("countrycode");
                     		 ldcode.setCode(ldcustomer.getCountryCode_home());
                			 ldcodeDao.selectldcode(ldcode);    
                			 mobile_countrycode = ldcodeDao.selectldcode(ldcode);
                			 if(mobile_countrycode==null){
                				 mobile_countrycode =new LdcodeVo(); 
                			 }
                			 
                         }
                         //固定电话信息  H5移除固定电话赋值回显，非同步HUB电话  又加上了
						if(!CommonUtil.isEmpty(ldcustomer.getPhone_home())){
							if(!CommonUtil.isEmpty(ldcustomer.getCountryCode_home())){
								lcaddress.setCountrycodetel_tel(mobile_countrycode.getCodealias());                      	
							 }
							lcaddress.setHomephone(ldcustomer.getPhone_home());
						 }
             			
                         if(!CommonUtil.isEmpty(ldcustomer.getMobile_home())){
                         	if(!CommonUtil.isEmpty(ldcustomer.getCountryCode_home())){
                             	lcaddress.setCountrycodetel_mob(mobile_countrycode.getCodealias());                      	
                             }
                         	lcaddress.setMobile(ldcustomer.getMobile_home());
                         }else{
                         	if(ldcustomer.getMobilephoneno()!=null){
                         		if(!CommonUtil.isEmpty(ldcustomer.getCountryCode_home())){                         			 
                                 	lcaddress.setCountrycodetel_mob(mobile_countrycode.getCodealias());                      	
                                 }
                               lcaddress.setMobile(ldcustomer.getMobilephoneno());
                           }
                         }                  
                                                
                         //邮编
                         if(!CommonUtil.isEmpty(ldcustomeraddress.getContactpostcode())){
                           	  String code =ldcustomeraddress.getContactpostcode();
                           	  int i = code.lastIndexOf("-");
                           	  if(i!=-1){
                           		  lcaddress.setZipcode(code.substring(i+1));  
                           	  }else{
                           		  lcaddress.setZipcode(ldcustomeraddress.getContactpostcode());  
                           	  }                            	                          
                         }
                         if (ldcustomeraddress != null&&!CommonUtil.isEmpty(ldcustomeraddress.getEmailaddress())) {
                             lcaddress.setEmail(ldcustomeraddress.getEmailaddress());
                         } 
                    	
                    }else{
                    	HubHistory hubHistory =	hubHistoryMapper.selectByPrimaryKey(applyBean.getTransno());
                    	if(hubHistory!=null){
                		//需求类型回显       		
                		ldcustomer.setGoaltype(hubHistory.getGoaltype());        		
                    	} 
                    }
                   
                }
             
        	}else{      		
        	HubHistory hubHistory =	hubHistoryMapper.selectByPrimaryKey(applyBean.getTransno());
        	if(hubHistory!=null){
    		//需求类型回显       		
    		ldcustomer.setGoaltype(hubHistory.getGoaltype());        		
        	}
        	//地址信息回显
    		lcaddressVo lcaddress1=new lcaddressVo();
            lcaddress1.setAddressno(new BigDecimal(0));
            lcaddress1.setTransno(applyBean.getTransno());
            lcaddress1.setCustomerno(applyBean.getGrpcontno());
    		lcaddress=lcaddressVoDao.selectByPrimaryKey_anzl(lcaddress1);
    		//投保人信息回显
    		lcappnt=newContEnterDao.selectBylcAppnt(applyBean.getTransno());
    		if(lcaddress!=null&&"0".equals(lcaddress.getPostalflag())){
            	lcaddress.getPostalflags().add("postalflags");
            }
            //回显证件长期有效
            if(lcappnt!=null && "Y".equals(lcappnt.getIslongitem())){
                lcappnt.getIslongitems().add("islongitems");
            }
          }       	
        }
        
		if (ifQR){
			//清除回显
			if (ldcustomer != null) ldcustomer.setIdnumber(null);
			if (lcappnt!=null){ 
				lcappnt.setIdno(null);
			}
			// 投保人的固定电话清除
//			if (lcaddress != null) {
//				lcaddress.setHomephone(null);//固定电话
//				lcaddress.setAreacodetel(null);//固话城市区号
//				lcaddress.setCountrycodetel_tel(null);//固定电话国家/地区代码
//			}
		}
        lcappntData.setLdcustomer(ldcustomer);
        lcappntData.setLcappntaddress(lcaddress);

		if (NewContUtil.validTransNo(transno)
				&&(null!=lcappntData.getLccont()&&!lcappntData.getLccont().getPageflag().equals("0"))){
			lcappnt = newContEnterDao.selectBylcAppnt(transno);
			// 预览单
			if(StringUtils.isNotBlank(applyBean.getPaperTransno())){
				lcappnt = preContDao.selectBylcAppnt(applyBean.getPaperTransno());
				formdata.getSubFormData().setLcappnt(lcappnt);
			}
		}
//        lcappntData.setLccont(lccont);
        lcappntData.setLcappnt(lcappnt);
        returnVueForm.setFormdata(lcappntData);
        
		return returnVueForm;
	}
	
	
	
	@Override

	public VueForm saveOrUpdate(HttpServletRequest request, String urltransno,
			String insurancecom, VueForm returnVueForm, ContFormData formdata) {
		
		UserLoginInfoBean tUserLoginInfo = (UserLoginInfoBean) request
				.getSession().getAttribute("userLoginInfo");
		FormStatus contFormStatus = returnVueForm.getFormstatus();
		logger.info(" service in getSidData SID: "+getSID() +" transno : "+ urltransno 
				+ " user :"+tUserLoginInfo.getEmplID());
		boolean ifQR = false;
		if (insurancecom.endsWith("QR")) {
			ifQR = true;
			insurancecom = insurancecom.replace("QR", "");
		}
        try {
//          LccontData lccontData = formdata.getLccont()JSON.parseObject(lccontFormdata, LccontData.class);
//          LcappntData lcappntData = JSON.parseObject(lcappntFormdata, LcappntData.class);
            LCContVo lcContVo = formdata.getLccont();
            lcContVo.setPremiumBudget(formdata.getLccont().getPremiumBudget());

            Ldcustomeraccount ldcustomeraccount = formdata.getLdcustomeraccount();
			if("I".equals(formdata.getLcappnt().getIdtype())
					&& null!=formdata.getLcappnt().getStartingDate() && StringUtils.isNotEmpty(formdata.getLcappnt().getAppntname())) {
				String name = formdata.getLcappnt().getAppntname().trim();
				boolean matches = NewContUtil.isValidString(name) || !NewContUtil.containsChinese(name);
				if (matches) {
					contFormStatus.setFlag(false);
					contFormStatus.setDesc("证件为身份证时，姓名只能是中文");
					return returnVueForm;
				}
			}
            LCAppntVo lcappnt = formdata.getLcappnt();
            lcaddressVo lcaddress = formdata.getLcappntaddress();
            Ldcustomer ldcustomer = formdata.getLdcustomer();
            ApplyBean applyBean = formdata.getNewContApply();
            PaymentBranch paymentBranch = formdata.getPaymentbranch();
            try {
            	System.out.println("第一步，根据订单号orderId查询有几张订单");
                String orderid =applyBean.getOrderID();
                List<LCContVo> lccont_orders =newContEnterDao.selectLccontByOrderId(orderid);
                if(lccont_orders!=null&&lccont_orders.size()>0){
                	  System.out.println("第二步，查询出了多张单子,将每单的流水号跟当前流水号做对比,单数为："+lccont_orders.size());
                	  for (LCContVo lccont_order : lccont_orders) {
    					String transno_order = lccont_order.getTransno();
    					System.out.println("流水号为："+transno_order+"，当前单单号为："+urltransno);
    					if(transno_order.equals(urltransno)){
    						System.out.println("流水号一样，不做处理");
    					}else{
    						System.out.println("第三步，将其他单清除orderid,保证orderid在YBT对应的订单唯一");
//    						lccont_order.setOrderID("");
//    						int i =newContEnterDao.updateLCCont(lccont_order);
//    						System.out.println(transno_order+",更新成功");
							System.out.println("新逻辑，不清除，提示用户订单已存在，引导其操作旧单");
							contFormStatus.setFlag(false);
							contFormStatus.setDesc("此订单已存在，请关闭此页面后，请重新从SFP下单页面点击“购买”后重新跳转至银保通页面，或直接打开银保通-投保单操作页面，选择相应投保单，继续录入并保存订单信息。");
							return returnVueForm;
    					}
    				}
                	
                }else{
                System.out.println("此订单号："+orderid+"没有对应的订单，不做处理");	
                }
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("此订单号处理异常");
			}
            
            String brhQRFlag = applyBean.getBrhQRFlag();
            if(StringUtils.isNotEmpty(brhQRFlag)){
            	lcContVo.setBrhQRFlag(brhQRFlag); //分行QR标志
            }
            
            String recordingFlag = applyBean.getRecording();
            lcContVo.setRecording(recordingFlag); //插入补录标志位    Y为补录单，N为正常单
            /***双录***/
			lcContVo.setActiveId(applyBean.getActiveId());
            lcContVo.setOrderID(applyBean.getOrderID()); //双录字段1
            lcContVo.setReportID(applyBean.getReportID()); //双录字段2
            lcContVo.setRecordID(applyBean.getRecordID());//双录字段备1
            lcContVo.setFPRID(applyBean.getFPRID());//双录字段备2
            lcContVo.setPrdTypeCode(applyBean.getPrdTypeCode());
            lcContVo.setPrdSubTypeCode(applyBean.getPrdSubTypeCode());
            lcContVo.setPrdAlternativeNumber(applyBean.getPrdAlternativeNumber());
            lcContVo.setPrdClassificationCode(applyBean.getPrdClassificationCode());
            lcContVo.setCountryTradableCode(applyBean.getCountryTradableCode());
            lcContVo.setCustomerIndicator(applyBean.getCustomerIndicator());
            lcContVo.setEnterWay(applyBean.getEnterWay());
            //委托录入
            if(StringUtils.isNotBlank(applyBean.getTrustField1())){
                 lcContVo.setTrustField1(applyBean.getTrustField1());
            }
            if(StringUtils.isNotBlank(applyBean.getTrustField2())){
                 lcContVo.setTrustField2(applyBean.getTrustField2());
            }
            
            
            lcContVo.setManagecom(tUserLoginInfo.getCompanyCode());           
            List<String> staffids = ldcodeDao.selectExemptData("exemptstaffid");
    		List<String> cifids = ldcodeDao.selectExemptData("exemptcifid");
    		List<String> reportIDs = ldcodeDao.selectExemptData("ReportID");
    		List<String> fprIDs = ldcodeDao.selectExemptData("FprID");
    		String staffid = tUserLoginInfo.getEmplID();
    		String grpcontno = formdata.getNewContApply().getGrpcontno();
    		System.out.println("staffid:"+staffid+",grpcontno"+grpcontno);
    		if(staffids!=null&&cifids!=null&&staffids.contains(staffid)&&cifids.contains(grpcontno)){
    			System.out.println("经检测此单为测试单，插入值IPS的值");
    			//当标记为false时，需要判定IPS特定值是否为空,为空的时候则代表未从SFP跳转，则需要手动补数据
				if(lcContVo.getReportID()==null||"".equals(lcContVo.getReportID())){
					lcContVo.setReportID((reportIDs==null||reportIDs.size()==0)?"20201106 - Q0000170892":reportIDs.get(0));
					lcContVo.setFPRID((fprIDs==null||reportIDs.size()==0)?"311220 - 0038042":fprIDs.get(0));
					lcContVo.setPrdTypeCode("INS");
					lcContVo.setPrdSubTypeCode("INSIL"); 
					lcContVo.setPrdAlternativeNumber(formdata.getNewContApply().getRiskcode());
					lcContVo.setPrdClassificationCode("M");
					lcContVo.setCountryTradableCode("CN");
					lcContVo.setCustomerIndicator("Sole");
					if(lcContVo.getCommonchannel()==null||"".equals(lcContVo.getCommonchannel())){
						lcContVo.setCommonchannel("BH"); 
					}									
				}
				System.out.println("插入值IPS的值完毕");
    		}
            /***End***/
            //通过页面的code 加载name
           /* String citycode =lcContVo.getCitycode();
            System.out.println("获取页面的 城市代码："+citycode);
            AreacodefullVo areacodefullVo= areacodefullVoMapper.selectByPrimaryKey(citycode);
            if(areacodefullVo!=null){
            	lcContVo.setCityname(areacodefullVo.getCityname());
            }else{
            	System.out.println("城市代码："+citycode+"未获取到相应的值");
            }*/
          //RS渠道添加网点城市校验 (三个地址任意一个满足条件就跳过)
            if("RE".equals(lcContVo.getCommonchannel())||"RS".equals(lcContVo.getCommonchannel())){           	          
            	//通讯地址
            	String postprovince = lcaddress.getPostprovince() ;
            	System.out.println("通讯地址省代码："+postprovince);
            	//获取RM所在的网点
            	String managecom = tUserLoginInfo.getCompanyCode();
            	//通过网点查询到网点所对应的省
            	AreacodefullVo  areacodefullVo =areacodefullVoMapper.selectProvinceBycompanyCode(managecom);
            	if(areacodefullVo!=null){
            		String manageprovince = areacodefullVo.getBak2();
            		if(!postprovince.equals(manageprovince)){
            			contFormStatus.setFlag(false);
                		contFormStatus.setDesc("请注意，在此模式下，客户投保时提供的联系地址需和销售网点所属城市保持一致，请返回修改！");
                		return returnVueForm;
            		}
            	}
            	
            }
            //勾选长期有效
            if(lcappnt.getIslongitems() != null && lcappnt.getIslongitems().size()>=1){
                lcappnt.setIslongitem("Y");
            }else{
                lcappnt.setIslongitem("N");
            }
            if(lcaddress.getPostalflags()!=null&&lcaddress.getPostalflags().size()>=1
            		){
            	lcaddress.setPostalflag("0");
            }else{
            	 
            }
            //ANZL投保人都显示固话
			if(lcaddress.getHomephone()!=null&&lcaddress.getHomephone().length()>0){ 
				if(lcaddress.getCountrycodetel_tel()==null||lcaddress.getAreacodetel()==null 
						||lcaddress.getCountrycodetel_tel().length()==0||lcaddress.getAreacodetel().length()==0){ 
					contFormStatus.setFlag(false);
					contFormStatus.setDesc("请填写完整的固定电话信息！(格式为:国家代码+区号+固定电话)");
					return returnVueForm;
				} 
			}else{
				if((lcaddress.getCountrycodetel_tel()!=null&&lcaddress.getCountrycodetel_tel().length()!=0)||(lcaddress.getAreacodetel()!=null 
						&&lcaddress.getAreacodetel().length()!=0)){ 
					contFormStatus.setFlag(false);
					contFormStatus.setDesc("请填写完整的固定电话信息！(格式为:国家代码+区号+固定电话)");
					return returnVueForm;
				}
			}
			
			if(null!=lcappnt.getSalary()&&lcappnt.getSalary().compareTo(new BigDecimal(lcappnt.getRgtaddress()))==-1){
				contFormStatus.setFlag(false);
				contFormStatus.setDesc("家庭年收入必须大于或等于个人年收入！");
				return returnVueForm;
			}
            
            StaffCongyeBean certificateBean = certificateDao.findCertificateNoByStaffid(staffid);
            if(certificateBean != null){
            	logger.info("查询到销售人员从业资格证编号：{}，销售人员姓名：{}", certificateBean.getCongyeNum(), certificateBean.getName());
            	lcContVo.setCertificateNo(certificateBean.getCongyeNum());
            	lcContVo.setSalesName(certificateBean.getName());
            }
            if (ifQR){
            	 /**hub固定数据赋值**/
				Ldcustomer ldcustomerDB = newContEnterService.selectldcustomer(applyBean.getGrpcontno());
				if(ldcustomerDB != null){
					lcappnt.setIdno(ldcustomerDB.getIdnumber());//证件号码  塞值
					logger.info("投保人证件号码塞值结果...");
				}else{
					contFormStatus.setFlag(false);
					contFormStatus.setDesc("未查询到当前客户信息");
					return returnVueForm;
				}
			}

            LCContVo lcContVo1 = newContEnterDao.selectLccontToProposalcontno(lcContVo.getProposalcontno());
            LCAppntVo templcappnt=newContEnterDao.selectBylcAppnt(applyBean.getTransno());
            if (lcContVo1 != null&&templcappnt!=null) {
                lcContVo.setDepositBank(lcContVo.getBankaccno().replaceAll("[a-zA-Z]", "").substring(0, 3));
                lcContVo.setModifydate(PubFun.getCurrentDate());
                lcContVo.setModifytime(PubFun.getCurrentTime());
                lcContVo.setAccname(lcappnt.getAppntname());
                int i = newContEnterDao.updateLCCont(lcContVo);
                if (i == 1) {
                	lcappnt.setTransno(StringUtils.isNotBlank(lcContVo.getTransno())?lcContVo.getTransno():lcContVo1.getTransno());
					lcappnt.setAppntage(CommFomat.getAgeByBirthday(lcappnt.getAppntbirthday()));
					lcappnt.setContno(lcContVo.getContno());
					lcappnt.setPrtno(lcContVo.getContno());
					lcappnt.setAppntno(lcContVo.getAppntno());
					lcappnt.setGrpcontno(lcContVo.getGrpcontno());
					lcappnt.setOperator(tUserLoginInfo.getEmplID());
					lcappnt.setModifydate(PubFun.getDate(PubFun.getCurrentDate()));
					lcappnt.setModifytime(PubFun.getCurrentTime());
                    int j = newContEnterDao.updateLCAppnt(lcappnt);
                    if (!("".equals(ldcustomer.getGoaltype())) && ldcustomer.getGoaltype() != null) {
                        Ldcustomer ldcustomer1 = ldcustomerDao.selectLdcustomer(lcContVo.getGrpcontno());
                        //添加goalType
                        ldcustomer1.setGoaltype(ldcustomer.getGoaltype());
                        ldcustomerDao.updateLdcustomer(ldcustomer1);
                    }
//                    ldcustomeraccount.setTransno(lcContVo.getTransno());
//                    ldcustomeraccountDao.updateLdcustomeraccount(ldcustomeraccount);
                    if (j == 1) {
                        lcaddressVoDao.updateByPrimaryKey_anzl(lcaddress); 
                        //如果存在先删除再插入
                        PaymentBranchKey key =new PaymentBranchKey();
                        key.setAccountholder("0");
                        key.setTransno(urltransno);                     
                        int decount=paymentBranchMapper.deleteByPrimaryKey(key);
                        System.out.println("年金账户产出成功，条数为："+decount);                        
                        if(paymentBranch!=null){
                        	//插入年金账号
                            paymentBranch.setTransno(lcappnt.getTransno());
                        	paymentBranch.setAccbankname(lcappnt.getAppntname());
                    		paymentBranch.setBranch(lcContVo.getAccountBranch());
                        	paymentBranch.setBankaccno(lcContVo.getBankaccno());              	
                        	paymentBranch.setAccountholder("0");
                        	paymentBranchMapper.insert(paymentBranch);
                        }  
                        int y=hubHistoryMapper.deleteByPrimaryKey(applyBean.getTransno());
                        System.out.println("HUB历史数据删除，删除条数为："+y);
                      //插入HUB数据
                        HubHistory hubHistory=new   HubHistory();
                        hubHistory.setTransno(applyBean.getTransno());//流水号
                        hubHistory.setInsucom(insurancecom);//保险公司
                        if(ldcustomer!=null){
                        	if(!"N".equals(ldcustomer.getGoaltype())){
                        		hubHistory.setGoaltype(ldcustomer.getGoaltype());//需求类型    
                        	}
                        	if(StringUtils.isNotBlank(ldcustomer.getRisklevel())
                        			&&!"N".equals(ldcustomer.getRisklevel())){
                        		System.out.println("保存客户风险等级："+ldcustomer.getRisklevel());
                        		hubHistory.setRiskLevel(ldcustomer.getRisklevel());
                        	}
                                           	                          
                        }                      
                        if(ldcustomeraccount!=null){
                        hubHistory.setAnotherholderidno(ldcustomeraccount.getAnotherHolderIdNo());
                        hubHistory.setAnotherholderidtype(ldcustomeraccount.getAnotherHolderIdType());
                        hubHistory.setAnotherholdername(ldcustomeraccount.getAnotherHolderName());
                        }
                        int x=hubHistoryMapper.insert(hubHistory);
                        System.out.println("HUB数据入库成功，条数："+x);
                    }
                }
            } else {
				String transno = null;
            	//新单
            	if("Y".equals(recordingFlag)){ //补录单，投保单号手动输入
            		logger.info("===ANZL====本投保单为补录单，当前进入插入投保单号步骤=======");
            		String proposalcontnoDIY = formdata.getLccont().getProposalcontno(); //获取页面输入的投保单号
            		 try {
            			 lcContVo.setProposalcontno(proposalcontnoDIY); //set投保单号
                         LCContVo proposalcontnoLccont = newContEnterDao.selectLccontToProposalcontno(proposalcontnoDIY); //查询投保单号是否重复
                         if (proposalcontnoLccont != null) {
                         	contFormStatus.setFlag(false);
                         	contFormStatus.setDesc("该投保单号已存在，请返回【投保单基本信息】页重新输入投保单号！");
                            return returnVueForm;
                         }
                     } catch (Exception e) {
                    	 logger.error("查询投保单号发生异常" + e.getMessage());
                     	 e.printStackTrace();
                         contFormStatus.setFlag(false);
                         contFormStatus.setDesc("查询投保单号发生异常: " + e.getMessage());
                         return returnVueForm;
                     }
					transno=newContEnterDao.selectTransno(); //获取流水号
            	}else {
					if (StringUtils.isNotBlank(applyBean.getPaperTransno())) {//预录单转新单
						lcContVo.setProposalcontno(applyBean.getPaperContno());
						transno = applyBean.getPaperTransno();
					} else {
						//正常新单
						PageListBean pageList1 = newContEnterService
								.selectByContno1(tUserLoginInfo, formdata.getLccont().getInsurancecom());
						String proposalcontno = pageList1.getParm();
						if (pageList1.isSuccess() == true) {
							lcContVo.setProposalcontno(proposalcontno);
							try {
								LCContVo selectLccontToProposalcontno
										= newContEnterDao.selectLccontToProposalcontno(pageList1.getParm());
								if (selectLccontToProposalcontno != null) {
									contFormStatus.setFlag(false);
									contFormStatus.setDesc("获取投保单号重复");
									return returnVueForm;
								}
							} catch (Exception e) {
								logger.error("查询投保单号发生异常" + e.getMessage());
								e.printStackTrace();
								contFormStatus.setFlag(false);
								contFormStatus.setDesc("查询投保单号发生异常: " + e.getMessage());
								return returnVueForm;
							}
						} else {
							contFormStatus.setDesc(pageList1.getMsg());
							contFormStatus.setFlag(false);
							return returnVueForm;
						}
						transno = newContEnterDao.selectTransno();
					}
				}
                applyBean.setTransno(transno);
                lcContVo.setTransno(transno);
                lcContVo.setAcctType("个人结算账户");
                lcContVo.setNewpaymode("1");//首期缴费方案    1->自动转账
                lcContVo.setPaylocation("1");//续期缴费方案     1->自动转账
                lcContVo.setDepositBank(lcContVo.getBankaccno().replaceAll("[a-zA-Z]", "").substring(0,3));
				if(StringUtils.isNotBlank(applyBean.getPaperTransno())){//预录单转新单

				}else {
					String appntno = newContEnterDao.selectAppntno();
					lcContVo.setAppntno(appntno);
					String insuredno = lcinsuredVoDao.selectINSUREDNO();
					lcContVo.setInsuredno(insuredno);
				}
                lcContVo.setContno(lcContVo.getProposalcontno());
                lcContVo.setPrtno(lcContVo.getProposalcontno());//保存投保单号
                lcContVo.setManagecom(tUserLoginInfo.getCompanyCode());
                lcContVo.setAccname(lcappnt.getAppntname()); //新单AccName
                lcContVo.setSalechnl("3");
                lcContVo.setSelltype("08");//销售方式
                lcContVo.setPoltype("0");
                lcContVo.setConttype("1");
                lcContVo.setForceuwflag("0");
                //投保单状态
                lcContVo.setAppflag("01");//未承保状态
                //设置投保单/保单标志
                lcContVo.setState("00");
                lcContVo.setChargecode("W");
                lcContVo.setDebitflag("0");
                lcContVo.setHesitationflag("0");
                lcContVo.setOperator(tUserLoginInfo.getEmplID());//操作员
                lcContVo.setModifydate(PubFun.getCurrentDate());
                lcContVo.setModifytime(PubFun.getCurrentTime());//录入时间
                lcContVo.setMakedate(PubFun.getCurrentDate());//录入日期
                lcContVo.setMaketime(PubFun.getCurrentTime());//录入时间
                //添加goalType
//                ldcustomerDao.updateLdcustomer(ldcustomer);                                         
                int i = newContEnterDao.saveLCContBean(lcContVo);
                if(i==1){
                	lcappnt.setAppntage(CommFomat.getAgeByBirthday(lcappnt.getAppntbirthday()));
                    lcappnt.setTransno(transno);
                    lcappnt.setContno(lcContVo.getContno());
                    lcappnt.setPrtno(lcContVo.getContno());
                    lcappnt.setAppntno(lcContVo.getAppntno());
                    lcappnt.setGrpcontno(lcContVo.getGrpcontno());
                    lcappnt.setOperator(tUserLoginInfo.getEmplID());
                    lcappnt.setMakedate(PubFun.getDate(PubFun.getCurrentDate()));
                    lcappnt.setMaketime(PubFun.getCurrentTime());
                    lcappnt.setModifydate(PubFun.getDate(PubFun.getCurrentDate()));
                    lcappnt.setModifytime(PubFun.getCurrentTime());
                    int j  = newContEnterDao.saveLCAppntBean(lcappnt);
                    if(j==1){
                        lcaddress.setTransno(transno);//保存交易流水号
                        lcaddress.setCustomerno(lcContVo.getGrpcontno());
                        lcaddress.setAddressno(new BigDecimal(0));
                        lcaddress.setOperator(tUserLoginInfo.getEmplID());
                        lcaddress.setMakedate(PubFun.getCurrentDate());
                        lcaddress.setMaketime(PubFun.getCurrentTime());
                        lcaddress.setModifydate(PubFun.getCurrentDate());
                        lcaddress.setModifytime(PubFun.getCurrentTime());
                        lcaddressVoDao.insertSelective_anzl(lcaddress);
                     
                        if(paymentBranch!=null){
                        	//插入年金账号
                            paymentBranch.setTransno(lcappnt.getTransno());
                        	paymentBranch.setAccbankname(lcappnt.getAppntname());
                    		paymentBranch.setBranch(lcContVo.getAccountBranch());
                        	paymentBranch.setBankaccno(lcContVo.getBankaccno());                	
                        	paymentBranch.setAccountholder("0");
                        	paymentBranchMapper.insert(paymentBranch);
                        }         
                        //插入HUB数据
                        HubHistory hubHistory=new   HubHistory();
                        hubHistory.setTransno(transno);//流水号
                        hubHistory.setInsucom(insurancecom);//保险公司
                        if(ldcustomer!=null){
                        	if(!"N".equals(ldcustomer.getGoaltype())){
                        		hubHistory.setGoaltype(ldcustomer.getGoaltype());//需求类型    
                        	}
                        	if(StringUtils.isNotBlank(ldcustomer.getRisklevel())
                        			&&!"N".equals(ldcustomer.getRisklevel())){
                        		System.out.println("保存客户风险等级："+ldcustomer.getRisklevel());
                        		hubHistory.setRiskLevel(ldcustomer.getRisklevel());
                        	}
                                           	                          
                        }                        
                        if(ldcustomeraccount!=null){
                        hubHistory.setAnotherholderidno(ldcustomeraccount.getAnotherHolderIdNo());
                        hubHistory.setAnotherholderidtype(ldcustomeraccount.getAnotherHolderIdType());
                        hubHistory.setAnotherholdername(ldcustomeraccount.getAnotherHolderName());
                        }
                        int x=hubHistoryMapper.insert(hubHistory);
                        System.out.println("HUB数据入库成功，条数："+x);
                }
               }
            }
            formdata.setLccont(lcContVo);
            
            if("S".equals(applyBean.getBrhQRFlag()) || "Y".equals(applyBean.getBrhQRFlag())){
            	 //将分行QR创建的投保单流水号存入session
                request.getSession().setAttribute("h5tkTransNo", lcContVo.getTransno());
            }
            
        } catch (Exception e) {
        	logger.error("投保人信息,保单基本信息更新失败：" + e.getMessage());
        	e.printStackTrace();
        	 contFormStatus.setDesc("投保人信息,保单基本信息更新失败：" + e.getMessage());
            contFormStatus.setFlag(false);
            return returnVueForm;
        }
        
        if(formdata.getNewContApply().getCurrentSIDIndex()>=2){
        	if("8".equals(formdata.getLcinsured().getRelationtoappnt())){
 
        		formdata.getNewContApply().setNextcurrentSIDindex(2);
        	}
        }else{
        	formdata.getNewContApply().setNextcurrentSIDindex(0);
        }

        return returnVueForm;
    }
	    //地址信息mapping
		private void mappingadd(Ldcustomeraddress ldcustomeraddress, lcaddressVo lcaddress){
			if(ldcustomeraddress !=null){								
				//通讯地址				
				String contact = "";
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactaddresstype())){
					contact = ldcustomeraddress.getContactaddresstype();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactprovince())){
					contact =contact+ldcustomeraddress.getContactprovince();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactcity())){
					contact =contact+ldcustomeraddress.getContactcity();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactdistrict())){
					contact =contact+ldcustomeraddress.getContactdistrict();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactdetailedaddress())){
					contact =contact+ldcustomeraddress.getContactdetailedaddress();
				}
               try {
            	   if(!CommonUtil.isEmpty(contact)){
            		  String contact_countrycode = ldcustomeraddress.getContact_countrycode();
            		   if(!CommonUtil.isEmpty(contact_countrycode)){
            			   if("CN".equals(contact_countrycode)||"HK".equals(contact_countrycode)
            					   ||"MO".equals(contact_countrycode)||	"TW".equals(contact_countrycode)){           				 
            				    Map<String,String> map = detailedaddress(contact);
            				    lcaddress.setPostprovince(map.get("province"));
        						lcaddress.setPostcity(map.get("city"));
        						lcaddress.setPostdistrict(map.get("area"));		
        						lcaddress.setPostaladdress(map.get("village"));
            				   
            			   }else{
            				   lcaddress.setPostaladdress(contact);  
            			   }
            			 } else{
              	        	 if(contact.contains("中国")||contact.contains("台湾")||contact.contains("香港")
              	        			||contact.contains("澳门")){
              	        		Map<String,String> map = detailedaddress(contact);
             				    lcaddress.setPostprovince(map.get("province"));
         						lcaddress.setPostcity(map.get("city"));
         						lcaddress.setPostdistrict(map.get("area"));		
         						lcaddress.setPostaladdress(map.get("village"));
         					}else{
         						lcaddress.setPostaladdress(contact);
         					}   
              	         } 
            		   }       				
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("通讯地址映射异常");
				}
								
	      }
		
		}
		
		//截取详细地址
		//截取详细地址
		private Map<String,String> detailedaddress (String address){
			Map<String,String>  row=new LinkedHashMap<String,String>();
			try {
				List<String> municipality = Arrays.asList("北京市","上海市","重庆市","天津市");					
				 List<Map<String,String>> list = AddressSplitUtil.addressResolution(address);
				   if(list!=null&&list.size()>0){
					   Map<String,String> addressMap =list.get(0);
					   String province = addressMap.get("province");
					   String city =null;
					   if(municipality.contains(province)){
						  city = addressMap.get("province");   
					   }else{
						   city = addressMap.get("city");
					   }				  
					   String area = addressMap.get("area");
					   String village = addressMap.get("village");
					   if(CommonUtil.isEmpty(province)||CommonUtil.isEmpty(city)||CommonUtil.isEmpty(area)){
						   row.put("village", address);
					   }else{
						   String provincecode =null,citycode=null,areacode=null;
						   provincecode =provinceVoMapper.selectbyname(province) ;
						   //当解析出来的省为四大直辖市，由于数据库中四大直辖市省市名字一样
						   if(municipality.contains(province)){
							   citycode = cityVoMapper.selectbyname(province);  
						   }else{
							   citycode = cityVoMapper.selectbyname(city);
						   }
						   if(!CommonUtil.isEmpty(citycode)){
							   areacode= countyVoMapper.selectbyname(area,citycode);
						   }
						   //当其中任意一个code为空，则为不规则的地址信息，返回整条信息
						   if(CommonUtil.isEmpty(provincecode)||CommonUtil.isEmpty(citycode)||CommonUtil.isEmpty(areacode)){
							   row.put("village", address);
						   }else{
							   row.put("province", provincecode) ;
							   row.put("city", citycode);
							   row.put("area", areacode);
							   row.put("village", village);
						   } 
						   
					   }
					}else{
						row.put("village", address);
					}
		} catch (Exception e) {
			e.printStackTrace();
			row.put("village", address);
		}						
			return row;			
		}

	/**
	 * HUB塞值
	 */
	private void setHubAddressDetail(Ldcustomeraddress ldcustomeraddress, lcaddressVo lcaddress, Ldcustomer ldcustomer){
		
		/*LdcodeVo mobile_countrycode = new LdcodeVo();
			
		if(!CommonUtil.isEmpty(ldcustomer.getCountryCode_home())){
			//根据code CN 获取 86
			 LdcodeVo ldcode = new LdcodeVo();
			 ldcode.setCodetype("countrycode");
     		 ldcode.setCode(ldcustomer.getCountryCode_home());
			 mobile_countrycode = ldcodeDao.selectldcode(ldcode);
			 if(mobile_countrycode == null){
				 mobile_countrycode = new LdcodeVo();
			 }
         }
                             	          			
         if(!CommonUtil.isEmpty(ldcustomer.getMobile_home())){
         	if(!CommonUtil.isEmpty(ldcustomer.getCountryCode_home())){
             	lcaddress.setCountrycodetel_mob(mobile_countrycode.getCodealias());                      	
             }
         	lcaddress.setMobile(ldcustomer.getMobile_home());
         }else{
         	if(ldcustomer.getMobilephoneno()!=null){
         		if(!CommonUtil.isEmpty(ldcustomer.getCountryCode_home())){                         			 
                 	lcaddress.setCountrycodetel_mob(mobile_countrycode.getCodealias());                      	
                 }
               lcaddress.setMobile(ldcustomer.getMobilephoneno());
           }
         }*/
		
		if(lcaddress != null){
			
			if(!CommonUtil.isEmpty(ldcustomer.getMobile_home())){
	         	lcaddress.setHubMobile(ldcustomer.getMobile_home());
	        }else{
	         	if(ldcustomer.getMobilephoneno()!=null){
	               lcaddress.setHubMobile(ldcustomer.getMobilephoneno());
	            }
	        }
			
			if(ldcustomeraddress != null){
				//通讯地址			
				String contact = "";
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactaddresstype())){
					contact = ldcustomeraddress.getContactaddresstype();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactprovince())){
					contact =contact+ldcustomeraddress.getContactprovince();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactcity())){
					contact =contact+ldcustomeraddress.getContactcity();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactdistrict())){
					contact =contact+ldcustomeraddress.getContactdistrict();
				}
				if(!CommonUtil.isEmpty(ldcustomeraddress.getContactdetailedaddress())){
					contact =contact+ldcustomeraddress.getContactdetailedaddress();
				}
	           try {
	        	   if(!CommonUtil.isEmpty(contact)){
	        		  String contact_countrycode = ldcustomeraddress.getContact_countrycode();
	        		   if(!CommonUtil.isEmpty(contact_countrycode)){
	        			   if("CN".equals(contact_countrycode)||"HK".equals(contact_countrycode)
	        					   ||"MO".equals(contact_countrycode)||	"TW".equals(contact_countrycode)){           				 
	        				    Map<String,String> map = detailedaddress(contact);
	    						lcaddress.setHubContactDetail(map.get("village"));
	        			   }else{
	        				    lcaddress.setHubContactDetail(contact);  
	        			   }
	        			 } else{
	          	        	 if(contact.contains("中国")||contact.contains("台湾")||contact.contains("香港")
	          	        			||contact.contains("澳门")){
	          	        		Map<String,String> map = detailedaddress(contact);
	     						lcaddress.setHubContactDetail(map.get("village"));
	     					}else{
	     						lcaddress.setHubContactDetail(contact);
	     					}   
	          	         } 
	        		   }
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Hub通讯地址映射异常");
				}
	      }
		}else{
			logger.info("Lcaddress对象为空，Hub比对信息初始化失败");
		}
		
		
	
	}
		
		
		
	@Override
	public String getInsuCode() {
		return "ANZL";
	}

	@Override
	public String getSID() {
		return NewContStaticStr.APPNTSID;
	}

}
