package com.sinosoft.service.print.ANZL;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import com.sinosoft.bean.common.FormElement;
import com.sinosoft.bean.common.NoticeFormData;
import com.sinosoft.bean.common.ValueMapBean;
import com.sinosoft.bean.common.VueForm;
import com.sinosoft.bean.newCont.ContFormData;
import com.sinosoft.bean.newCont.NewContStaticStr;
import com.sinosoft.bean.newCont.data.ApplyBean;
import com.sinosoft.core.common.bean.config.SinoProperty;
import com.sinosoft.mvc.newCont.NewContController;
import com.sinosoft.service.api.PubFun;
import com.sinosoft.service.api.TimeFormat;
import com.sinosoft.service.business.db.dao.*;
import com.sinosoft.service.business.db.vo.*;
import com.sinosoft.service.business.ui.contprint.metLife.SpecialProvenceCheck;
import com.sinosoft.service.common.newCont.ImpartConfigService;
import com.sinosoft.service.common.pdfprint.PdfItextBean;
import com.sinosoft.service.common.pdfprint.PdfPrintForItextImpl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
public class PdfPrintANZL extends PdfPrintForItextImpl {

    /**
     * 打印日志
     */
    private static final Logger logger = LoggerFactory
            .getLogger(PdfPrintANZL.class);

    @Resource
    private SinoProperty sinoProperty;
    @Resource
    LdoccupationVoMapper ldoccupationVoMapper;
    @Resource
    private NewContController newContController;
    @Resource
    private LMRiskParamsDefADao lmriskParamsDefADao;
    @Resource
    private LdcodeDao ldcodeDao;
    @Resource
    private NewContEnterDao enterDao;
    @Resource
    private LdPathDao ldpathDao;
    @Resource
    private LcbnfVoDao bnfVoDao;
    @Resource
    private RelevantMapper relevantMapper;
    @Resource
    private LmriskDao lmriskDao;
    @Resource
    private lcpolVoMapper lcpolDao;
    @Resource
    private RiskReletionInsuredDao riskReletionInsuredDao;
    @Autowired
    private PaymentBranchMapper paymentbranchMapper;
    @Autowired
    private ProvinceVoMapper proviceDao;
    @Autowired
    private CityVoMapper cityDao;
    @Autowired
    private CountyVoMapper countyDao;
    @Autowired
    private LCAccountInfoVoMapper lCAccountInfoVoMapper;
    @Autowired
    private LdcomVoMapper ldcomVoMapper;
    @Autowired
	private ImpartConfigService impartConfigService;
    @Autowired
	private FormelementMapper formelementMapper;

    @Override
    public ValueMapBean getValueMapBean() {
        ValueMapBean valueMapBean = new ValueMapBean();
        valueMapBean.addJsonMapEle("bnf.sex", "0", "男");
        valueMapBean.addJsonMapEle("bnf.sex", "1", "女");
        valueMapBean.addJsonMapEle("noticeinfos.owneryesorno", "Y", "是");
        valueMapBean.addJsonMapEle("noticeinfos.owneryesorno", "N", "否");
        valueMapBean.addJsonMapEle("noticeinfos.insuredyesorno", "Y", "是");
        valueMapBean.addJsonMapEle("noticeinfos.insuredyesorno", "N", "否");
        valueMapBean.addJsonMapEle("noticeinfos.insuredyesorno2", "Y", "是");
        valueMapBean.addJsonMapEle("noticeinfos.insuredyesorno2", "N", "否");
        valueMapBean.addJsonMapEle("noticeinfos.noticeinfos.insuredyesorno", "Y", "是");
        valueMapBean.addJsonMapEle("noticeinfos.noticeinfos.insuredyesorno", "N", "否");
        return valueMapBean;
    }

    @Override
    public PdfItextBean getPDF(Object... obj) throws IOException {


        PdfItextBean pdfStamper = null;
        try {
            ContFormData returnFormData = getFormData(
                    (HttpServletRequest) obj[0], (String) obj[1],
                    (String) obj[2], (String) obj[3]);
            // 生成文件的路径
            String pdfpath = ldpathDao.selectByKey("41").getCodeValue();
//			String pdfpath = "D:\\appvol\\ybt\\downloadfiles\\printinfo\\combine";
            File file = new File(pdfpath);
            if (file.exists()) {
                pdfpath = pdfpath + File.separator
                        + returnFormData.getLccont().getProposalcontno();
                File fileChild = new File(pdfpath);
                if (!fileChild.exists()) {
                    fileChild.mkdir();
                }
                logger.info("path:" + pdfpath);

            } else {
                throw new IOException(pdfpath + "目录有误");
            }
            // 通用处理
            pdfStamper = getFillFormFieldPDF(returnFormData, pdfpath + File.separator + returnFormData.getLccont().getProposalcontno() + ".pdf");

            // 生成PDF

        } catch (Exception e) {
            e.printStackTrace();
            throw new IOException(e);
        } finally {

        }
        return pdfStamper;

    }

    @Override
    public String getFormTemplate() {
        Properties fontproperties = sinoProperty.getProMap().get(
                "pdfprint_properties");
        return fontproperties.getProperty("ANZL_template");
    }

    private ContFormData getFormData(HttpServletRequest request,
                                     String transno, String riskcode, String grpcontno) {

        String insurancecom = "ANZL";

        VueForm returnVueForm = new VueForm();

        ContFormData returnFormData = new ContFormData();
        returnVueForm.setFormdata(returnFormData);

        ApplyBean applyBean = new ApplyBean();
        applyBean.setTransno(transno);
        applyBean.setRiskcode(riskcode);
        applyBean.setGrpcontno(grpcontno);
        returnFormData.setNewContApply(applyBean);
        returnFormData = newContController.getAllFormData(request, transno,
                insurancecom, returnVueForm);

        //一年期不打印税收
        if("1Y".equals(returnFormData.getLcpol().getInsuyear())){
            List<TAXTIN> taxtins = new ArrayList<>();
            returnFormData.getLcappnt().setTaxtype(null);
            returnFormData.getLcappnt().setTaxtins(taxtins);

            returnFormData.getLcinsured().setTaxtype(null);
            returnFormData.getLcinsured().setTaxtins(taxtins);

            returnFormData.getLcinsuredtwo().setTaxtype(null);
            returnFormData.getLcinsuredtwo().setTaxtins(taxtins);

            List<OtherInsuredVo> otherInsuredList = returnFormData.getOtherinsured();
            for (OtherInsuredVo otherInsuredVo :otherInsuredList) {
                otherInsuredVo.setTaxtype(null);
                otherInsuredVo.setTaxtins(taxtins);
            }
        }

        return returnFormData;
    }

    @Override
    public String getDateformat() {
        return "yyyy/MM/dd";
    }

    /***
     * 获取保险期间
     * @param lcpolVo
     * @return
     */
    private String getInsuYear(lcpolVo lcpolVo) {
    	String insuyear = "";
    	if (lcpolVo != null){
            insuyear = lcpolVo.getInsuyear();
            LmriskparamsdefaVo defavo = new LmriskparamsdefaVo();
            defavo.setRiskcode(lcpolVo.getRiskcode());
            defavo.setParamstype("insuyear");
            defavo.setParamscode(insuyear);
        logger.info("保险期间代号" + insuyear);
        
        if (null != insuyear &&null != lcpolVo.getRiskcode() ) {
            //Y4、B9类 改成可配置化，配置了保险期间（年）输入框的产品取insuyearY4字段
     		List<LmriskparamsdefaVo> params=lmriskDao.QueryParam(lcpolVo.getRiskcode(), "insuyearY4", "Y");
     		
     		if(params.size()>0&&null!=lcpolVo.getInsuyearY4()){//保险期间输入框取值
     			 insuyear = lcpolVo.getInsuyearY4();
             }else{
         	   if (null != lmriskParamsDefADao.selectlmriskParamsDef(defavo)){//保险期间下拉框取值
         		 
                  insuyear = lmriskParamsDefADao.selectlmriskParamsDef(defavo).getParamsname();
                }
         }
     }
     }  
         return insuyear;
    }


    /**
     * 获取付费期间
     *
     * @param lcpolVo
     * @return
     */
    private String getPayendyear(lcpolVo lcpolVo) {

        String payendyear = lcpolVo.getPayendyear();
        if (("0Y").equals(payendyear)) {
            payendyear = "趸交";
        } else if (payendyear != null) {
            System.out.println("保费支付期" + payendyear);
            payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
        }
        return payendyear;
    }

    /**
     * 保险计划改大写
     * @param lcpolVo
     * @return
     */
    private String getPlan(lcpolVo lcpolVo){
        String plan = lcpolVo.getPlan();
        if ("1".equals(plan)){
            plan = "计划一";
        }else if("2".equals(plan)){
            plan = "计划二";
        }else if ("3".equals(plan)){
            plan = "计划三";
        }
        return plan;
    }
    @Override
    public void setSpecialCode(Object valueObj, PdfItextBean pdfStamper)
            throws IOException {
        ContFormData returnFormData = (ContFormData) valueObj;
        //渠道
        String commonchannel = returnFormData.getLccont().getCommonchannel();
        Date polapplydate = returnFormData.getLccont().getPolapplydate();
        if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
            setSigleValue("手机银行", pdfStamper, "commonchannel");
            try {
                setSigleValue(PubFun.formatYMD1(polapplydate),pdfStamper,"polapplydate");
            } catch (ParseException e) {
                e.printStackTrace();
            }
        } else if ("BH".equals(commonchannel)) {
            setSigleValue("银保通", pdfStamper, "commonchannel");
        }
        System.out.println("渠道：" + commonchannel + "销售人员编号：" + returnFormData.getLccont().getOperator());
        //这边解决其他被保人第一个为空的情况
        Iterator<OtherInsuredVo> iterator = returnFormData.getOtherinsured().iterator();
        while (iterator.hasNext()) {
            OtherInsuredVo otherInsuredVo = (OtherInsuredVo) iterator.next();
            if (otherInsuredVo == null) {
                iterator.remove();
            }
        }

        //基本保险金额为0就不填
        if (returnFormData.getLcpol().getAmnt() != null && "0".equals(returnFormData.getLcpol().getAmnt().toString())){
            setSigleValue("", pdfStamper, "lcpol.amnt");
        }

        String TransNo = returnFormData.getNewContApply().getTransno(); // 交易流水号
        //条形码
        setSigleValue("*" + returnFormData.getLccont().getProposalcontno()
                + "*", pdfStamper, "lccont.barcodetext");
        setSigleValue("*1151*", pdfStamper, "barcode1code");
        setSigleValue("*1152*", pdfStamper, "barcode2code");
        setSigleValue("*4201*", pdfStamper, "side1code");
        setSigleValue("*4202*", pdfStamper, "side2code");
        setSigleValue("*4203*", pdfStamper, "side3code");
        setSigleValue("*4204*", pdfStamper, "side4code");
        setSigleValue("*4205*", pdfStamper, "side5code");
        setSigleValue("*4206*", pdfStamper, "side6code");
        setSigleValue("*4207*", pdfStamper, "side7code");
        setSigleValue("*4208*", pdfStamper, "side8code");
        setSigleValue("*4209*", pdfStamper, "side9code");
        LCContVo contSchema = enterDao.selectBylccont(TransNo);
        //线上还是线下
        if ("12".equals(contSchema.getAppflag())) {
            //e电子p纸质
            if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
                setSigleValue("HSBC Online Application_S", pdfStamper, "lccont.appflag");
            }else if("BH".equals(commonchannel) || "RE".equals(commonchannel)){
                if ("E".equals(returnFormData.getLccont().geteSignFlag())) {
                    setSigleValue("HSBC Online Application_E", pdfStamper, "lccont.appflag");
                }
                if ("P".equals(returnFormData.getLccont().geteSignFlag())) {
                    setSigleValue("HSBC Online Application_P", pdfStamper, "lccont.appflag");
                }
            }
        } else if ("09".equals(contSchema.getAppflag()) || "14".equals(contSchema.getAppflag())) {
            //e电子p纸质
            if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
                setSigleValue("HSBC Offline Application_S", pdfStamper, "lccont.appflag");
            }else if("BH".equals(commonchannel) || "RE".equals(commonchannel)){
                if ("E".equals(returnFormData.getLccont().geteSignFlag())) {
                    setSigleValue("HSBC Offline Application_E", pdfStamper, "lccont.appflag");
                }
                if ("P".equals(returnFormData.getLccont().geteSignFlag())) {
                    setSigleValue("HSBC Offline Application_P", pdfStamper, "lccont.appflag");
                }
            }
        }


        /**
         * 投保人
         */
        if (returnFormData.getLcappnt() != null) {
            lcaddressVo lcappntaddress = returnFormData.getLcappntaddress();
            //投保人行业类型
            setSigleValue(ldoccupationVoMapper.selectByOccupationcode(returnFormData.getLcappnt().getOccupationcode(), "AL").getOccupationname2(), pdfStamper, "lcappnt.industrytype");
            //投保人具体工作
            setSigleValue(ldoccupationVoMapper.selectByOccupationcode(returnFormData.getLcappnt().getOccupationcode(), "AL").getOccupationname(), pdfStamper, "lcappnt.responsibility");
            //投保人居住地址
            String postprovince1 = lcappntaddress.getPostprovince();
            ProvinceVo provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince1));
            provinceVo = SpecialProvenceCheck.check(provinceVo);
            String postcity1 = lcappntaddress.getPostcity();
            CityVo cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity1));
            cityVo = SpecialProvenceCheck.checkCity(cityVo);
            String postArea = lcappntaddress.getPostdistrict();
            CountyVo countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
            String postdetail = lcappntaddress.getPostaladdress();
            String appntResidentialAddress = provinceVo.getProvincename() + cityVo.getCityname()
                    + countyVo.getCountyname() + postdetail;

            setSigleValue(appntResidentialAddress, pdfStamper,
                    "lcappntaddress.homeaddress");

            setSigleValue(ldcodeDao.selectLdcode("iss_country", returnFormData.getLcappnt().getBirthcounty()).get(0).getCodename(), pdfStamper,
                    "lcappnt.birthcounty");
            //证件长期
            Date date = null;
            try {
                date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Date enddate = returnFormData.getLcappnt().getAppntenddate();
            if (null!=enddate){
                if (date.compareTo(enddate) == 0){
                    setSigleValue("长期",pdfStamper,"lcappnt.appntenddate");
                }
            }

        }

        /**
         * 主被保人，第二被保人，其他被保人
         */
        if (returnFormData.getLcinsured() != null) {
            LdoccupationVo ldoccupationVo = getLdoccupation(returnFormData
                    .getLcinsured().getLcinsuredroccupationcode());

            setSigleValue(ldoccupationVo.getOccupationname2(), pdfStamper,
                    "lcinsured.industrytype");
            setSigleValue(ldoccupationVo.getOccupationname(), pdfStamper,
                    "lcinsured.lcinsuredroccupationcode");

            //主被保人居住地址
            lcaddressVo lcinsuredaddress = returnFormData.getLcinsuredaddress();
            String postprovince1 = lcinsuredaddress.getPostprovince();
            ProvinceVo provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince1));
            provinceVo = SpecialProvenceCheck.check(provinceVo);
            String postcity1 = lcinsuredaddress.getPostcity();
            CityVo cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity1));
            cityVo = SpecialProvenceCheck.checkCity(cityVo);
            String postArea = lcinsuredaddress.getPostdistrict();
            CountyVo countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
            String postdetail = lcinsuredaddress.getPostaladdress();
            String appntResidentialAddress = provinceVo.getProvincename() + cityVo.getCityname()
                    + countyVo.getCountyname() + postdetail;

            setSigleValue(appntResidentialAddress, pdfStamper,
                    "lcinsuredaddress.homeaddress");

            setSigleValue(ldcodeDao.selectLdcode("iss_country", returnFormData.getLcinsured().getLcinsuredbirthcounty()).get(0).getCodename(), pdfStamper,
                    "lcinsured.lcinsuredbirthcounty");

            // 投保人与主被保人关系
            String relationtoappnt = returnFormData.getLcinsured().getRelationtoappnt();
            if (relationtoappnt != null){
                setSigleValue(ldcodeDao.selectLdcode("anzl_relation", relationtoappnt).get(0).getCodename(), pdfStamper, "lcinsured.relationtoappnt");
            }
            //证件长期
            Date date = null;
            try {
                date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Date enddate = returnFormData.getLcinsured().getInsureidenddate();
            if (null!=enddate){
                if (date.compareTo(enddate) == 0){
                    setSigleValue("长期",pdfStamper,"lcinsured.insureidenddate");
                }
            }
        }

//        第二被保人姓名不为空
        if (returnFormData.getLcinsuredtwo() != null && StringUtils.isNotEmpty(returnFormData.getLcinsuredtwo().getLcinsuredname())) {
            lcaddressVo lcinsuredtwoaddress = returnFormData.getLcinsuredtwoaddress();
            LdoccupationVo ldoccupationtwoVo = getLdoccupation(returnFormData
                    .getLcinsuredtwo().getLcinsuredroccupationcode());

            setSigleValue(ldoccupationtwoVo.getOccupationname2(), pdfStamper,
                    "lcinsuredtwo.industrytype");
            setSigleValue(ldoccupationtwoVo.getOccupationname(), pdfStamper,
                    "lcinsuredtwo.lcinsuredroccupationcode");

            String postprovince1 = lcinsuredtwoaddress.getPostprovince();
            ProvinceVo provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince1));
            provinceVo = SpecialProvenceCheck.check(provinceVo);
            String postcity1 = lcinsuredtwoaddress.getPostcity();
            CityVo cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity1));
            cityVo = SpecialProvenceCheck.checkCity(cityVo);
            String postArea = lcinsuredtwoaddress.getPostdistrict();
            CountyVo countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
            String postdetail = lcinsuredtwoaddress.getPostaladdress();
            String appntResidentialAddress = provinceVo.getProvincename() + cityVo.getCityname()
                    + countyVo.getCountyname() + postdetail;

            setSigleValue(appntResidentialAddress, pdfStamper,
                    "lcinsuredtwoaddress.homeaddress");

            setSigleValue(ldcodeDao.selectLdcode("iss_country", returnFormData.getLcinsuredtwo().getLcinsuredbirthcounty()).get(0).getCodename(), pdfStamper,
                    "lcinsuredtwo.lcinsuredbirthcounty");

            //与主被保险人关系
            setSigleValue(ldcodeDao.selectLdcode("anzl_relation", returnFormData.getLcinsuredtwo().getRelatoinsu()).get(0).getCodename(), pdfStamper, "lcinsuredtwo.relatoinsu");

            Calendar c = Calendar.getInstance();
            if (null!=returnFormData.getLcinsuredtwo().getInsureidenddate()){
                c.setTime(returnFormData.getLcinsuredtwo().getInsureidenddate());
                setSigleValue(String.valueOf(c.get(Calendar.YEAR)),
                        pdfStamper, "lcinsuredtwo.year");
                setSigleValue(String.valueOf(c.get(Calendar.MONTH) + 1),
                        pdfStamper, "lcinsuredtwo.month");
                setSigleValue(String.valueOf(c.get(Calendar.DAY_OF_MONTH)),
                        pdfStamper, "lcinsuredtwo.day");
            }

            //证件长期
            Date date = null;
            try {
                date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Date enddate = returnFormData.getLcinsuredtwo().getInsureidenddate();
            if (null!=enddate){
                if (date.compareTo(enddate) == 0){
                    setSigleValue("长期",pdfStamper,"lcinsuredtwo.insureidenddate");
                }
            }
        }

        if (returnFormData.getOtherinsured() != null) {
            int otherindex = 0;
            for (OtherInsuredVo otherInsuredVo : returnFormData.getOtherinsured()) {
                if (otherInsuredVo == null  || StringUtils.isEmpty(otherInsuredVo.getLcinsuredname())){
                    continue;
                }
                LdoccupationVo ldoccupationotherVo = getLdoccupation(otherInsuredVo.getLcinsuredroccupationcode());

                setSigleValue(ldoccupationotherVo.getOccupationname2(), pdfStamper,
                        "otherinsured[" + otherindex + "].industrytype");
                setSigleValue(ldoccupationotherVo.getOccupationname(), pdfStamper,
                        "otherinsured[" + otherindex + "].lcinsuredroccupationcode");
                try {
                    OtherInsuredLcaddressVo otherInsuredLcaddress = otherInsuredVo.getOtherInsuredLcaddress();
                    String postprovince1 = otherInsuredLcaddress.getPostprovince();
                    ProvinceVo provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince1));
                    provinceVo = SpecialProvenceCheck.check(provinceVo);
                    String postcity1 = otherInsuredLcaddress.getPostcity();
                    CityVo cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity1));
                    cityVo = SpecialProvenceCheck.checkCity(cityVo);
                    String postArea = otherInsuredLcaddress.getPostdistrict();
                    CountyVo countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
                    String postdetail = otherInsuredLcaddress.getPostaladdress();
                    String appntResidentialAddress = provinceVo.getProvincename() + cityVo.getCityname()
                            + countyVo.getCountyname() + postdetail;
                    setSigleValue(appntResidentialAddress, pdfStamper,
                            "otherinsured[" + otherindex + "].otherInsuredLcaddress.homeaddress");
                } catch (Exception e) {
                    System.out.println("其他被保人中有必填字段为空");
                }
                setSigleValue(ldcodeDao.selectLdcode("iss_country", returnFormData.getOtherinsured().get(otherindex).getLcinsuredbirthcounty()).get(0).getCodename(), pdfStamper,
                        "otherinsured[" + otherindex + "].lcinsuredbirthcounty");

                //与主被保险人关系
                setSigleValue(ldcodeDao.selectLdcode("anzl_relation", returnFormData.getOtherinsured().get(otherindex).getRelatoinsu()).get(0).getCodename(), pdfStamper, "otherinsured[" + otherindex + "].relatoinsu");
                setSigleValue(ldcodeDao.selectLdcode("anzl_relation", returnFormData.getOtherinsured().get(otherindex).getRelatopolicy()).get(0).getCodename(), pdfStamper, "otherinsured[" + otherindex + "].relatopolicy");

                Calendar c = Calendar.getInstance();
                if (null!=returnFormData.getOtherinsured().get(otherindex).getInsureidenddate()){
                    c.setTime(returnFormData.getOtherinsured().get(otherindex).getInsureidenddate());
                    setSigleValue(String.valueOf(c.get(Calendar.YEAR)),
                            pdfStamper, "otherinsured[" + otherindex + "].year");
                    setSigleValue(String.valueOf(c.get(Calendar.MONTH) + 1),
                            pdfStamper, "otherinsured[" + otherindex + "].month");
                    setSigleValue(String.valueOf(c.get(Calendar.DAY_OF_MONTH)),
                            pdfStamper, "otherinsured[" + otherindex + "].day");
                }

                //证件长期
                Date date = null;
                try {
                    date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Date enddate = returnFormData.getOtherinsured().get(otherindex).getInsureidenddate();
                if (null!=enddate){
                    if (date.compareTo(enddate) == 0){
                        setSigleValue("长期",pdfStamper,"otherinsured[" + otherindex + "].insureidenddate");
                    }
                }

                otherindex++;

            }

        }

        //医疗险不打印受益人
        if(!"11".equals(returnFormData.getLcpol().getConttype())){
            /**
             * 受益人
             */
            List<LcbnfVo> bnfSet = bnfVoDao.selectByPrimaryKey(TransNo);
            if (bnfSet.isEmpty()) {
                setSigleValue("法定受益人", pdfStamper,
                        "bnfs[0].name");
            }
            if (null != bnfSet && bnfSet.size() != 0) {

                int firstbnfindex = 0;
                int secondbnfindex = 2;
                int bothbifindex = 4;
                for (LcbnfVo lcbnfVo : bnfSet) {

                    String bnfno = lcbnfVo.getBnfno().toString();
                    List<Relevant> relevants = relevantMapper.selRelBytransnoandbnfno(TransNo, bnfno);
                    for (Relevant relevant : relevants) {
                        String insuid = relevant.getInsuid();
                        System.out.println("第几被保人" + insuid + "**");
                        try {

                            // 代表是第一被保人受益人
                            if ("1".equals(insuid)) {
                                // 身故受益人姓名
                                setSigleValue(lcbnfVo.getName(), pdfStamper,
                                        "bnfs[" + firstbnfindex + "].name");
                                // 身故受益人性别
                                setSigleValue("0".equals(lcbnfVo.getSex()) ? "男" : "女", pdfStamper,
                                        "bnfs[" + firstbnfindex + "].sex");
                                // 身故受益人证件类型
                                String codename = ldcodeDao.selectLdcode("idtype", lcbnfVo.getIdtype()).get(0)
                                        .getCodename().replaceAll("(.*?)\\/.*", "$1");
                                setSigleValue(codename, pdfStamper,
                                        "bnfs[" + firstbnfindex + "].idtype");
                                // 身故受益人证件号码
                                if (null != lcbnfVo && null != lcbnfVo.getIdno()){
                                    setSigleValue(lcbnfVo.getIdno(), pdfStamper,
                                            "bnfs[" + firstbnfindex + "].idno");
                                }
                                // 身故受益人证件号码/换证次数
//                            if (StringUtils.isNotBlank(lcbnfVo.getRenewCount())){
//                                setSigleValue(lcbnfVo.getIdno()+"/"+lcbnfVo.getRenewCount(), pdfStamper,
//                                        "bnfs[" + firstbnfindex + "].idno");
//                            }else{
//                                setSigleValue(lcbnfVo.getIdno(), pdfStamper,
//                                        "bnfs[" + firstbnfindex + "].idno");
//                            }
                                // 身故受益人出生日期
                                setSigleValue(TimeFormat.TimeDateFormat2(lcbnfVo.getBirthday()), pdfStamper,
                                        "bnfs[" + firstbnfindex + "].birthday");
                                // 身故受益人与被保人关系
                                setSigleValue(ldcodeDao.selectLdcode("anzl_relation", relevant.getRelationtoinsured()).get(0)
                                                .getCodename(), pdfStamper,
                                        "bnfs[" + firstbnfindex + "].relationtoinsured");
                                // 身故受益人受益比例
                                setSigleValue(String.valueOf(relevant.getBnflot()), pdfStamper,
                                        "bnfs[" + firstbnfindex + "].bnflot");
                                //受益人证件有效起期
                                if (null!=lcbnfVo.getStartingDate()){
                                    setSigleValue(PubFun.formatYMD1(lcbnfVo.getStartingDate()), pdfStamper,
                                            "bnfs[" + firstbnfindex + "].startingDate");
                                }
                                //受益人证件有效期
                                if ("9999-01-01".equals(lcbnfVo.getBnfvalidYear())){
                                    setSigleValue("长期", pdfStamper,
                                            "bnfs[" + firstbnfindex + "].bnfvalidYear");
                                }else{
                                    setSigleValue(lcbnfVo.getBnfvalidYear(), pdfStamper,
                                            "bnfs[" + firstbnfindex + "].bnfvalidYear");
                                }
                                firstbnfindex++;
                            }

                            if ("2".equals(insuid)) {                            // 身故受益人姓名
                                setSigleValue(lcbnfVo.getName(), pdfStamper,
                                        "bnfs[" + secondbnfindex + "].name");
                                // 身故受益人性别
                                setSigleValue("0".equals(lcbnfVo.getSex()) ? "男" : "女", pdfStamper,
                                        "bnfs[" + secondbnfindex + "].sex");
                                // 身故受益人证件类型
                                String codename = ldcodeDao.selectLdcode("idtype", lcbnfVo.getIdtype()).get(0)
                                        .getCodename().replaceAll("(.*?)\\/.*", "$1");
                                setSigleValue(codename, pdfStamper,
                                        "bnfs[" + secondbnfindex + "].idtype");
                                // 身故受益人证件号码
                                if (null != lcbnfVo && null != lcbnfVo.getIdno()){
                                    setSigleValue(lcbnfVo.getIdno(), pdfStamper,
                                            "bnfs[" + secondbnfindex + "].idno");
                                }
                                // 身故受益人证件号码/换证次数
//                            if (StringUtils.isNotBlank(lcbnfVo.getRenewCount())){
//                                setSigleValue(lcbnfVo.getIdno()+"/"+lcbnfVo.getRenewCount(), pdfStamper,
//                                        "bnfs[" + secondbnfindex + "].idno");
//                            }else{
//                                setSigleValue(lcbnfVo.getIdno(), pdfStamper,
//                                        "bnfs[" + secondbnfindex + "].idno");
//                            }
                                // 身故受益人出生日期
                                setSigleValue(TimeFormat.TimeDateFormat2(lcbnfVo.getBirthday()), pdfStamper,
                                        "bnfs[" + secondbnfindex + "].birthday");
                                // 身故受益人与被保人关系
                                setSigleValue(ldcodeDao.selectLdcode("anzl_relation", relevant.getRelationtoinsured()).get(0)
                                                .getCodename(), pdfStamper,
                                        "bnfs[" + secondbnfindex + "].relationtoinsured");
                                // 身故受益人受益比例
                                setSigleValue(String.valueOf(relevant.getBnflot()), pdfStamper,
                                        "bnfs[" + secondbnfindex + "].bnflot");
                                //受益人证件有效起期
                                if (null !=lcbnfVo.getStartingDate()){
                                    setSigleValue(PubFun.formatYMD1(lcbnfVo.getStartingDate()), pdfStamper,
                                            "bnfs[" + secondbnfindex + "].startingDate");
                                }
                                //受益人证件有效期
                                if ("9999-01-01".equals(lcbnfVo.getBnfvalidYear())){
                                    setSigleValue("长期", pdfStamper,
                                            "bnfs[" + secondbnfindex + "].bnfvalidYear");
                                }else{
                                    setSigleValue(lcbnfVo.getBnfvalidYear(), pdfStamper,
                                            "bnfs[" + secondbnfindex + "].bnfvalidYear");
                                }
                                secondbnfindex++;
                            }

                            if ("1,2".equals(insuid)) {                            // 身故受益人姓名
                                setSigleValue(lcbnfVo.getName(), pdfStamper,
                                        "bnfs[" + bothbifindex + "].name");
                                // 身故受益人性别
                                setSigleValue("0".equals(lcbnfVo.getSex()) ? "男" : "女", pdfStamper,
                                        "bnfs[" + bothbifindex + "].sex");
                                // 身故受益人证件类型
                                String codename = ldcodeDao.selectLdcode("idtype", lcbnfVo.getIdtype()).get(0)
                                        .getCodename().replaceAll("(.*?)\\/.*", "$1");
                                setSigleValue(codename, pdfStamper,
                                        "bnfs[" + bothbifindex + "].idtype");
                                // 身故受益人证件号码
                                if (null != lcbnfVo && null != lcbnfVo.getIdno()){
                                    setSigleValue(lcbnfVo.getIdno(), pdfStamper,
                                            "bnfs[" + bothbifindex + "].idno");
                                }
                                // 身故受益人证件号码/换证次数
//                            if (StringUtils.isNotBlank(lcbnfVo.getRenewCount())){
//                                setSigleValue(lcbnfVo.getIdno()+"/"+lcbnfVo.getRenewCount(), pdfStamper,
//                                        "bnfs[" + bothbifindex + "].idno");
//                            }else{
//                                setSigleValue(lcbnfVo.getIdno(), pdfStamper,
//                                        "bnfs[" + bothbifindex + "].idno");
//                            }
                                // 身故受益人出生日期
                                setSigleValue(TimeFormat.TimeDateFormat2(lcbnfVo.getBirthday()), pdfStamper,
                                        "bnfs[" + bothbifindex + "].birthday");
                                String[] relationtoinsured1AndTwo = relevant.getRelationtoinsured().split(",");
                                String relation1 = ldcodeDao
                                        .selectLdcode("anzl_relation", relationtoinsured1AndTwo[0].trim()).get(0)
                                        .getCodename();
                                String relation2 = ldcodeDao
                                        .selectLdcode("anzl_relation", relationtoinsured1AndTwo[1].trim()).get(0)
                                        .getCodename();
                                // 身故受益人与被保人关系
                                setSigleValue(relation1 + "/" + relation2, pdfStamper,
                                        "bnfs[" + bothbifindex + "].relationtoinsured");
                                // 身故受益人受益比例
                                setSigleValue(String.valueOf(relevant.getBnflot()), pdfStamper,
                                        "bnfs[" + bothbifindex + "].bnflot");
                                //受益人证件有效起期
                                if (null!=lcbnfVo.getStartingDate()){
                                    setSigleValue(PubFun.formatYMD1(lcbnfVo.getStartingDate()), pdfStamper,
                                            "bnfs[" + bothbifindex + "].startingDate");
                                }
                                //受益人证件有效期
                                if ("9999-01-01".equals(lcbnfVo.getBnfvalidYear())){
                                    setSigleValue("长期", pdfStamper,
                                            "bnfs[" + bothbifindex + "].bnfvalidYear");
                                }else{
                                    setSigleValue(lcbnfVo.getBnfvalidYear(), pdfStamper,
                                            "bnfs[" + bothbifindex + "].bnfvalidYear");
                                }
                                bothbifindex++;

                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }

                }

            }
            //受益人结束

        }

        //税收
        if (null != returnFormData.getLcappnt().getTaxtype()) {
            setSigleValue(returnFormData.getLcappnt().getAppntname(), pdfStamper, "taxinAppntName");
        }
        if (null != returnFormData.getLcinsured().getTaxtype()) {
            setSigleValue(returnFormData.getLcinsured().getLcinsuredname(), pdfStamper, "taxinLcinsuredName");
        }
        if (null != returnFormData.getLcinsuredtwo() && null != returnFormData.getLcinsuredtwo().getTaxtype()) {
            setSigleValue(returnFormData.getLcinsuredtwo().getLcinsuredname(), pdfStamper, "taxinLcinsuredTwoName");
        }
        if (!CollectionUtils.isEmpty(returnFormData.getOtherinsured())&&!CollectionUtils.isEmpty(returnFormData.getOtherinsured().get(0).getTaxtins())) {
            int index = 0;
            for (OtherInsuredVo otherInsuredVo : returnFormData.getOtherinsured()) {
                setSigleValue(otherInsuredVo.getLcinsuredname(), pdfStamper, "taxinOtherLcinsuredName" + index);
                index++;
            }
        }

        // 主险

        setSigleValue(getInsuYear(returnFormData.getLcpol()), pdfStamper,
                "lcpol.insuyear");
        setSigleValue(getPayendyear(returnFormData.getLcpol()), pdfStamper,
                "lcpol.payendyear");
        if (returnFormData.getLcpol() != null) {
            lcpolVo lcpol = returnFormData.getLcpol();
            //@X4新产品打印
            String uniontype = lcpol.getUniontype();
            if (null != uniontype && "1".equals(uniontype)){
                setSigleValue(lcpol.getUnioncontno1(), pdfStamper, "lcpol.unioncontno1");
                setSigleValue("", pdfStamper, "lcpol.unioncontno2");
            }else if (null != uniontype && "2".equals(uniontype)){
                setSigleValue("", pdfStamper, "lcpol.unioncontno1");
                setSigleValue(lcpol.getUnioncontno2(), pdfStamper, "lcpol.unioncontno2");
            }else if (null != uniontype && "3".equals(uniontype)){
                setSigleValue(lcpol.getUnioncontno1(), pdfStamper, "lcpol.unioncontno1");
                setSigleValue(lcpol.getUnioncontno2(), pdfStamper, "lcpol.unioncontno2");
            }
            String payintv = lcpol.getPayintv();
            setSigleValue(payintv, pdfStamper,
                    "lcpol.payintv");
            setSigleValue(lcpol.getPaymode(), pdfStamper,
                    "lcpol.paymode");
            if ("Y".equals(lcpol.getAnnuityincamnt())) {
                setSigleValue("增加保额", pdfStamper,
                        "lcpol.annuityincamnt1");
            }
        }


        /** 附加险 */
        List<lcpolVo> lcpolVoList = lcpolDao.selectByPrimaryKey(TransNo);
        RiskReletionInsuredVo riskReletionInsuredVo = null;
        int FirstAdditionIndex = 1;
        int secondAdditioniIndex = 1;
        int appntIndex = 1;
        int otherIndex = 1;
        for (lcpolVo lcpolVo : lcpolVoList) {
            if (lcpolVo.getKindcode().equals(lcpolVo.getRiskcode())) {
//                if (null != lcpolVo.getConttype()) {
//                    setSigleValue(ldcodeDao.selectLdcode("riskinputtype",lcpolVo.getConttype()).get(0).getCodename(), pdfStamper,
//            				"lcpol.type");
//                }
                if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                    setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "lcpol.bak1");
                } else {
                    setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper, "lcpol.bak1");
                }
                //授权账户号码
                PaymentBranchKey pay = new PaymentBranchKey();
                pay.setTransno(TransNo);
                pay.setAccountholder("0");// 授权账户
                PaymentBranch payment = paymentbranchMapper.selectByPrimaryKey(pay);
                if (null != payment) {
                    // 授权银行
                    setSigleValue("汇丰银行(中国)有限公司", pdfStamper, "NameBanklcappnt");
                    // 授权账户号码
                    String bankaccno = payment.getBankaccno().replaceAll("^CNHSBC(.*)", "$1");
                    char[] accountNumberCharArray = bankaccno.toCharArray();
                    for (int j = 0; j < accountNumberCharArray.length; j++) {
                        setSigleValue(accountNumberCharArray[j] + "", pdfStamper, "AccountNumberslcappnt" + (j + 1));
                    }
                }

                // 授权省
                if (null != payment.getAreaprovince()) {
                    setSigleValue(proviceDao.selectByPrimaryKey(
                            new BigDecimal(payment.getAreaprovince())).getProvincename(), pdfStamper, "Areaprovincelcappnt");
                }

                // 给予授权市
                if (null != payment.getAreacity()) {
                    setSigleValue(cityDao.selectByPrimaryKey(new BigDecimal(payment.getAreacity()))
                            .getCityname(), pdfStamper, "Areacitylcappnt");
                }

                // 分行/支行
                if (null != payment.getBranch()) {
                    setSigleValue(payment.getBranch(), pdfStamper, "Branchlcappnt");
                }

                pay.setAccountholder("1");// 给予账户
                payment = paymentbranchMapper.selectByPrimaryKey(pay);
                if (null != payment) {

                    // 授权银行
                    setSigleValue("汇丰银行(中国)有限公司", pdfStamper, "NameBanklcinsured");
                    // 给予账户号码
                    if (null != payment.getBankaccno()) {


                        String bankaccno1 = payment.getBankaccno().replaceAll("^CNHSBC(.*)", "$1");
                        setSigleValue(bankaccno1, pdfStamper, "AccountNumberslcinsured");

                        // 给予授权省
                        if (null != payment.getAreaprovince()) {
                            setSigleValue(proviceDao.selectByPrimaryKey(
                                    new BigDecimal(payment.getAreaprovince())).getProvincename(), pdfStamper, "Areaprovincelcinsured");
                        }

                        // 给予授权市
                        if (null != payment.getAreacity()) {
                            setSigleValue(cityDao.selectByPrimaryKey(new BigDecimal(payment.getAreacity()))
                                    .getCityname(), pdfStamper, "Areacitylcinsured");
                        }

                        // 给予分行/支行 nameBankIns
                        if (null != payment.getBranch()) {
                            setSigleValue(payment.getBranch(), pdfStamper, "Branchlcinsured");
                        }
                    }
                }

                // 投资产品栏
                List<LCAccountInfoVo> lCAccountInfoVoMapperList = lCAccountInfoVoMapper
                        .selectLCAccountInfoVoOrderBy(TransNo);
                for (int i = 0; i < lCAccountInfoVoMapperList.size(); i++) {
                    LCAccountInfoVo lcacount = lCAccountInfoVoMapperList.get(i);
                    if (null == lcacount) {
                        System.out.println("投资账户对象是null");
                        continue;
                    }
                    String codeName = lcacount.getBak2();

                    if (i == 0) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc1");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion1");// 投资比例
                        if (null != lcacount.getInvestmentaccount()) {
                            System.out.println("投资账户自动转换" + lcacount.getInvestmentaccount());
                            if ("Y".equals(lcacount.getInvestmentaccount())) {
                                setSigleValue("Y", pdfStamper, "InvestmentAccAut");// 投资账户自动转换
                            }
                        }
                    } else if (i == 1) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc2");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion2");// 投资比例
                    } else if (i == 2) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc3");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion3");// 投资比例
                    } else if (i == 3) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc4");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion4");// 投资比例
                    } else if (i == 4) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc5");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion5");// 投资比例
                    } else if (i == 5) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc6");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion6");// 投资比例
                    }
                }

                if (contSchema.getInvestmentStartDateFlag() != null) {
                    String investmentStartDateFlag = contSchema.getInvestmentStartDateFlag();
                    if (investmentStartDateFlag.equals("1")) {
                        setSigleValue("1", pdfStamper, "Immediately");// 立即投资
                    } else if (investmentStartDateFlag.equals("2")) {
                        setSigleValue("2", pdfStamper, "Immediately");// 犹豫期后投资
                    }
                }

                // 红利分配形式
                if (lcpolVo.getBonusgetmode() != null) {
                    String bonusgetmode = lcpolVo.getBonusgetmode();
                    setSigleValue(bonusgetmode, pdfStamper, "lcpol.bonusgetmode");

                    if (bonusgetmode.equals("7")) {// 累计生息
                        LmriskparamsdefaVo defavo1 = new LmriskparamsdefaVo();
                        defavo1.setRiskcode(lcpolVo.getRiskcode());
                        defavo1.setParamstype("bonuspayment");
                        defavo1.setParamscode(bonusgetmode);
                        System.out.println("红利分配形式代号:" + bonusgetmode);
                        String bonusgetmodeName = lmriskParamsDefADao.selectlmriskParamsDef(defavo1).getParamsname();
                        setSigleValue(bonusgetmodeName, pdfStamper, "OthersDividendName");
                    }
                }
                //每期保费

                continue;
            }
            riskReletionInsuredVo = new RiskReletionInsuredVo();
            riskReletionInsuredVo.setTransno(TransNo);
            riskReletionInsuredVo.setRiskcode(lcpolVo.getRiskcode());
            riskReletionInsuredVo.setInsuid("1");// 代表第一被保人附加险
            List<RiskReletionInsuredVo> firstSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            if (firstSelectByPrimaryKey != null && firstSelectByPrimaryKey.size() > 0) {
                try {

                    for (int i = 0; i < firstSelectByPrimaryKey.size(); i++) {

                        // 险种名称
                        if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "additonriskname" + FirstAdditionIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "additonriskname" + FirstAdditionIndex);
                        }
                        // 基本保险金额
                        String additionAmnt = lcpolVo.getAmnt().toString();
                        if ("0".equals(lcpolVo.getAmnt())) {
                            additionAmnt = "";
                        }
                        setSigleValue(additionAmnt, pdfStamper,
                                "additonsuminsured" + FirstAdditionIndex);

                        // 类型
//	                    if (null != lcpolVo.getConttype()) {
//	                    setSigleValue(ldcodeDao.selectLdcode("riskinputtype",lcpolVo.getConttype()).get(0).getCodename(), pdfStamper,
//	            				"additonsatype" + FirstAdditionIndex);
//	                    }
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "additonsatype" + FirstAdditionIndex);
                        }
                        // 保险期间
                        String insuyear1 = lcpolVo.getInsuyear();
                        LmriskparamsdefaVo defavo1 = new LmriskparamsdefaVo();
                        defavo1.setRiskcode(lcpolVo.getRiskcode());
                        defavo1.setParamstype("insuyear");
                        defavo1.setParamscode(insuyear1);
                        System.out.println("保险期间代号" + insuyear1);
                        insuyear1 = lmriskParamsDefADao.selectlmriskParamsDef(defavo1).getParamsname();
                        setSigleValue(insuyear1, pdfStamper,
                                "addbenefitterm" + FirstAdditionIndex);

                        // 保险费支付期
                        String payendyear = lcpolVo.getPayendyear();
                        if (payendyear.equals("0Y")) {
                            payendyear = "趸交";
                        } else {
                            payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "addpremiumterm" + FirstAdditionIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "addprem" + FirstAdditionIndex);
                        }
                        FirstAdditionIndex++;

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            riskReletionInsuredVo.setInsuid("2");// 代表第二被保人附加险
            List<RiskReletionInsuredVo> secondSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            if (null != secondSelectByPrimaryKey && secondSelectByPrimaryKey.size() > 0) {

                try {
                    System.out.println("第二被保人附加险险种代码" + lcpolVo.getRiskcode() + "List长度"
                            + secondSelectByPrimaryKey.size());
                    for (int i = 0; i < secondSelectByPrimaryKey.size(); i++) {

                        // 险种名称
                        if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "secadditonriskname" + secondAdditioniIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "secadditonriskname" + secondAdditioniIndex);
                        }

                        // 基本保险金额
                        setSigleValue(lcpolVo.getAmnt().toString(), pdfStamper,
                                "secadditonsuminsured" + secondAdditioniIndex);

                        // 类型
//	                    if (null != lcpolVo.getConttype()) {
//	                    setSigleValue(ldcodeDao.selectLdcode("riskinputtype",lcpolVo.getConttype()).get(0).getCodename(), pdfStamper,
//	            				"secadditonsatype" + secondAdditioniIndex);
//	                    }
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "secadditonsatype" + secondAdditioniIndex);
                        }
                        // 保险期间
                        String insuyear2 = lcpolVo.getInsuyear();
                        LmriskparamsdefaVo defavo2 = new LmriskparamsdefaVo();
                        defavo2.setRiskcode(lcpolVo.getRiskcode());
                        defavo2.setParamstype("insuyear");
                        defavo2.setParamscode(insuyear2);
                        System.out.println("保险期间代号" + insuyear2);
                        insuyear2 = lmriskParamsDefADao.selectlmriskParamsDef(defavo2).getParamsname();
                        setSigleValue(insuyear2, pdfStamper,
                                "secaddbenefitterm" + secondAdditioniIndex);

                        // 保险费支付期
                        String payendyear = lcpolVo.getPayendyear();
                        if (payendyear.equals("0Y")) {
                            payendyear = "趸交";
                        } else {
                            payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "secaddpremiumterm" + secondAdditioniIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "secaddprem" + secondAdditioniIndex);
                        }
                        secondAdditioniIndex++;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


            riskReletionInsuredVo.setInsuid("0");// 代表投保人附加险
            List<RiskReletionInsuredVo> appntSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            Iterator<RiskReletionInsuredVo> appiterator = appntSelectByPrimaryKey.iterator();
            while (appiterator.hasNext()) {
                if (appiterator.next().getOtherinsuredid() != null) {
                    appiterator.remove();
                }
            }

            if (null != appntSelectByPrimaryKey && appntSelectByPrimaryKey.size() > 0) {

                try {
                    System.out.println("投保人附加险险种代码" + lcpolVo.getRiskcode() + "List长度"
                            + appntSelectByPrimaryKey.size());
                    System.out.println("**********");
                    for (int i = 0; i < appntSelectByPrimaryKey.size(); i++) {

                        System.out.println("-------");
                        // 险种名称
                        if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "appntriskname" + appntIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "appntriskname" + appntIndex);
                        }

                        // 基本保险金额
                        setSigleValue(lcpolVo.getAmnt().toString(), pdfStamper,
                                "appntsuminsured" + appntIndex);

                        // 类型
//	                    if (null != lcpolVo.getConttype()) {
//	                    setSigleValue(ldcodeDao.selectLdcode("riskinputtype",lcpolVo.getConttype()).get(0).getCodename(), pdfStamper,
//	            				"appntsatype" + appntIndex);
//	                    }
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "appntsatype" + appntIndex);
                        }
                        // 保险期间
                        String insuyear0 = lcpolVo.getInsuyear();
                        LmriskparamsdefaVo defavo0 = new LmriskparamsdefaVo();
                        defavo0.setRiskcode(lcpolVo.getRiskcode());
                        defavo0.setParamstype("insuyear");
                        defavo0.setParamscode(insuyear0);
                        System.out.println("保险期间代号" + insuyear0);
                        insuyear0 = lmriskParamsDefADao.selectlmriskParamsDef(defavo0).getParamsname();
                        setSigleValue(insuyear0, pdfStamper,
                                "appntbenefitterm" + appntIndex);

                        // 保险费支付期
                        String payendyear = lcpolVo.getPayendyear();
                        if (payendyear.equals("0Y")) {
                            payendyear = "趸交";
                        } else {
                            payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "appntpremiumterm" + appntIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "appntprem" + appntIndex);
                        }

                        appntIndex++;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


            riskReletionInsuredVo.setInsuid("0");// 代表其他被保人附加险
            riskReletionInsuredVo.setOtherinsuredid("0");
            List<RiskReletionInsuredVo> otherSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            if (null != otherSelectByPrimaryKey && otherSelectByPrimaryKey.size() > 0) {

                try {
                    System.out.println("投保人附加险险种代码" + lcpolVo.getRiskcode() + "List长度"
                            + otherSelectByPrimaryKey.size());
                    System.out.println("**********");
                    for (int i = 0; i < otherSelectByPrimaryKey.size(); i++) {

                        System.out.println("-------");
                        // 险种名称
                        if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "otherriskname" + otherIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "otherriskname" + otherIndex);
                        }

                        // 基本保险金额
                        setSigleValue(lcpolVo.getAmnt().toString(), pdfStamper,
                                "othersuminsured" + otherIndex);
                        // 类型
//	                    if (null != lcpolVo.getConttype()) {
//	                    setSigleValue(ldcodeDao.selectLdcode("riskinputtype",lcpolVo.getConttype()).get(0).getCodename(), pdfStamper,
//	            				"othersatype" + otherIndex);
//	                    }
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "othersatype" + otherIndex);
                        }
                        // 保险期间
                        String insuyear0 = lcpolVo.getInsuyear();
                        LmriskparamsdefaVo defavo0 = new LmriskparamsdefaVo();
                        defavo0.setRiskcode(lcpolVo.getRiskcode());
                        defavo0.setParamstype("insuyear");
                        defavo0.setParamscode(insuyear0);
                        System.out.println("保险期间代号" + insuyear0);
                        insuyear0 = lmriskParamsDefADao.selectlmriskParamsDef(defavo0).getParamsname();
                        setSigleValue(insuyear0, pdfStamper,
                                "otherbenefitterm" + otherIndex);

                        // 保险费支付期
                        String payendyear = lcpolVo.getPayendyear();
                        if (payendyear.equals("0Y")) {
                            payendyear = "趸交";
                        } else {
                            payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "otherpremiumterm" + otherIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "otherprem" + otherIndex);

                        }

                        otherIndex++;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            //附加险结束
        }


        String managecom = returnFormData.getLccont().getManagecom();
        System.out.println("managecom是" + managecom);
        LdcomVo ldcome = ldcomVoMapper.selectByPrimaryKey(managecom);
        if (ldcome != null){
            setSigleValue(ldcome.getComname(), pdfStamper, "sysuser.companyCode");
        }


        /**
         * 告知详情打印
         */
        List<SimpleNoticeInfo> noticedetails = returnFormData.getNoticedetails();
        int num = noticedetails.size() / 2;
        //健康告知
        HashMap<String, String> hashMap1 = new HashMap<>();
        int number1 = 1;
        //其他告知
        HashMap<String, String> hashMap2 = new HashMap<>();
        int number2 = 1;
        //复杂告知和简单告知分开显示 投被保人身高体重、健康告知    SP简单告知  CP复杂告知   flage=""时不会打印在模板上所以没必要判断！=""时再填值到模板
        String flage = judgeSCorCP(returnFormData);
        //没有投保人
        if (null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(37) && StringUtils.isEmpty(returnFormData.getNoticeinfos().get(37).getOwnerimpart())) {
            for (int i = 0; i < num; i++) {
//	        		if(i==0) {
//	        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname() ,pdfStamper, "temp"+(i+1));
//	        		}else {
//	        			setSigleValue(returnFormData.getLcinsuredtwo().getLcinsuredname() ,pdfStamper, "temp"+(i+1));
//	        		}

                //        		setSigleValue("被保人"+(i+1),pdfStamper, "temp"+(i+1));
//	        		setSigleValue(""+(i+1),pdfStamper, "num"+(i+1));//序号
                if (null != returnFormData.getNoticedetails() && null != returnFormData.getNoticedetails().get(i) && StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i).getNoticeinfo1())) {
                    if (i == 0) {
                        if (null != returnFormData.getLcinsured()){
                            hashMap1.put(returnFormData.getLcinsured().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    } else {
                        if (null != returnFormData.getLcinsuredtwo()){
                            hashMap1.put(returnFormData.getLcinsuredtwo().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    }
                }
//	        		setSigleValue(returnFormData.getNoticedetails().get(i).getNoticeinfo1(),pdfStamper, "detail"+(i+1));
            }

        } else {
            setSigleValue("1", pdfStamper, flage + "num1");//序号
            number1 = 2;
            if (null != returnFormData.getLcappnt()){
                setSigleValue(returnFormData.getLcappnt().getAppntname(), pdfStamper, flage + "temp1");
            }
            if (null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(37)){
                setSigleValue(returnFormData.getNoticeinfos().get(37).getOwnerimpart(), pdfStamper, flage + "detail1");
            }
            for (int i = 0; i < num; i++) {
//	        		if(i==0) {
//	        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname() ,pdfStamper, "temp"+(i+1+1));	
//	        		}else {
//	        			setSigleValue(returnFormData.getLcinsuredtwo().getLcinsuredname() ,pdfStamper, "temp"+(i+1+1));	
//	        		}
                //setSigleValue("被保人"+(i+1),pdfStamper, "temp"+(i+1+1));
//	        		setSigleValue(""+(i+1+1),pdfStamper, "num"+(i+1+1));//序号
                if (null != returnFormData.getNoticedetails() && null != returnFormData.getNoticedetails().get(i) && StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i).getNoticeinfo1())) {
                    if (i == 0) {
                        if (null != returnFormData.getLcinsured()){
                            hashMap1.put(returnFormData.getLcinsured().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    } else {
                        if (null != returnFormData.getLcinsuredtwo()){
                            hashMap1.put(returnFormData.getLcinsuredtwo().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    }
                }
//	        		setSigleValue(returnFormData.getNoticedetails().get(i).getNoticeinfo1(),pdfStamper, "detail"+(i+1+1));
            }
        }


        //打印健康告知
        Iterator<Entry<String, String>> it1 = hashMap1.entrySet().iterator();
        while (it1.hasNext()) {
            setSigleValue("" + number1, pdfStamper, flage + "num" + (number1));
            Entry<String, String> entry = it1.next();
            setSigleValue(entry.getKey(), pdfStamper, flage + "temp" + (number1));
            setSigleValue(entry.getValue(), pdfStamper, flage + "detail" + (number1));
            number1++;
        }

        if (null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(38) && StringUtils.isEmpty(returnFormData.getNoticeinfos().get(38).getOwnerimpart())) {
            for (int i = num; i < noticedetails.size(); i++) {
//	        		if(i==num) {
//	        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname() ,pdfStamper, "other"+(i+1-num));
//	        		}else {
//	        			setSigleValue(returnFormData.getLcinsuredtwo().getLcinsuredname() ,pdfStamper, "other"+(i+1-num));
//	        		}
                //setSigleValue("被保人"+(i+1-num),pdfStamper, "other"+(i+1-num));
//	        		setSigleValue(""+(i+1-num),pdfStamper, "newnum"+(i+1-num));//序号
                if (null != returnFormData.getNoticedetails() && null != returnFormData.getNoticedetails().get(i) && StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i).getNoticeinfo1())) {
                    if (i == num) {
                        if (null != returnFormData.getLcinsured()){
                            hashMap2.put(returnFormData.getLcinsured().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    } else {
                        if (null != returnFormData.getLcinsuredtwo()){
                            hashMap2.put(returnFormData.getLcinsuredtwo().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    }
                }
//	        		setSigleValue(returnFormData.getNoticedetails().get(i).getNoticeinfo1(),pdfStamper, "otherdetail"+(i+1-num));
            }
        } else {
            setSigleValue("1", pdfStamper, "newnum1");//序号
            number2 = 2;
            if (null != returnFormData.getLcappnt()){
                setSigleValue(returnFormData.getLcappnt().getAppntname(), pdfStamper, "other1");
            }
            if (null != returnFormData.getNoticeinfos() && null != returnFormData.getNoticeinfos().get(38)){
                setSigleValue(returnFormData.getNoticeinfos().get(38).getOwnerimpart(), pdfStamper, "otherdetail1");
            }
            for (int i = num; i < noticedetails.size(); i++) {
//	        		if(i==num) {
//	        			setSigleValue(returnFormData.getLcinsured().getLcinsuredname() ,pdfStamper, "other"+(i+1+1-num));
//	        		}else {
//	        			setSigleValue(returnFormData.getLcinsuredtwo().getLcinsuredname() ,pdfStamper, "other"+(i+1+1-num));
//	        		}
                //setSigleValue("被保人"+(i+1-num),pdfStamper, "other"+(i+1+1-num));
//	        		setSigleValue(""+(i+1+1-num),pdfStamper, "newnum"+(i+1+1-num));//序号
                if (null != returnFormData.getNoticedetails() && null != returnFormData.getNoticedetails().get(i) && StringUtils.isNoneBlank(returnFormData.getNoticedetails().get(i).getNoticeinfo1())) {
                    if (i == num) {
                        if (null != returnFormData.getLcinsured()){
                            hashMap2.put(returnFormData.getLcinsured().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    } else {
                        if (null != returnFormData.getLcinsuredtwo()){
                            hashMap2.put(returnFormData.getLcinsuredtwo().getLcinsuredname(), returnFormData.getNoticedetails().get(i).getNoticeinfo1());
                        }
                    }
                }
//	        		setSigleValue(returnFormData.getNoticedetails().get(i).getNoticeinfo1(),pdfStamper, "otherdetail"+(i+1+1-num));
            }
        }

        //打印其他告知
        Iterator<Entry<String, String>> it2 = hashMap2.entrySet().iterator();
        while (it2.hasNext()) {
            setSigleValue("" + number2, pdfStamper, "newnum" + (number2));//序号
            Entry<String, String> entry = it2.next();
            setSigleValue(entry.getKey(), pdfStamper, "other" + (number2));
            setSigleValue(entry.getValue(), pdfStamper, "otherdetail" + (number2));
            number2++;
        }

        //复杂告知和简单告知分开显示 投被保人身高体重    SP简单告知  CP复杂告知
        if (null != returnFormData.getLcinsured() && null != returnFormData.getLcinsured().getStature() && null != returnFormData.getLcinsured().getAvoirdupois()) {
            setSigleValue(String.valueOf(returnFormData.getLcinsured().getStature()), pdfStamper, flage + "lcinsured.stature");
            setSigleValue(String.valueOf(returnFormData.getLcinsured().getAvoirdupois()), pdfStamper, flage + "lcinsured.avoirdupois");
        }
        if (null != returnFormData.getLcinsuredtwo() && null != returnFormData.getLcinsuredtwo().getStature() && null != returnFormData.getLcinsuredtwo().getAvoirdupois()) {
            setSigleValue(String.valueOf(returnFormData.getLcinsuredtwo().getStature()), pdfStamper, flage + "lcinsuredtwo.stature");
            setSigleValue(String.valueOf(returnFormData.getLcinsuredtwo().getAvoirdupois()), pdfStamper, flage + "lcinsuredtwo.avoirdupois");
        }
        if (null != returnFormData.getLcappnt() && null != returnFormData.getLcappnt().getStature() && null != returnFormData.getLcappnt().getAvoirdupois()) {
            setSigleValue(String.valueOf(returnFormData.getLcappnt().getStature()), pdfStamper, flage + "lcappnt.stature");
            setSigleValue(String.valueOf(returnFormData.getLcappnt().getAvoirdupois()), pdfStamper, flage + "lcappnt.avoirdupois");
        }
    }

    /**
     * 判断投配置的是简单告知还是复杂告知
     * 判断逻辑为：根据配置的告知，最终在告知页面上要显示的告知来判断
     * notice1~notice9告知配置为显示为简单告知  （即elementstatus=="01"显示告知 "02"不显示告知）
     * notice10~notice39（不含notice34、notice35）告知配置为显示为复杂告知
     * @formdata
     * @return   "SP"简单告知  "CP"复杂告知  ""不显示告知 （不存在同时配置了简单告知和复杂告知的情况）
     */
    public String judgeSCorCP(ContFormData formdata) {
        String flage = "";

        logger.info("投保单打印查询告知 元素，判断为简单告知还是复杂告知");
        // 查询出告知页面的元素
        String combindid = "";
        //年金/生存金是否需要转入万能账户,选是出固定复杂告知
        if (StringUtils.isNotBlank(formdata.getLcpol().getWhetherconvert()) && "Y".equals(formdata.getLcpol().getWhetherconvert())) {
            logger.info("年金/生存金是否需要转入万能账户不为空且为 Y固定复杂告知 PC， Whetherconvert="+formdata.getLcpol().getWhetherconvert());
            //选了转万能后，出固定复杂告知（数据库新配置一套） combinedid='complexnotification'
            combindid = StringUtils.isNotBlank(formdata.getLccont().getAxaPdfName()) ?
                    formdata.getLccont().getAxaPdfName() : formdata.getNewContApply().getNoticeCombineID();
        } else {
            NoticeFormData noticeFormData = new NoticeFormData();
            noticeFormData.setInsurancecom(NewContStaticStr.ANZLinsucom);//保险公司代码
            noticeFormData.setMainriskcode(formdata.getLcpol().getRiskcode());
            String additionRiskCode = "";
            int index = 0;
            Set<String> riskcodeset = new HashSet<String>();
            for (lcpolVo additionlcpol : formdata.getSublcpols()) {
                if (additionlcpol.getRiskcode() != null) {
                    if (riskcodeset.contains(additionlcpol.getRiskcode())) {
                        continue;
                    } else {
                        riskcodeset.add(additionlcpol.getRiskcode());
                    }

                    if (index != 0) {
                        additionRiskCode = additionRiskCode + "," + additionlcpol.getRiskcode();
                    } else {
                        additionRiskCode = additionRiskCode + additionlcpol.getRiskcode();
                    }
                }
                index++;
            }
            noticeFormData.setAdditionRiskCode(additionRiskCode);

            combindid = "N/A";
            try {
                combindid = impartConfigService.queryCombinecode(noticeFormData);
            } catch (Exception e) {
                // TODO: handle exception
                e.printStackTrace();
                combindid = "N/A";
            }
        }

		List<FormElement> list = formelementMapper.selNoticeFormelement(
				NewContStaticStr.ANZLinsucom + NewContStaticStr.CONT_NOTICE, combindid);

		for (int i = 0; i < list.size(); i++) {
			FormElement element = list.get(i);
			if ("ParentElement".equals(element.getType())&&"01".equals(element.getElementstatus())) { // 告知项
			    int num = Integer.valueOf(element.getId().substring(6));
                if (1 <= num && num <= 9) {
                    flage = "SP";
                    break;//存在一个简单告知项被配置为显示，结束循环，结果为简单告知
                } else if (10 <= num && num <= 39 && num != 34 && num != 35) {
                    flage = "CP";//存在一个复杂告知项被配置为显示，结束循环，结果为复杂告知
                    break;
                }
			}
		}
		logger.info("combindid:"+combindid+"   flage:"+flage);
		return flage;
    }


    private LdoccupationVo getLdoccupation(String occupationcode) {

        if (occupationcode == null || occupationcode.length() == 0) {
            return new LdoccupationVo();
        }

        LdoccupationVo ldoccupationVo = ldoccupationVoMapper.selectByOccupationcode(occupationcode, "AL");

        if (ldoccupationVo == null) {
            ldoccupationVo = new LdoccupationVo();
        }

        return ldoccupationVo;


    }

}
