package com.sinosoft.service.print.paperentry.ANZL;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.annotation.Resource;

import com.sinosoft.service.api.PubFun;
import com.sinosoft.service.business.db.dao.*;
import com.sinosoft.service.business.db.vo.*;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sinosoft.bean.common.ValueMapBean;
import com.sinosoft.bean.newCont.ContFormData;
import com.sinosoft.bean.newCont.data.ApplyBean;
import com.sinosoft.core.common.bean.config.SinoProperty;
import com.sinosoft.service.business.ui.contprint.metLife.SpecialProvenceCheck;
import com.sinosoft.service.common.pdfprint.PdfItextBean;
import com.sinosoft.service.common.pdfprint.PdfPrintForItextImpl;

@Service
public class PaperPdfPrintANZL extends PdfPrintForItextImpl{
    /**
     * 打印日志
     */
    private static final Logger logger = LoggerFactory
            .getLogger(PaperPdfPrintANZL.class);

    @Resource
    private SinoProperty sinoProperty;
    @Resource
    LdoccupationVoMapper ldoccupationVoMapper;
    @Resource
    private LMRiskParamsDefADao lmriskParamsDefADao;
    @Resource
    private LdcodeDao ldcodeDao;
    @Resource
    private PNewContEnterDao enterDao;
    @Resource
    private LmriskDao lmriskDao;
    @Resource
    private PlcpolVoMapper lcpolDao;
    @Autowired
    private PRiskReletionInsuredDao riskReletionInsuredDao;
    @Autowired
    private PPaymentBranchMapper paymentbranchMapper;
    @Autowired
    private ProvinceVoMapper proviceDao;
    @Autowired
    private CityVoMapper cityDao;
    @Autowired
    private CountyVoMapper countyDao;
    @Autowired
    private PLCAccountInfoVoMapper lCAccountInfoVoMapper;
    @Autowired
    private LdcomVoMapper ldcomVoMapper;
    @Autowired
    private PlcaddressVoMapper addressDao;
    @Autowired
    private LoginDao loginDao;

    @Override
    public ValueMapBean getValueMapBean() {
        ValueMapBean valueMapBean = new ValueMapBean();
        return valueMapBean;
    }

    @Override
    public PdfItextBean getPDF(Object... obj) throws IOException {
        System.out.println("进入PaperPdfPrintANZL----");
        PdfItextBean pdfStamper = null;
        try {
            ContFormData returnFormData = getFormData((String) obj[0], (String) obj[1], (String) obj[2]);
            pdfStamper = getFillFormFieldPDF(returnFormData, (String) obj[3]);
            // 生成PDF

        } catch (Exception e) {
            e.printStackTrace();
            throw new IOException(e);
        } finally {

        }
        return pdfStamper;

    }

    @Override
    public String getFormTemplate() {
        Properties fontproperties = sinoProperty.getProMap().get(
                "pdfprint_properties");
        return fontproperties.getProperty("ANZL_template");
//        return "D:/appvol/ybt/downloadfiles/printinfo/test.pdf";
    }

    private ContFormData getFormData(String transno, String riskcode, String grpcontno) {
        ContFormData returnFormData = new ContFormData();
        ApplyBean applyBean = new ApplyBean();
        boolean relationFlag = isSelf(transno);
        LCContVo contSchema = enterDao.selectBylccont(transno);
        LCAppntVo appntSchema = enterDao.selectBylcAppnt(transno);// 投保人信息
        lcpolVo selectByPrimaryKey1 = lcpolDao.selectMianRisk(transno);//保险信息-主险
        List<lcpolVo> lcpolVoList = lcpolDao.selectSubRisk(transno);
        //地址信息
        lcaddressVo appntaddressVo = new lcaddressVo();
        lcaddressVo lcappntAddressVo = null;
        appntaddressVo.setTransno(transno);
        if (contSchema != null){
            appntaddressVo.setCustomerno(contSchema.getGrpcontno());
            appntaddressVo.setAddressno(new BigDecimal("0"));
            lcappntAddressVo = addressDao.selectByPrimaryKey_anzl(appntaddressVo);
        }
        applyBean.setTransno(transno);
        applyBean.setRiskcode(riskcode);
        applyBean.setGrpcontno(grpcontno);
        returnFormData.setNewContApply(applyBean);
        returnFormData.setLccont(contSchema);
        returnFormData.setLcappnt(appntSchema);
        returnFormData.setLcappntaddress(lcappntAddressVo);
        returnFormData.setLcpol(selectByPrimaryKey1);
        returnFormData.setSublcpols(lcpolVoList);
        //同步被保人信息
        if (relationFlag){
            LcinsuredVo lcinsuredVo = new LcinsuredVo();
            lcinsuredVo.setLcinsuredname(appntSchema.getAppntname());
            lcinsuredVo.setLcinsuredsex(appntSchema.getAppntsex());
            lcinsuredVo.setLcinsuredbirthday(appntSchema.getAppntbirthday());
            lcinsuredVo.setLcinsuredage(appntSchema.getAppntage());
            lcinsuredVo.setLcinsuredidtype(appntSchema.getIdtype());
            lcinsuredVo.setLcinsuredidno(appntSchema.getIdno());
            lcinsuredVo.setStartingDate(appntSchema.getStartingDate());
            lcinsuredVo.setInsureidenddate(appntSchema.getAppntenddate());
            lcinsuredVo.setLcinsurednativeplace(appntSchema.getNativeplace());
            lcinsuredVo.setLcinsuredbirthcounty(appntSchema.getBirthcounty());
            lcinsuredVo.setRgtaddress(appntSchema.getRgtaddress());
            lcinsuredVo.setLcinsuredcompany(appntSchema.getCompany());
            lcinsuredVo.setIndustrytype(appntSchema.getIndustrytype());
            lcinsuredVo.setLcinsuredroccupationcode(appntSchema.getResponsibility());
            lcinsuredVo.setTaxtype(appntSchema.getTaxtype());
            returnFormData.setLcinsured(lcinsuredVo);
        }
        //同步被保人地址信息
        if (relationFlag){
            lcaddressVo lcinsuredAddressVo = new lcaddressVo();
            lcinsuredAddressVo.setHomeaddress(lcappntAddressVo.getHomeaddress());
            lcinsuredAddressVo.setZipcode(lcappntAddressVo.getZipcode());
            lcinsuredAddressVo.setCountrycodetel_tel(lcappntAddressVo.getCountrycodetel_tel());
            lcinsuredAddressVo.setAreacodetel(lcappntAddressVo.getAreacodetel());
            lcinsuredAddressVo.setHomephone(lcappntAddressVo.getHomephone());
            lcinsuredAddressVo.setCountrycodetel_mob(lcappntAddressVo.getCountrycodetel_mob());
            lcinsuredAddressVo.setMobile(lcappntAddressVo.getMobile());
            lcinsuredAddressVo.setEmail(lcappntAddressVo.getEmail());
            returnFormData.setLcinsuredaddress(lcinsuredAddressVo);
        }
        //1年期不打印税收信息
        if("1Y".equals(returnFormData.getLcpol().getInsuyear())){
            returnFormData.getLcappnt().setTaxtype(null);
            returnFormData.getLcappnt().setTaxtins(new ArrayList<TAXTIN>());
        }
        return returnFormData;
    }

    @Override
    public String getDateformat() {
        return "yyyy/MM/dd";
    }

    /***
     * 获取保险期间
     * @param lcpolVo
     * @return
     */
    private String getInsuYear(lcpolVo lcpolVo) {
        String insuyear = "";
        if (lcpolVo != null){
            insuyear = lcpolVo.getInsuyear();
            LmriskparamsdefaVo defavo = new LmriskparamsdefaVo();
            defavo.setRiskcode(lcpolVo.getRiskcode());
            defavo.setParamstype("insuyear");
            defavo.setParamscode(insuyear);
            logger.info("保险期间代号" + insuyear);
            
            if (null != insuyear &&null != lcpolVo.getRiskcode() ) {
                   //Y4、B9类 改成可配置化，配置了保险期间（年）输入框的产品取insuyearY4字段
            		List<LmriskparamsdefaVo> params=lmriskDao.QueryParam(lcpolVo.getRiskcode(), "insuyearY4", "Y");
            		
            		if(params.size()>0&&null!=lcpolVo.getInsuyearY4()){//保险期间输入框取值
            			 insuyear = lcpolVo.getInsuyearY4();
                    }else{
                	   if (null != lmriskParamsDefADao.selectlmriskParamsDef(defavo)){//保险期间下拉框取值
                		 
                         insuyear = lmriskParamsDefADao.selectlmriskParamsDef(defavo).getParamsname();
                       }
                }
            }
        }
        return insuyear;
    }


    /**
     * 获取付费期间
     *
     * @param lcpolVo
     * @return
     */
    private String getPayendyear(lcpolVo lcpolVo) {
        String payendyear = "";
        if (lcpolVo != null){
            payendyear = lcpolVo.getPayendyear();
            if (null != payendyear && ("0Y").equals(payendyear)) {
                payendyear = "趸交";
            } else if (payendyear != null) {
                System.out.println("保费支付期" + payendyear);
                if (null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear) && ldcodeDao.selectLdcode("riskinputtypep05", payendyear).size() >0 && null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0)){
                    payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                }
            }
        }
        return payendyear;
    }

    /**
     * 保险计划改大写
     * @param lcpolVo
     * @return
     */
    private String getPlan(lcpolVo lcpolVo){
        String plan = "";
        if (lcpolVo != null){
            plan = lcpolVo.getPlan();
            if ("1".equals(plan)){
                plan = "计划一";
            }else if("2".equals(plan)){
                plan = "计划二";
            }else if ("3".equals(plan)){
                plan = "计划三";
            }
        }
        return plan;
    }
    @Override
    public void setSpecialCode(Object valueObj, PdfItextBean pdfStamper)
            throws IOException {
        ContFormData returnFormData = (ContFormData) valueObj;
        String transno = returnFormData.getNewContApply().getTransno(); // 交易流水号
        boolean relationFlag = isSelf(transno);
        LCContVo contSchema = enterDao.selectBylccont(transno);
        LCAppntVo appntSchema = enterDao.selectBylcAppnt(transno);// 投保人信息
        lcpolVo selectByPrimaryKey1 = lcpolDao.selectMianRisk(transno);//保险信息-主险
        if (contSchema != null){
            //渠道
            String commonchannel = contSchema.getCommonchannel();
            Date polapplydate = contSchema.getPolapplydate();
            if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
                setSigleValue("手机银行", pdfStamper, "commonchannel");
                try {
                    setSigleValue(PubFun.formatYMD1(polapplydate),pdfStamper,"polapplydate");
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            } else if ("BH".equals(commonchannel)) {
                setSigleValue("银保通", pdfStamper, "commonchannel");
            }
            System.out.println("渠道：" + commonchannel + "销售人员编号：" + contSchema.getOperator());

            //线上还是线下
            if ("12".equals(contSchema.getAppflag())) {
                //e电子p纸质
                if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
                    setSigleValue("HSBC Online Application_S", pdfStamper, "lccont.appflag");
                }else if("BH".equals(commonchannel) || "RE".equals(commonchannel)){
                    if ("E".equals(contSchema.geteSignFlag())) {
                        setSigleValue("HSBC Online Application_E", pdfStamper, "lccont.appflag");
                    }
                    if ("P".equals(contSchema.geteSignFlag())) {
                        setSigleValue("HSBC Online Application_P", pdfStamper, "lccont.appflag");
                    }
                }
            } else if ("09".equals(contSchema.getAppflag()) || "14".equals(contSchema.getAppflag())) {
                //e电子p纸质
                if ("SC".equals(commonchannel) || "RS".equals(commonchannel)) {
                    setSigleValue("HSBC Offline Application_S", pdfStamper, "lccont.appflag");
                }else if("BH".equals(commonchannel) || "RE".equals(commonchannel)){
                    if ("E".equals(contSchema.geteSignFlag())) {
                        setSigleValue("HSBC Offline Application_E", pdfStamper, "lccont.appflag");
                    }
                    if ("P".equals(contSchema.geteSignFlag())) {
                        setSigleValue("HSBC Offline Application_P", pdfStamper, "lccont.appflag");
                    }
                }
            }
        }

        //条形码
        if (contSchema != null){
            setSigleValue("*" + contSchema.getProposalcontno()
                    + "*", pdfStamper, "lccont.barcodetext");
        }
        setSigleValue("*1151*", pdfStamper, "barcode1code");
        setSigleValue("*1152*", pdfStamper, "barcode2code");
        setSigleValue("*4201*", pdfStamper, "side1code");
        setSigleValue("*4202*", pdfStamper, "side2code");
        setSigleValue("*4203*", pdfStamper, "side3code");
        setSigleValue("*4204*", pdfStamper, "side4code");
        setSigleValue("*4205*", pdfStamper, "side5code");
        setSigleValue("*4206*", pdfStamper, "side6code");
        setSigleValue("*4207*", pdfStamper, "side7code");
        setSigleValue("*4208*", pdfStamper, "side8code");
        setSigleValue("*4209*", pdfStamper, "side9code");


        /**
         * 投保人
         */
        if (appntSchema != null) {
            // 投保人与主被保人关系
            String relationtoappnt = appntSchema.getRelationtoappnt();
            if (relationtoappnt != null){
                if (null != ldcodeDao.selectLdcode("anzl_relation", relationtoappnt) && null != ldcodeDao.selectLdcode("anzl_relation", relationtoappnt).get(0)){
                    setSigleValue(ldcodeDao.selectLdcode("anzl_relation", relationtoappnt).get(0).getCodename(), pdfStamper, "lcinsured.relationtoappnt");
                }
            }

            lcaddressVo appntaddressVo = new lcaddressVo();
            appntaddressVo.setTransno(transno);
            if (contSchema != null){
                appntaddressVo.setCustomerno(contSchema.getGrpcontno());
            }
            appntaddressVo.setAddressno(new BigDecimal("0"));
            lcaddressVo lcappntaddress = addressDao.selectByPrimaryKey_anzl(appntaddressVo);
            //投保人行业类型
            if (null != ldoccupationVoMapper.selectByOccupationcode(appntSchema.getOccupationcode(), "AL")){
                setSigleValue(ldoccupationVoMapper.selectByOccupationcode(appntSchema.getOccupationcode(), "AL").getOccupationname2(), pdfStamper, "lcappnt.industrytype");
            }
            //投保人具体工作
            if (null != ldoccupationVoMapper.selectByOccupationcode(appntSchema.getOccupationcode(), "AL")){
                setSigleValue(ldoccupationVoMapper.selectByOccupationcode(appntSchema.getOccupationcode(), "AL").getOccupationname(), pdfStamper, "lcappnt.responsibility");
            }
            ProvinceVo provinceVo = null;
            CityVo cityVo = null;
            CountyVo countyVo = null;
            //投保人居住地址
            String postprovince = "";
            if (lcappntaddress != null){
                postprovince = lcappntaddress.getPostprovince();
                System.out.println("居住地址postprovince:" + postprovince);
            }
            if (null != postprovince){
                provinceVo = proviceDao.selectByPrimaryKey(new BigDecimal(postprovince));
                System.out.println("居住地址provinceVo:" + provinceVo);
            }
            String postcity = "";
            if (lcappntaddress != null){
                postcity = lcappntaddress.getPostcity();
                System.out.println("居住地址postcity:" + postcity);
            }
            if (null != postcity){
                cityVo = cityDao.selectByPrimaryKey(new BigDecimal(postcity));
                System.out.println("居住地址cityVo:" + cityVo);
            }
            String postArea = "";
            if (lcappntaddress != null){
                postArea = lcappntaddress.getPostdistrict();
                System.out.println("居住地址postArea:" + postArea);
            }
            if (postArea != null){
                countyVo = countyDao.selectByPrimaryKey(new BigDecimal(postArea));
                System.out.println("居住地址countyVo:" + countyVo);
            }
            String appntResidentialAddress = "";
            if (provinceVo != null && cityVo != null && countyVo != null){
                appntResidentialAddress = appntResidentialAddress + provinceVo.getProvincename() + cityVo.getCityname() + countyVo.getCountyname();
                System.out.println("居住地址省市区:" + appntResidentialAddress);
            }
            if (provinceVo == null && cityVo == null && countyVo == null){
                System.out.println("居住地址无省市区:" + appntResidentialAddress);
            }
            if (provinceVo != null && cityVo != null && countyVo == null){
                appntResidentialAddress = appntResidentialAddress + provinceVo.getProvincename() + cityVo.getCityname();
                System.out.println("居住地址省市:" + appntResidentialAddress);
            }
            if (provinceVo != null && cityVo == null && countyVo == null){
                appntResidentialAddress = appntResidentialAddress + provinceVo.getProvincename();
                System.out.println("居住地址省:" + appntResidentialAddress);
            }
            String postdetail = lcappntaddress.getPostaladdress();
            System.out.println("居住地址postdetail:" + postdetail);
            if (null != postdetail){
                appntResidentialAddress = appntResidentialAddress + postdetail;
            }
            setSigleValue(appntResidentialAddress, pdfStamper, "lcappntaddress.homeaddress");
            if (relationFlag){
                setSigleValue(appntResidentialAddress, pdfStamper, "lcinsuredaddress.homeaddress");
            }

            if (null != ldcodeDao.selectLdcode("iss_country", appntSchema.getBirthcounty()) && ldcodeDao.selectLdcode("iss_country", appntSchema.getBirthcounty()).size() >0 && null != ldcodeDao.selectLdcode("iss_country", appntSchema.getBirthcounty()).get(0)){
                setSigleValue(ldcodeDao.selectLdcode("iss_country", appntSchema.getBirthcounty()).get(0).getCodename(), pdfStamper, "lcappnt.birthcounty");
                if (relationFlag){
                    setSigleValue(ldcodeDao.selectLdcode("iss_country", appntSchema.getBirthcounty()).get(0).getCodename(), pdfStamper, "lcinsured.lcinsuredbirthcounty");
                }
            }
            //证件长期
            Date date = null;
            try {
                date = new SimpleDateFormat("yyyy/MM/dd").parse("9999/01/01");
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Date enddate = appntSchema.getAppntenddate();
            if (null!=enddate){
                if (date.compareTo(enddate) == 0){
                    setSigleValue("长期",pdfStamper,"lcappnt.appntenddate");
                    if (relationFlag){
                        setSigleValue("长期",pdfStamper,"lcinsured.insureidenddate");
                    }
                }
            }
            //税收
            if (null != appntSchema.getTaxtype()) {
                setSigleValue(appntSchema.getAppntname(), pdfStamper, "taxinAppntName");
            }
        }
        if (selectByPrimaryKey1 != null){
            //基本保险金额为0就不填
            if (selectByPrimaryKey1.getAmnt() != null && ("0".equals(selectByPrimaryKey1.getAmnt().toString()) || "0.0".equals(selectByPrimaryKey1.getAmnt().toString()) || "0.00".equals(selectByPrimaryKey1.getAmnt().toString()))){
                setSigleValue("", pdfStamper, "lcpol.amnt");
            }
            //prem为0就不填
            if (selectByPrimaryKey1.getPrem() != null && ("0".equals(selectByPrimaryKey1.getPrem().toString()) || "0.0".equals(selectByPrimaryKey1.getPrem().toString()) || "0.00".equals(selectByPrimaryKey1.getPrem().toString()))){
                setSigleValue("", pdfStamper, "lcpol.prem");
            }
            //additionalprem为0就不填
            if (selectByPrimaryKey1.getAdditionalprem() != null && ("0".equals(selectByPrimaryKey1.getAdditionalprem().toString()) || "0.0".equals(selectByPrimaryKey1.getAdditionalprem().toString()) || "0.00".equals(selectByPrimaryKey1.getAdditionalprem().toString()))){
                setSigleValue("", pdfStamper, "lcpol.additionalprem");
            }
            // 主险

            setSigleValue(getInsuYear(selectByPrimaryKey1), pdfStamper,
                    "lcpol.insuyear");
            setSigleValue(getPayendyear(selectByPrimaryKey1), pdfStamper,
                    "lcpol.payendyear");
            String payintv = selectByPrimaryKey1.getPayintv();
            setSigleValue(payintv, pdfStamper,
                    "lcpol.payintv");
            setSigleValue(selectByPrimaryKey1.getPaymode(), pdfStamper,
                    "lcpol.paymode");
            if ("Y".equals(selectByPrimaryKey1.getAnnuityincamnt())) {
                setSigleValue("增加保额", pdfStamper,
                        "lcpol.annuityincamnt1");
            }
        }

        /** 附加险 */
        List<lcpolVo> lcpolVoList = lcpolDao.selectByPrimaryKey(transno);
        RiskReletionInsuredVo riskReletionInsuredVo = null;
        int FirstAdditionIndex = 1;
        int secondAdditioniIndex = 1;
        int appntIndex = 1;
        int otherIndex = 1;
        System.out.println("附加险lcpolVoList:" + lcpolVoList);
        for (lcpolVo lcpolVo : lcpolVoList) {
            if (lcpolVo.getKindcode() != null && lcpolVo.getRiskcode() != null && lcpolVo.getKindcode().equals(lcpolVo.getRiskcode())) {
                if (null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                    setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "lcpol.bak1");
                } else {
                    setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper, "lcpol.bak1");
                }
                //授权账户号码
                PaymentBranchKey pay = new PaymentBranchKey();
                pay.setTransno(transno);
                pay.setAccountholder("0");// 授权账户
                PaymentBranch payment = paymentbranchMapper.selectByPrimaryKey(pay);
                if (null != payment) {
                    // 授权银行
                    setSigleValue("汇丰银行(中国)有限公司", pdfStamper, "NameBanklcappnt");
                    // 授权账户号码
                    String bankaccno = "";
                    if (payment.getBankaccno() != null){
                        bankaccno = payment.getBankaccno().replaceAll("^CNHSBC(.*)", "$1");
                    }
                    if (bankaccno != null){
                        char[] accountNumberCharArray = bankaccno.toCharArray();
                        for (int j = 0; j < accountNumberCharArray.length; j++) {
                            setSigleValue(accountNumberCharArray[j] + "", pdfStamper, "AccountNumberslcappnt" + (j + 1));
                        }
                    }
                    // 授权省
                    if (null != payment.getAreaprovince()) {
                        setSigleValue(proviceDao.selectByPrimaryKey(
                                new BigDecimal(payment.getAreaprovince())).getProvincename(), pdfStamper, "Areaprovincelcappnt");
                    }

                    // 给予授权市
                    if (null != payment.getAreacity()) {
                        setSigleValue(cityDao.selectByPrimaryKey(new BigDecimal(payment.getAreacity()))
                                .getCityname(), pdfStamper, "Areacitylcappnt");
                    }

                    // 分行/支行
                    if (null != payment.getBranch()) {
                        setSigleValue(payment.getBranch(), pdfStamper, "Branchlcappnt");
                    }
                }
                pay.setAccountholder("1");// 给予账户
                payment = paymentbranchMapper.selectByPrimaryKey(pay);
                if (null != payment) {

                    // 授权银行
                    setSigleValue("汇丰银行(中国)有限公司", pdfStamper, "NameBanklcinsured");
                    // 给予账户号码
                    if (null != payment.getBankaccno()) {


                        String bankaccno1 = payment.getBankaccno().replaceAll("^CNHSBC(.*)", "$1");
                        setSigleValue(bankaccno1, pdfStamper, "AccountNumberslcinsured");

                        // 给予授权省
                        if (null != payment.getAreaprovince()) {
                            setSigleValue(proviceDao.selectByPrimaryKey(
                                    new BigDecimal(payment.getAreaprovince())).getProvincename(), pdfStamper, "Areaprovincelcinsured");
                        }

                        // 给予授权市
                        if (null != payment.getAreacity()) {
                            setSigleValue(cityDao.selectByPrimaryKey(new BigDecimal(payment.getAreacity()))
                                    .getCityname(), pdfStamper, "Areacitylcinsured");
                        }

                        // 给予分行/支行 nameBankIns
                        if (null != payment.getBranch()) {
                            setSigleValue(payment.getBranch(), pdfStamper, "Branchlcinsured");
                        }
                    }
                }

                // 投资产品栏
                List<LCAccountInfoVo> lCAccountInfoVoMapperList = lCAccountInfoVoMapper
                        .selectLCAccountInfoVoOrderBy(transno);
                for (int i = 0; i < lCAccountInfoVoMapperList.size(); i++) {
                    LCAccountInfoVo lcacount = lCAccountInfoVoMapperList.get(i);
                    if (null == lcacount) {
                        System.out.println("投资账户对象是null");
                        continue;
                    }
                    String codeName = lcacount.getBak2();

                    if (i == 0) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc1");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion1");// 投资比例
                        if (null != lcacount.getInvestmentaccount()) {
                            System.out.println("投资账户自动转换" + lcacount.getInvestmentaccount());
                            if ("Y".equals(lcacount.getInvestmentaccount())) {
                                setSigleValue("Y", pdfStamper, "InvestmentAccAut");// 投资账户自动转换
                            }
                        }
                    } else if (i == 1) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc2");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion2");// 投资比例
                    } else if (i == 2) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc3");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion3");// 投资比例
                    } else if (i == 3) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc4");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion4");// 投资比例
                    } else if (i == 4) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc5");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion5");// 投资比例
                    } else if (i == 5) {
                        setSigleValue(codeName, pdfStamper, "InvestAcc6");// 投资账户
                        setSigleValue(lcacount.getAccrate() + "%", pdfStamper, "Proportion6");// 投资比例
                    }
                }
                if (contSchema != null){
                    if (contSchema.getInvestmentStartDateFlag() != null) {
                        String investmentStartDateFlag = contSchema.getInvestmentStartDateFlag();
                        if (("1").equals(investmentStartDateFlag)) {
                            setSigleValue("1", pdfStamper, "Immediately");// 立即投资
                        } else if (("2").equals(investmentStartDateFlag)) {
                            setSigleValue("2", pdfStamper, "Immediately");// 犹豫期后投资
                        }
                    }
                }

                // 红利分配形式
                if (lcpolVo != null && lcpolVo.getBonusgetmode() != null) {
                    String bonusgetmode = lcpolVo.getBonusgetmode();
                    setSigleValue(bonusgetmode, pdfStamper, "lcpol.bonusgetmode");

                    if (("7").equals(bonusgetmode)) {// 累计生息
                        LmriskparamsdefaVo defavo1 = new LmriskparamsdefaVo();
                        if (lcpolVo.getRiskcode() != null){
                            defavo1.setRiskcode(lcpolVo.getRiskcode());
                        }
                        defavo1.setParamstype("bonuspayment");
                        defavo1.setParamscode(bonusgetmode);
                        System.out.println("红利分配形式代号:" + bonusgetmode);
                        if (null != lmriskParamsDefADao.selectlmriskParamsDef(defavo1)){
                            String bonusgetmodeName = lmriskParamsDefADao.selectlmriskParamsDef(defavo1).getParamsname();
                            setSigleValue(bonusgetmodeName, pdfStamper, "OthersDividendName");
                        }
                    }
                }
                //每期保费

                continue;
            }
            riskReletionInsuredVo = new RiskReletionInsuredVo();
            riskReletionInsuredVo.setTransno(transno);
            if (lcpolVo.getRiskcode() != null){
                riskReletionInsuredVo.setRiskcode(lcpolVo.getRiskcode());
            }
            riskReletionInsuredVo.setInsuid("1");// 代表第一被保人附加险
            List<RiskReletionInsuredVo> firstSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            if (firstSelectByPrimaryKey != null && firstSelectByPrimaryKey.size() > 0) {
                try {

                    for (int i = 0; i < firstSelectByPrimaryKey.size(); i++) {

                        // 险种名称
                        if (null != lcpolVo.getPlan() && null != lcpolVo.getRiskcode() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "additonriskname" + FirstAdditionIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "additonriskname" + FirstAdditionIndex);
                        }
                        // 基本保险金额
                        String additionAmnt = "";
                        if (null != lcpolVo.getAmnt()){
                            additionAmnt = lcpolVo.getAmnt().toString();
                        }
                        if (null != lcpolVo.getAmnt() && ("0".equals(lcpolVo.getAmnt()) || "0.0".equals(lcpolVo.getAmnt()) || "0.00".equals(lcpolVo.getAmnt()))) {
                            additionAmnt = "";
                        }
                        setSigleValue(additionAmnt, pdfStamper,
                                "additonsuminsured" + FirstAdditionIndex);
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "additonsatype" + FirstAdditionIndex);
                        }
                        // 保险期间
                        String insuyear1 = "";
                        if (null != lcpolVo.getInsuyear()){
                            insuyear1 = lcpolVo.getInsuyear();
                        }
                        LmriskparamsdefaVo defavo1 = new LmriskparamsdefaVo();
                        if (null != lcpolVo.getRiskcode()){
                            defavo1.setRiskcode(lcpolVo.getRiskcode());
                        }
                        defavo1.setParamstype("insuyear");
                        defavo1.setParamscode(insuyear1);
                        System.out.println("保险期间代号" + insuyear1);
                        if (null != lmriskParamsDefADao.selectlmriskParamsDef(defavo1)){
                            insuyear1 = lmriskParamsDefADao.selectlmriskParamsDef(defavo1).getParamsname();
                        }
                        setSigleValue(insuyear1, pdfStamper,
                                "addbenefitterm" + FirstAdditionIndex);

                        // 保险费支付期
                        String payendyear = "";
                        if (null != lcpolVo.getPayendyear()){
                            payendyear = lcpolVo.getPayendyear();
                        }
                        if (null != payendyear && ("0Y").equals(payendyear)) {
                            payendyear = "趸交";
                        } else {
                            if (null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear) && ldcodeDao.selectLdcode("riskinputtypep05", payendyear).size() >0 && null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0)){
                                payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                            }
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "addpremiumterm" + FirstAdditionIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "addprem" + FirstAdditionIndex);
                        }
                        FirstAdditionIndex++;

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            riskReletionInsuredVo.setInsuid("2");// 代表第二被保人附加险
            List<RiskReletionInsuredVo> secondSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            if (null != secondSelectByPrimaryKey && secondSelectByPrimaryKey.size() > 0) {

                try {
                    System.out.println("第二被保人附加险险种代码" + lcpolVo.getRiskcode() + "List长度"
                            + secondSelectByPrimaryKey.size());
                    for (int i = 0; i < secondSelectByPrimaryKey.size(); i++) {

                        // 险种名称
                        if (null != lcpolVo.getRiskcode() && null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "secadditonriskname" + secondAdditioniIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "secadditonriskname" + secondAdditioniIndex);
                        }

                        // 基本保险金额
                        if (null != lcpolVo.getAmnt()){
                            setSigleValue(lcpolVo.getAmnt().toString(), pdfStamper,
                                    "secadditonsuminsured" + secondAdditioniIndex);
                        }
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "secadditonsatype" + secondAdditioniIndex);
                        }
                        // 保险期间
                        String insuyear2 = "";
                        if (null != lcpolVo.getInsuyear()){
                            insuyear2 = lcpolVo.getInsuyear();
                        }
                        LmriskparamsdefaVo defavo2 = new LmriskparamsdefaVo();
                        if (null != lcpolVo.getRiskcode()){
                            defavo2.setRiskcode(lcpolVo.getRiskcode());
                        }
                        defavo2.setParamstype("insuyear");
                        defavo2.setParamscode(insuyear2);
                        System.out.println("保险期间代号" + insuyear2);
                        if (null != lmriskParamsDefADao.selectlmriskParamsDef(defavo2)){
                            insuyear2 = lmriskParamsDefADao.selectlmriskParamsDef(defavo2).getParamsname();
                        }
                        setSigleValue(insuyear2, pdfStamper,
                                "secaddbenefitterm" + secondAdditioniIndex);

                        // 保险费支付期
                        String payendyear = "";
                        if (null != lcpolVo.getPayendyear()){
                            payendyear = lcpolVo.getPayendyear();
                        }
                        if (null != payendyear && ("0Y").equals(payendyear)) {
                            payendyear = "趸交";
                        } else {
                            if (null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear) && ldcodeDao.selectLdcode("riskinputtypep05", payendyear).size() >0 && null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0)){
                                payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                            }
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "secaddpremiumterm" + secondAdditioniIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "secaddprem" + secondAdditioniIndex);
                        }
                        secondAdditioniIndex++;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


            riskReletionInsuredVo.setInsuid("0");// 代表投保人附加险
            List<RiskReletionInsuredVo> appntSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            Iterator<RiskReletionInsuredVo> appiterator = appntSelectByPrimaryKey.iterator();
            while (appiterator.hasNext()) {
                if (appiterator.next().getOtherinsuredid() != null) {
                    appiterator.remove();
                }
            }

            if (null != appntSelectByPrimaryKey && appntSelectByPrimaryKey.size() > 0) {

                try {
                    System.out.println("投保人附加险险种代码" + lcpolVo.getRiskcode() + "List长度"
                            + appntSelectByPrimaryKey.size());
                    System.out.println("**********");
                    for (int i = 0; i < appntSelectByPrimaryKey.size(); i++) {

                        System.out.println("-------");
                        // 险种名称
                        if (null != lcpolVo.getRiskcode() && null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "appntriskname" + appntIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "appntriskname" + appntIndex);
                        }

                        // 基本保险金额
                        if (null != lcpolVo.getAmnt()){
                            setSigleValue(lcpolVo.getAmnt().toString(), pdfStamper,
                                    "appntsuminsured" + appntIndex);
                        }
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "appntsatype" + appntIndex);
                        }
                        // 保险期间
                        String insuyear0 = "";
                        if (null != lcpolVo.getInsuyear()){
                            insuyear0 = lcpolVo.getInsuyear();
                        }
                        LmriskparamsdefaVo defavo0 = new LmriskparamsdefaVo();
                        if (null != lcpolVo.getRiskcode()){
                            defavo0.setRiskcode(lcpolVo.getRiskcode());
                        }
                        defavo0.setParamstype("insuyear");
                        defavo0.setParamscode(insuyear0);
                        System.out.println("保险期间代号" + insuyear0);
                        if (null != lmriskParamsDefADao.selectlmriskParamsDef(defavo0)){
                            insuyear0 = lmriskParamsDefADao.selectlmriskParamsDef(defavo0).getParamsname();
                        }
                        setSigleValue(insuyear0, pdfStamper,
                                "appntbenefitterm" + appntIndex);

                        // 保险费支付期
                        String payendyear = "";
                        if (null != lcpolVo.getPayendyear()){
                            payendyear = lcpolVo.getPayendyear();
                        }
                        if (null != payendyear && ("0Y").equals(payendyear)) {
                            payendyear = "趸交";
                        } else {
                            if (null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear) && ldcodeDao.selectLdcode("riskinputtypep05", payendyear).size() >0 && null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0)){
                                payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                            }
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "appntpremiumterm" + appntIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "appntprem" + appntIndex);
                        }

                        appntIndex++;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }


            riskReletionInsuredVo.setInsuid("0");// 代表其他被保人附加险
            riskReletionInsuredVo.setOtherinsuredid("0");
            List<RiskReletionInsuredVo> otherSelectByPrimaryKey = riskReletionInsuredDao
                    .SelectByPrimaryKey(riskReletionInsuredVo);
            if (null != otherSelectByPrimaryKey && otherSelectByPrimaryKey.size() > 0) {

                try {
                    System.out.println("投保人附加险险种代码" + lcpolVo.getRiskcode() + "List长度"
                            + otherSelectByPrimaryKey.size());
                    System.out.println("**********");
                    for (int i = 0; i < otherSelectByPrimaryKey.size(); i++) {

                        System.out.println("-------");
                        // 险种名称
                        if (null != lcpolVo.getRiskcode() && null != lcpolVo.getPlan() && StringUtils.isNoneBlank(lcpolVo.getPlan())) {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()) + "(" + getPlan(lcpolVo) + ")", pdfStamper, "otherriskname" + otherIndex);
                        } else {
                            setSigleValue(lmriskDao.selectNameByRiskCode(lcpolVo.getRiskcode()), pdfStamper,
                                    "otherriskname" + otherIndex);
                        }

                        // 基本保险金额
                        if (null != lcpolVo.getAmnt()){
                            setSigleValue(lcpolVo.getAmnt().toString(), pdfStamper,
                                    "othersuminsured" + otherIndex);
                        }
                        if (null != lcpolVo.getType()) {
                            setSigleValue(lcpolVo.getType(), pdfStamper,
                                    "othersatype" + otherIndex);
                        }
                        // 保险期间
                        String insuyear0 = "";
                        if (null != lcpolVo.getInsuyear()){
                            insuyear0 = lcpolVo.getInsuyear();
                        }
                        LmriskparamsdefaVo defavo0 = new LmriskparamsdefaVo();
                        if (null != lcpolVo.getRiskcode()){
                            defavo0.setRiskcode(lcpolVo.getRiskcode());
                        }
                        defavo0.setParamstype("insuyear");
                        defavo0.setParamscode(insuyear0);
                        System.out.println("保险期间代号" + insuyear0);
                        if (null != lmriskParamsDefADao.selectlmriskParamsDef(defavo0)){
                            insuyear0 = lmriskParamsDefADao.selectlmriskParamsDef(defavo0).getParamsname();
                        }
                        setSigleValue(insuyear0, pdfStamper,
                                "otherbenefitterm" + otherIndex);

                        // 保险费支付期
                        String payendyear = "";
                        if (null != lcpolVo.getPayendyear()){
                            payendyear = lcpolVo.getPayendyear();
                        }
                        if (null != payendyear && ("0Y").equals(payendyear)) {
                            payendyear = "趸交";
                        } else {
                            if (null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear) && ldcodeDao.selectLdcode("riskinputtypep05", payendyear).size() >0 && null != ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0)){
                                payendyear = ldcodeDao.selectLdcode("riskinputtypep05", payendyear).get(0).getCodename();
                            }
                        }
                        setSigleValue(payendyear, pdfStamper,
                                "otherpremiumterm" + otherIndex);

                        // 保费
                        if (lcpolVo.getPrem() != null) {
                            setSigleValue(lcpolVo.getPrem().toString(), pdfStamper,
                                    "otherprem" + otherIndex);

                        }

                        otherIndex++;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
            //附加险结束
        }

        if (appntSchema != null){
            //税收
            if (null != appntSchema.getTaxtype() && null != appntSchema.getAppntname()) {
                setSigleValue(appntSchema.getAppntname(), pdfStamper, "taxinAppntName");
            }
        }
        // 销售人员的代码
        SYSUserVo sysUserVo = null;
        if (contSchema != null){
            sysUserVo = loginDao.selectByUserCode(contSchema.getOperator());
        }
        String managecom = "";
        if (sysUserVo != null){
            managecom = contSchema.getManagecom();
        }
        System.out.println("managecom是" + managecom);
        LdcomVo ldcome = ldcomVoMapper.selectByPrimaryKey(managecom);
        if (ldcome != null){
            setSigleValue(ldcome.getComname(), pdfStamper, "sysuser.companyCode");
        }
    }
    private boolean isSelf(String transno){
        boolean relationFlag = false;
        LCAppntVo appntSchema = enterDao.selectBylcAppnt(transno);
        if (null != appntSchema.getRelationtoappnt()) {
            String relation = appntSchema.getRelationtoappnt();
            if ("8".equals(relation)) {
                relationFlag = true;
            }
        }
        System.out.println("relationFlag:" + relationFlag);
        return relationFlag;
    }
}
